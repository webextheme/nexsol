<?php
/**
 * Plugin Name: Deskly Theme Core
 * Plugin URI: webextheme.com
 * Description: Deskly Core Plugin for Custom Post Type, Metabox Features.
 * Version:  1.0
 * Author: webextheme
 * Author URI: http://themeforest.net/user/portfolio
 * License:  GPL2
 * Text Domain: deskly-core
 */

if (!defined('ABSPATH')): exit();endif;

/**
 * Load plugin textdomain.
 */

 if (!function_exists('webex_core_init')) {
	function webex_core_init()
	{
		load_plugin_textdomain('deskly-core', false, dirname(plugin_basename(__FILE__)) . '/languages');
	}
}
add_action('plugins_loaded', 'webex_core_init');

/**
 * Define plugin constants
 */
define('DESKLY_ADDON_FILE', __FILE__);
define('DESKLY_ADDON_PATH', __DIR__);
define('DESKLY_ADDON_URL', plugins_url('', DESKLY_ADDON_FILE));
define('DESKLY_ADDON_ASSETS', DESKLY_ADDON_URL . '/assets');
/**
 * Include Post Types
 */
require DESKLY_ADDON_PATH . '/inc/custom-post-type/header-builder.php';
require DESKLY_ADDON_PATH . '/inc/custom-post-type/side-panel.php';
require DESKLY_ADDON_PATH . '/inc/custom-post-type/footer-builder.php';
require DESKLY_ADDON_PATH . '/inc/custom-post-type/class-deskly-mega-menu.php';
require DESKLY_ADDON_PATH . '/inc/custom-post-type/workspace-custom-post.php';
require DESKLY_ADDON_PATH . '/inc/custom-post-type/workspace-gallery.php';
require DESKLY_ADDON_PATH . '/inc/meta-box/class-workspace-features-meta.php';
require DESKLY_ADDON_PATH . '/admin/admin-panel.php';
require DESKLY_ADDON_PATH . '/csf-icon-library.php';

/**
 * Inclide Taxonomies
 */
// require DESKLY_ADDON_PATH . '/inc/taxonomies/project-taxonomy.php';

/**
 * Inclide Custom Widgets
 */
require DESKLY_ADDON_PATH . '/widgets/recent-posts.php';
require DESKLY_ADDON_PATH . '/widgets/contact-info.php';
require DESKLY_ADDON_PATH . '/widgets/social-list.php';

/**
 * Include Codestar FrameWork
 */
if ( file_exists(DESKLY_ADDON_PATH.'/lib/codestar-framework/codestar-framework.php') ) {
  require_once DESKLY_ADDON_PATH . '/lib/codestar-framework/codestar-framework.php';
}
add_action( 'after_setup_theme', 'deskly_register_theme_options', 5 );
  function deskly_register_theme_options() {
  require_once DESKLY_ADDON_PATH . '/inc/theme-options/theme-options.php';
  require_once DESKLY_ADDON_PATH . '/inc/theme-options/metabox-options.php';
}
/**
 * Main WebexTheme Core Class
 *
 * The init class that runs the Hello World plugin.
 * Intended To make sure that the plugin's minimum requirements are met.
 *
 * You should only modify the constants to match your plugin's needs.
 *
 * Any custom code should go inside Plugin Class in the plugin.php file.
 * @since 1.2.0
 */
final class WebexTheme_Core {

  /**
   * Plugin Version
   *
   * @since 1.0.0
   * @var string The plugin version.
   */
  const VERSION = '1.0.0';

  /**
   * Minimum PHP Version
   *
   * @since 1.2.0
   * @var string Minimum PHP version required to run the plugin.
   */
  const MINIMUM_PHP_VERSION = '7.0';

  /**
   * Constructor
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {

    // Init Plugin
    add_action( 'plugins_loaded', array( $this, 'init' ) );
  }

  /**
   * Initialize the plugin
   *
   * Checks for basic plugin requirements, if one check fail don't continue,
   * if all check have passed include the plugin class.
   *
   * Fired by `plugins_loaded` action hook.
   *
   * @since 1.2.0
   * @access public
   */
  public function init() {

    // Check for required PHP version
    if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
      add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );
      return;
    }

  }

  /**
   * Admin notice
   *
   * Warning when the site doesn't have a minimum required PHP version.
   *
   * @since 1.0.0
   * @access public
   */
  public function admin_notice_minimum_php_version() {
    if ( isset( $_GET['activate'] ) ) {
      unset( $_GET['activate'] );
    }

    $message = sprintf(
      /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
      esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'deskly-core' ),
      '<strong>' . esc_html__( 'Tp Core', 'deskly-core' ) . '</strong>',
      '<strong>' . esc_html__( 'PHP', 'deskly-core' ) . '</strong>',
      self::MINIMUM_PHP_VERSION
    );

    printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
  }
}

// Instantiate WebexTheme_Core.
new WebexTheme_Core();