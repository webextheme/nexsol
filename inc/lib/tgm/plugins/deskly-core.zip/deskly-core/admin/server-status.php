<?php
/**
 * Template Server Status
 *
 * Server Status Template for admin panel
 *
 * @package Deskly
 */

defined( 'ABSPATH' ) || exit;
echo '<h1 class="panel-tab-title">Server Status</h1>';
global $wpdb;
$php_requirements                = 8.0;
$max_execution_time_requirements = 600;
$max_input_time_requirements     = 600;
$max_input_vars_requirements     = 3000;
function convert_to_bytes($size) {
	// Get the unit (last character)
	$unit = strtolower($size[strlen($size) - 1]);
	// Get the numeric part
	$size = (int) $size;
	// Convert to bytes based on the unit
	switch ($unit) {
		case 'g':
		$size *= 1024 * 1024 * 1024; // GB to bytes
			break;
		case 'm':
		$size *= 1024 * 1024; // MB to bytes
		break;
		case 'k':
		$size *= 1024; // KB to bytes
		break;
	}
	return $size; // Return size in bytes
}
$max_upload_size = 134217728; // 128MB in bytes
$upload_max_filesize = convert_to_bytes(ini_get('upload_max_filesize'));

$recommended_memory_limit = 268435456;
$memory_limit = convert_to_bytes(ini_get('memory_limit'));
?>
<div class="webex-dashboard-pages webex-server-status-page">
	<div class="webex-server-status-boxes">
		<div class="status-box">
			<h4><?php esc_html_e( 'WordPress Setting', 'deskly' ) ?>:</h4>
			<div class="status-lists">
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Home URL', 'deskly' );?>:</div>
					<div  class="content"><?php echo esc_html( home_url( '/' ) ); ?></div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Site Url', 'deskly' );?>:</div>
					<div class="content"><?php echo esc_html( site_url( '/' ) ); ?></div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Version', 'deskly' );?>:</div>
					<div class="content"><?php echo esc_html( get_bloginfo( 'version' ) ); ?></div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Language', 'deskly' );?>:</div>
					<div class="content"><?php echo get_locale(); ?></div>
				</div>
				<div class="single-status">
					<div class="title"><?php echo esc_html( 'WP_DEBUG' );?></div>
					<div  class="content">
						<?php if ( defined( 'WP_DEBUG' ) and WP_DEBUG === true ): ?>
						<?php echo esc_html__( 'Enabled.', 'deskly' ); ?>
						<p class="note">
							<a target="_blank" href="https://wordpress.org/support/article/debugging-in-wordpress/">
								<?php echo esc_html__( ' How to disable WP_DEBUG mode.', 'deskly' ); ?>
							</a>
						</p>
						<?php else: ?>
						<?php echo esc_html__( 'Disabled.', 'deskly' ); ?>
						<?php endif;?>
					</div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Memory Limit', 'deskly' );?>:</div>
						<div class="content">
							<?php if ($recommended_memory_limit > $memory_limit): ?>
							<span class="message-info-error">
								<span class="dashicons dashicons-warning"></span>
									<?php
									// Show the original max upload file size
									echo esc_html(ini_get('memory_limit'));
									esc_html_e(' - We recommend a minimum value of: 128 MB.', 'deskly');
									?>
								</span>
								<p class="note">
									<a target="_blank" href="http://www.wpbeginner.com/wp-tutorials/how-to-increase-the-maximum-file-upload-size-in-wordpress/">
											<?php esc_html_e('To see how you can change this, please read this guide', 'deskly'); ?>
									</a>
							</p>
							<?php
							else: ?>
								<?php echo esc_html(ini_get('memory_limit')); ?>
							<?php
							endif; ?>
					</div>
				</div>
			</div>

			<h5><?php esc_html_e( 'Theme Config', 'deskly' ) ?>:</h5>
			<div class="status-lists">
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Theme Name', 'deskly' );?>:</div>
					<div class="content"><?php echo esc_html( wp_get_theme()->get( 'Name' ) ); ?></div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Version', 'deskly' );?>:</div>
					<div class="content"><?php echo esc_html( wp_get_theme()->get( 'Version' ) ); ?></div>
				</div>
				<?php if( is_child_theme() ) : ?>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Parent Theme Version', 'deskly' );?>:</div>
					<div class="content"><?php echo DESKLY_VERSION; ?></div>
				</div>
				<?php endif; ?>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Author', 'deskly' );?>:</div>
					<div class="content">
						<a href="<?php echo esc_url_raw( wp_get_theme()->get( 'AuthorURI' ) ) ?>" target="_blank">
							<?php echo esc_html( wp_get_theme()->get( 'Author' ) ); ?>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="status-box">
			<h4><?php esc_html_e( 'Server Setting', 'deskly' ) ?></h4>
			<div class="status-lists">
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'PHP Version', 'deskly' );?>:</div>
					<div  class="content">
						<?php if ( version_compare( phpversion(), $php_requirements, '<' ) ): ?>
						<span class="message-info-error">
							<span class="dashicons dashicons-warning"></span>
							<?php
								echo esc_html( phpversion() );
								esc_html_e( ' - We recommend a minimum PHP version of Above ', 'deskly' );
								echo esc_html( $php_requirements );
							?>
						</span>
						<?php else:
							echo esc_html( phpversion() );
						endif;?>
					</div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Post Max Size', 'deskly' );?>:</div>
					<?php
					class YourClass {
    			public function display_upload_limit() {?>
        	<div class="content">
            <?php echo esc_html( size_format( $this->let_to_num( ini_get( 'post_max_size' ) ) ) ); ?>
            <p class="note">
							<?php esc_html_e( 'You cannot upload images, themes, and plugins that have a size bigger than this value.', 'deskly' ); ?>
							<a target="_blank" href="http://www.wpbeginner.com/wp-tutorials/how-to-increase-the-maximum-file-upload-size-in-wordpress/">
								<?php esc_html_e( 'If you want to change this setting please read this guide', 'deskly' ); ?>
							</a>
            </p>
        	</div>
        <?php }

				private function let_to_num($size) {
					$unit = strtoupper(substr($size, -1));
					$size = (int) $size;
					switch ($unit) {
						case 'G':
							$size *= 1024;
						case 'M':
							$size *= 1024;
						case 'K':
							$size *= 1024;
					}
				return $size;
				}
			}

				$instance = new YourClass();
				$instance->display_upload_limit();
				?>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Max Execution Time', 'deskly' );?>:</div>
					<div class="content">
						<?php if ( $max_execution_time_requirements > ini_get( 'max_execution_time' ) ): ?>
						<span class="message-info-error">
							<span class="dashicons dashicons-warning"></span>
							<?php
								echo esc_html( ini_get( 'max_execution_time' ) );
								esc_html_e( ' - We recommend setting max execution time to at least ', 'deskly' );
								echo esc_html( $max_execution_time_requirements );
							?>
						</span>
						<p class="note">
							<a target="_blank" href="https://code.tutsplus.com/tutorials/how-to-increase-max_execution_time-in-php--cms-37017">
								<?php echo esc_html__( 'To see how you can change this please read this guide', 'deskly' ); ?>
							</a>
						</p>
						<?php else:
							echo esc_html( ini_get( 'max_execution_time' ) );
						endif; ?>
					</div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'PHP Max Input Time', 'deskly' );?>:</div>
					<div class="content">
						<?php if ( $max_input_time_requirements > ini_get( 'max_input_time' ) ): ?>
						<span class="message-info-error">
							<span class="dashicons dashicons-warning"></span>
							<?php
								echo esc_html( ini_get( 'max_input_time' ) );
								esc_html_e( ' - We recommend setting max execution time to at least ', 'deskly' );
								echo esc_html( $max_input_time_requirements );
							?>
						</span>
						<p class="note">
							<a target="_blank" href="http://www.wpbeginner.com/wp-tutorials/how-to-increase-the-maximum-file-upload-size-in-wordpress/">
								<?php echo esc_html__( 'To see how you can change this please read this guide', 'deskly' ); ?>
							</a>
						</p>
						<?php else:
							echo esc_html( ini_get( 'max_input_time' ) );
						endif; ?>
					</div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'PHP Max Input Vars', 'deskly' );?>:</div>
					<div class="content">
						<?php if ( $max_input_vars_requirements > ini_get( 'max_input_vars' ) ): ?>
						<span class="message-info-error">
							<span class="dashicons dashicons-warning"></span>
							<?php
								echo esc_html( ini_get( 'max_input_vars' ) );
								esc_html_e( ' - We recommend setting max execution time to at least ', 'deskly' );
								echo esc_html( $max_input_vars_requirements );
							?>
						</span>
						<p class="note">
							<a target="_blank" href="http://www.wpbeginner.com/wp-tutorials/how-to-increase-the-maximum-file-upload-size-in-wordpress/">
								<?php echo esc_html__( 'To see how you can change this please read this guide', 'deskly' ); ?>
							</a>
						</p>
						<?php else:
							echo esc_html( ini_get( 'max_input_vars' ) );
						endif; ?>
					</div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'MySql Version', 'deskly' );?>:</div>
					<div class="content"><?php echo ( ! empty( $wpdb->is_mysql ) ? $wpdb->db_version() : '' ); ?></div>
				</div>
				<div class="single-status">
					<div class="title"><?php esc_html_e( 'Max upload size', 'deskly' );?>:</div>
						<div class="content">
							<?php if ($max_upload_size > $upload_max_filesize): ?>
							<span class="message-info-error">
								<span class="dashicons dashicons-warning"></span>
									<?php
									// Show the original max upload file size
									echo esc_html(ini_get('upload_max_filesize'));
									esc_html_e(' - We recommend a minimum value of: 128 MB.', 'deskly');
									?>
								</span>
								<p class="note">
									<a target="_blank" href="http://www.wpbeginner.com/wp-tutorials/how-to-increase-the-maximum-file-upload-size-in-wordpress/">
											<?php esc_html_e('To see how you can change this, please read this guide', 'deskly'); ?>
									</a>
							</p>
							<?php
							else: ?>
								<?php echo esc_html(ini_get('upload_max_filesize')); ?>
							<?php
							endif; ?>
					</div>
				</div>

				<div class="single-status">
					<div class="title"><?php esc_html_e( 'SimpleXML', 'deskly' );?>:</div>
					<div class="content">
						<?php if ( ! extension_loaded( 'simplexml' ) ): ?>
						<span class="message-info-error">
							<?php esc_html_e( 'To ensure successful installation of demo content The SimpleXML extension should be installed on your web server. Please contact your hosting provider to install and activate SimpleXML extension.', 'deskly' ) ?>
						</span>
						<?php else:
							echo esc_html__( 'Enabled', 'deskly' );
						endif;?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>