<?php
/**
 * Template Help center
 *
 * Help Center Template for admin panel
 *
 * @package Deskly
 */

defined( 'ABSPATH' ) || exit;
echo '<h1 class="panel-tab-title">Help Center</h1>';

$allowed_html = [
	'a' => [
			'href'   => true,
			'target' => true,
	],
];

?>
<div class="webex-dashboard-pages deskly-helper-center-page">
	<div class="webex-help-boxes">
		<div class="help-box doc-box">
			<a href="https://docs.webextheme.com/deskly-docs/" target="_blank" class="help-center-btn"><?php esc_html_e( 'Documentation', 'deskly' ) ?></a>
		</div>
		<div class="help-box support-box">
			<a href="https://themeforest.net/user/webextheme#contact" target="_blank" class="help-center-btn"><?php esc_html_e( 'Get Support', 'deskly' ) ?></a>
		</div>
	</div>
</div>