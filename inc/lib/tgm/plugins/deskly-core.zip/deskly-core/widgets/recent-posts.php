<?php
/**
 * Class Definition.
 */
class Deskly_Recent_Posts extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
		parent::__construct(
			// Base ID of your widget.
			'deskly_recent_posts',
			// Widget name will appear in UI.
			esc_html__( '(Theme) Deskly Recent Posts', 'deskly-core' ),
			// Widget description.
			array(
				'description' => esc_html__( 'Widget for recent posts.', 'deskly-core' ),
			)
		);
	}

	/**
	 * Widget Backend
	 *
	 * @param  [type] $instance description.
	 */
	public function form( $instance ) {
		$post_title = ! empty( $instance['post_title'] ) ? $instance['post_title'] : "";
		$post_count      = ! empty( $instance['post_count'] ) ? $instance['post_count'] : esc_html__( '3', 'deskly-core' );
		$post_title_word_count      = ! empty( $instance['post_title_word_count'] ) ? $instance['post_title_word_count'] : esc_html__( '2', 'deskly-core' );
		// Widget admin form.
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'post_title' ) ); ?>"><?php esc_html_e( 'Title:', 'deskly-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'post_title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_title' ) ); ?>" type="text" value="<?php echo esc_attr( $post_title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'post_count' ) ); ?>"><?php esc_html_e( 'No. of Posts to show:', 'deskly-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'post_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_count' ) ); ?>" type="number" value="<?php echo esc_attr( $post_count ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'post_title_word_count' ) ); ?>"><?php esc_html_e( 'Post Title Word Count:', 'deskly-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'post_title_word_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_title_word_count' ) ); ?>" type="number" value="<?php echo esc_attr( $post_title_word_count ); ?>" />
		</p>
		<?php
	}

	/**
	 * Creating widget front-end.
	 *
	 * @param  [type] $args     description.
	 * @param  [type] $instance description.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		// before and after widget arguments are defined by themes.
		echo wp_kses_post( $args['before_widget'] );
		if ( ! empty( $instance['title'] ) ) {
			echo wp_kses_post( $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'] );
		}

		$post_title 		 = ! empty( $instance['post_title'] ) ? $instance['post_title'] : '';
		$post_count      = ! empty( $instance['post_count'] ) ? $instance['post_count'] : esc_html__( '3', 'deskly-core' );
		$post_title_word_count      = ! empty( $instance['post_title_word_count'] ) ? $instance['post_title_word_count'] : esc_html__( '2', 'deskly-core' );
		?>
		<?php if($post_title == true): ?>
		<h5 class="widget-title"><?php echo esc_attr( $post_title ); ?></h5>
		<?php endif; ?>
		<?php
		$query = new WP_Query(
			array(
				'post_type'      => 'post',
				'posts_per_page' => $post_count,
				'orderby'        => 'ID',
				'order'          => 'DESC',

			)
		);
		while ( $query->have_posts() ) :
			$query->the_post();
			?>
		<div class="webex_single-post media">
			<div class="webex_post-image">
					<?php if ( has_post_thumbnail() ) { ?>
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'deskly-image(72x72)' ); ?></a>
					<?php } ?>
			</div>
			<div class="webex_post-content">
				<h5 class="webex_post-title"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words( get_the_title(), $post_title_word_count, '' ); ?></a></h5>
				<h6 class="webex_post-date"><i class="far fa-clock mrr-5"></i><?php echo get_the_date(); ?></h6>
			</div>
		</div>
			<?php
		endwhile; // End of the loop.
		?>
		<?php wp_reset_postdata(); ?>

		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Updating widget replacing old instances with new.
	 *
	 * @param  [type] $new_instance description.
	 * @param  [type] $old_instance description.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                  = array();
		$instance['post_title'] = ( ! empty( $new_instance['post_title'] ) ) ? strip_tags(
			$new_instance['post_title']
		) : '';

		$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags(
			$new_instance['post_count']
		) : '';

		$instance['post_title_word_count'] = ( ! empty( $new_instance['post_title_word_count'] ) ) ? strip_tags(
			$new_instance['post_title_word_count']
		) : '';

		return $instance;
	}

}
/**
 * Register and load the widget
 */
function deskly_recent_posts_load_widget() {
	register_widget( 'Deskly_Recent_Posts' );
}
add_action( 'widgets_init', 'deskly_recent_posts_load_widget' );
