<?php
/**
 * Class Definition.
 */
global $deskly_redux;
class Deskly_Social_List extends WP_Widget {
	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
		parent::__construct(
			// Base ID of your widget.
			'Deskly_social_list',
			// Widget name will appear in UI.
			esc_html__( '(Theme) Deskly Social List', 'deskly-core' ),
			// Widget description.
			array(
				'description' => esc_html__( 'Widget for Social List.', 'deskly-core' ),
			)
		);
	}

	/**
	 * Widget Backend
	 *
	 * @param  [type] $instance description.
	 */
	public function form( $instance ) {
		$post_title = ! empty( $instance['post_title'] ) ? $instance['post_title'] : "";
		$title_extra_class = ! empty( $instance['title_extra_class'] ) ? $instance['title_extra_class'] : "";
		$facebook = ! empty( $instance['facebook'] ) ? $instance['facebook'] : "";
		$twitter = ! empty( $instance['twitter'] ) ? $instance['twitter'] : "";
		$instagram = ! empty( $instance['instagram'] ) ? $instance['instagram'] : "";
		$google_plus = ! empty( $instance['google_plus'] ) ? $instance['google_plus'] : "";

		// Widget admin form.
		?>
<p>
  <label
    for="<?php echo esc_attr( $this->get_field_id( 'post_title' ) ); ?>"><?php esc_html_e( 'Title:', 'deskly-core' ); ?></label>
  <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'post_title' ) ); ?>"
    name="<?php echo esc_attr( $this->get_field_name( 'post_title' ) ); ?>" type="text"
    value="<?php echo esc_attr( $post_title ); ?>" />
</p>
<p>
  <label
    for="<?php echo esc_attr( $this->get_field_id( 'title_extra_class' ) ); ?>"><?php esc_html_e( 'Extra Class:', 'deskly-core' ); ?></label>
  <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title_extra_class' ) ); ?>"
    name="<?php echo esc_attr( $this->get_field_name( 'title_extra_class' ) ); ?>" type="text"
    value="<?php echo esc_attr( $title_extra_class ); ?>" />
</p>
<p>
  <label
    for="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>"><?php esc_html_e( 'Facebook:', 'deskly-core' ); ?></label>
  <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>"
    name="<?php echo esc_attr( $this->get_field_name( 'facebook' ) ); ?>" type="text"
    value="<?php echo esc_url( $facebook ); ?>" />
</p>
<p>
  <label
    for="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>"><?php esc_html_e( 'Twitter:', 'deskly-core' ); ?></label>
  <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>"
    name="<?php echo esc_attr( $this->get_field_name( 'twitter' ) ); ?>" type="text"
    value="<?php echo esc_url( $twitter ); ?>" />
</p>
<p>
  <label
    for="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>"><?php esc_html_e( 'Instagram:', 'deskly-core' ); ?></label>
  <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>"
    name="<?php echo esc_attr( $this->get_field_name( 'instagram' ) ); ?>" type="text"
    value="<?php echo esc_url( $instagram ); ?>" />
</p>
<p>
  <label
    for="<?php echo esc_attr( $this->get_field_id( 'google_plus' ) ); ?>"><?php esc_html_e( 'Google Plus:', 'deskly-core' ); ?></label>
  <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'google_plus' ) ); ?>"
    name="<?php echo esc_attr( $this->get_field_name( 'google_plus' ) ); ?>" type="text"
    value="<?php echo esc_url( $google_plus ); ?>" />
</p>
<?php
	}

	/**
	 * Creating widget front-end.
	 *
	 * @param  [type] $args     description.
	 * @param  [type] $instance description.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		// before and after widget arguments are defined by themes.
		echo wp_kses_post( $args['before_widget'] );
		if ( ! empty( $instance['title'] ) ) {
			echo wp_kses_post( $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'] );
		}
		$post_title 		 = ! empty( $instance['post_title'] ) ? $instance['post_title'] : '';
		$title_extra_class = ! empty( $instance['title_extra_class'] ) ? $instance['title_extra_class'] : "";
		$facebook = ! empty( $instance['facebook'] ) ? $instance['facebook'] : "";
		$twitter = ! empty( $instance['twitter'] ) ? $instance['twitter'] : "";
		$instagram = ! empty( $instance['instagram'] ) ? $instance['instagram'] : "";
		$google_plus = ! empty( $instance['google_plus'] ) ? $instance['google_plus'] : "";

		?>
<?php if($post_title == true): ?>
<h5 class="widget-title <?php if( $title_extra_class == true ): echo esc_attr( $title_extra_class ); endif; ?> ">
  <?php echo esc_attr( $post_title ); ?></h5>
<?php endif; ?>

<ul class="social-list">
  <?php if($facebook == true): ?>
  <li><a href="<?php echo esc_url( $facebook ); ?>" aria-label="Social Link"><i class="fab fa-facebook-f"></i></a></li>
  <?php endif; ?>
  <?php if($twitter == true): ?>
  <li><a href="<?php echo esc_url( $twitter ); ?>" aria-label="Social Link"><i class="fab fa-twitter"></i></a></li>
  <?php endif; ?>
  <?php if($instagram == true): ?>
  <li><a href="<?php echo esc_url( $instagram ); ?>" aria-label="Social Link"><i class="fab fa-instagram"></i></a></li>
  <?php endif; ?>
  <?php if($google_plus == true): ?>
  <li><a href="<?php echo esc_url( $google_plus ); ?>" aria-label="Social Link"><i class="fab fa-google-plus-g"></i></a>
  </li>
  <?php endif; ?>
</ul>

<?php wp_reset_postdata(); ?>
<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Updating widget replacing old instances with new.
	 *
	 * @param  [type] $new_instance description.
	 * @param  [type] $old_instance description.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                  = array();
		$instance['post_title'] = ( ! empty( $new_instance['post_title'] ) ) ? strip_tags(
			$new_instance['post_title']
		) : '';

		$instance['title_extra_class'] = ( ! empty( $new_instance['title_extra_class'] ) ) ? strip_tags(
			$new_instance['title_extra_class']
		) : '';

		$instance['facebook'] = ( ! empty( $new_instance['facebook'] ) ) ? wp_strip_all_tags(
			$new_instance['facebook']
		) : '';

		$instance['twitter'] = ( ! empty( $new_instance['twitter'] ) ) ? wp_strip_all_tags(
			$new_instance['twitter']
		) : '';

		$instance['instagram'] = ( ! empty( $new_instance['instagram'] ) ) ? wp_strip_all_tags(
			$new_instance['instagram']
		) : '';

		$instance['google_plus'] = ( ! empty( $new_instance['google_plus'] ) ) ? wp_strip_all_tags(
			$new_instance['google_plus']
		) : '';

		return $instance;
	}

}
/**
 * Register and load the widget
 */
function deskly_social_list_load_widget() {
	register_widget( 'Deskly_Social_List' );
}
add_action( 'widgets_init', 'deskly_social_list_load_widget' );