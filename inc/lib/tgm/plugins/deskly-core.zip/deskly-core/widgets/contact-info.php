<?php
/**
 * Class Definition.
 */
global $deskly_redux;
class Deskly_Contact_Info extends WP_Widget {
	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
		parent::__construct(
			// Base ID of your widget.
			'Deskly_contact_info',
			// Widget name will appear in UI.
			esc_html__( '(Theme) Deskly Contact Info', 'deskly-core' ),
			// Widget description.
			array(
				'description' => esc_html__( 'Widget for Contact Information.', 'deskly-core' ),
			)
		);
	}

	/**
	 * Widget Backend
	 *
	 * @param  [type] $instance description.
	 */
	public function form( $instance ) {
		// Set default values.
		$instance = wp_parse_args(
			(array) $instance,
			array(
				'contact_address_area'  => '',
				'contact_phone_area'  => '',
				'contact_email_area'  => '',
				'contact_website_area'  => '',
			)
		);
		$post_title = ! empty( $instance['post_title'] ) ? $instance['post_title'] : "";
		$contact_address_area  = ! empty( $instance['contact_address_area'] ) ? $instance['contact_address_area'] : '';
		$contact_phone_area  = ! empty( $instance['contact_phone_area'] ) ? $instance['contact_phone_area'] : '';
		$contact_email_area  = ! empty( $instance['contact_email_area'] ) ? $instance['contact_email_area'] : '';
		$contact_website_area  = ! empty( $instance['contact_website_area'] ) ? $instance['contact_website_area'] : '';

		// Widget admin form.
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'post_title' ) ); ?>"><?php esc_html_e( 'Title:', 'deskly-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'post_title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_title' ) ); ?>" type="text" value="<?php echo esc_attr( $post_title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'contact_address_area' ) ); ?>"><?php esc_html_e( 'Address:', 'deskly-core' ); ?></label>
			<textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'contact_address_area' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'contact_address_area' ) ); ?>"><?php echo esc_html( $contact_address_area ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'contact_phone_area' ) ); ?>"><?php esc_html_e( 'Phone No:', 'deskly-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'contact_phone_area' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'contact_phone_area' ) ); ?>" type="number" value="<?php echo esc_attr( $contact_phone_area ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'contact_email_area' ) ); ?>"><?php esc_html_e( 'Email:', 'deskly-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'contact_email_area' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'contact_email_area' ) ); ?>" type="text" value="<?php echo esc_attr( $contact_email_area ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'contact_website_area' ) ); ?>"><?php esc_html_e( 'Website:', 'deskly-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'contact_website_area' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'contact_website_area' ) ); ?>" type="text" value="<?php echo esc_attr( $contact_website_area ); ?>" />
		</p>
		<?php
	}

	/**
	 * Creating widget front-end.
	 *
	 * @param  [type] $args     description.
	 * @param  [type] $instance description.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		// before and after widget arguments are defined by themes.
		echo wp_kses_post( $args['before_widget'] );
		if ( ! empty( $instance['title'] ) ) {
			echo wp_kses_post( $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'] );
		}
		$post_title 		 = ! empty( $instance['post_title'] ) ? $instance['post_title'] : '';

		$contact_address_area  = empty( $instance['contact_address_area'] ) ? '' : $instance['contact_address_area'];
		$contact_phone_area  = empty( $instance['contact_phone_area'] ) ? '' : $instance['contact_phone_area'];
		$contact_email_area  = ! empty( $instance['contact_email_area'] ) ? $instance['contact_email_area'] : '';
		$contact_website_area  = ! empty( $instance['contact_website_area'] ) ? $instance['contact_website_area'] : '';
		?>
		<?php if($post_title == true): ?>
			<h5 class="widget-title"><?php echo esc_attr( $post_title ); ?></h5>
		<?php endif; ?>

		<?php if( $contact_address_area == true ): ?>
			<p><?php echo esc_html( $contact_address_area ); ?></p>
		<?php endif; ?>
		<ul class="webex_widget-social-list">
			<?php if( $contact_phone_area == true ): ?>
				<li>
					<span><i class="fas fa-phone-alt alt mrr-10"></i>+<?php echo esc_html( $contact_phone_area ); ?></span>
				</li>
			<?php endif; ?>
			<?php if( $contact_email_area == true ): ?>
				<li>
					<span><i class="fas fa-envelope mrr-10"></i><?php echo esc_html( $contact_email_area ); ?></span>
				</li>
			<?php endif; ?>
			<?php if( $contact_website_area == true ): ?>
				<li>
					<span><i class="fas fa-globe mrr-10"></i><?php echo esc_html( $contact_website_area ); ?></span>
				</li>
			<?php endif; ?>
		</ul>

		<?php wp_reset_postdata(); ?>
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Updating widget replacing old instances with new.
	 *
	 * @param  [type] $new_instance description.
	 * @param  [type] $old_instance description.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                  = array();
		$instance['post_title'] = ( ! empty( $new_instance['post_title'] ) ) ? strip_tags(
			$new_instance['post_title']
		) : '';

		$instance['contact_address_area'] = ( ! empty( $new_instance['contact_address_area'] ) ) ? wp_strip_all_tags(
			$new_instance['contact_address_area']
		) : '';

		$instance['contact_phone_area'] = ( ! empty( $new_instance['contact_phone_area'] ) ) ? strip_tags(
			$new_instance['contact_phone_area']
		) : '';

		$instance['contact_email_area'] = ( ! empty( $new_instance['contact_email_area'] ) ) ? strip_tags(
			$new_instance['contact_email_area']
		) : '';

		$instance['contact_website_area'] = ( ! empty( $new_instance['contact_website_area'] ) ) ? strip_tags(
			$new_instance['contact_website_area']
		) : '';

		return $instance;
	}

}
/**
 * Register and load the widget
 */
function deskly_contact_info_load_widget() {
	register_widget( 'Deskly_Contact_Info' );
}
add_action( 'widgets_init', 'deskly_contact_info_load_widget' );
