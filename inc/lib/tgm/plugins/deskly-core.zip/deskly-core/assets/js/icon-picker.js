jQuery(function ($) {
  let iconList = [];
  let activeInput = null;

  $.getJSON(DesklyIconPicker.json_url, function (data) {
    iconList = data.icons ?? data;
  });

  // OPEN ICON PICKER
  $(document).on('click', '.deskly-icon-picker-btn', function () {
    activeInput = $(this).closest('.deskly-ws-feature-row').find('.deskly-icon-picker-input');

    $('#deskly-icon-popup').show();
    let list = $('.deskly-icon-list').html('');

    iconList.forEach((icon) => {
      list.append(`
        <div class="deskly-icon-item" data-icon="${icon}">
          <i class="${icon}"></i>
        </div>
      `);
    });
  });

  // SELECT ICON
  $(document).on('click', '.deskly-icon-item', function () {
    let iconClass = $(this).data('icon');

    if (activeInput) {
      activeInput.val(iconClass);

      // update preview span
      let preview = activeInput.closest('.deskly-icon-picker-input-wrapper')
        .find('.deskly-icon-preview');

      preview.attr("class", "deskly-icon-preview " + iconClass);
    }

    $('#deskly-icon-popup').hide();
  });

  // SEARCH FILTER
  $(document).on('keyup', '#deskly-icon-search', function () {
    let k = $(this).val().toLowerCase();

    $('.deskly-icon-item').each(function () {
      $(this).toggle($(this).data('icon').toLowerCase().includes(k));
    });
  });

  // ADD ROW
  $(document).on('click', '#deskly-ws-add-row', function () {
    let newRow = `
      <div class="deskly-ws-feature-row">

        <div class="deskly-icon-picker-input-wrapper">
          <span class="deskly-icon-preview"></span>
          <input type="text" name="deskly_ws_icon[]" class="widefat deskly-icon-picker-input" />
        </div>

        <button type="button" class="button deskly-icon-picker-btn">Choose Icon</button>

        <input type="text" name="deskly_ws_text[]" class="widefat" placeholder="Feature text" />

        <button type="button" class="button button-secondary deskly-ws-remove-row">Remove</button>
      </div>
    `;

    $('#deskly-ws-features-wrapper').append(newRow);
  });

  // REMOVE ROW
  $(document).on('click', '.deskly-ws-remove-row', function () {
    $(this).closest('.deskly-ws-feature-row').remove();
  });
});
