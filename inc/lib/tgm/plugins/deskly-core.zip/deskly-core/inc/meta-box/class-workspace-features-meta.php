<?php
/**
 * Workspace Features Meta Box + Custom Icon Picker + Numbering
 */

if ( ! class_exists( 'Deskly_Workspace_Features_Meta' ) ) {

  class Deskly_Workspace_Features_Meta {

    private $meta_key   = '_deskly_workspace_features';
    private $number_key = '_deskly_workspace_number';
    private $post_type  = 'webex_workspaces';

    public static function init() {
      static $instance = null;
      if ( $instance === null ) {
        $instance = new self();
      }
      return $instance;
    }

    private function __construct() {
      add_action( 'add_meta_boxes', array( $this, 'register_meta_box' ) );
      add_action( 'save_post', array( $this, 'save_meta_box' ) );
      add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    /**
     * Load icon picker assets + JSON icon library
     */
    public function enqueue_assets() {
      global $post_type;

      if ( $post_type !== $this->post_type ) {
        return;
      }

      // Custom icon font (deskly-elementor-core)
      wp_enqueue_style(
        'deskly-ws-icons',
        plugins_url('/assets/fonts/webexcoworkingicon/style.css', '/deskly-elementor-core/webex-elementor-core.php'),
        array(),
        '1.0'
      );

      // Admin CSS
      wp_enqueue_style(
        'deskly-icon-picker-admin',
        plugins_url('/assets/css/icon-picker-admin.css', DESKLY_ADDON_FILE),
        array(),
        '1.0'
      );

      // Icon Picker JS
      wp_enqueue_script(
        'deskly-icon-picker',
        plugins_url('/assets/js/icon-picker.js', DESKLY_ADDON_FILE),
        array('jquery'),
        '1.0',
        true
      );

      // Pass JSON path
      wp_localize_script(
        'deskly-icon-picker',
        'DesklyIconPicker',
        array(
          'json_url' => plugins_url(
            '/assets/fonts/webexcoworkingicon/webexcoworkingicon.json',
            '/deskly-elementor-core/webex-elementor-core.php'
          ),
        )
      );
    }

    /**
     * Register Meta Box
     */
    public function register_meta_box() {
      add_meta_box(
        'deskly_workspace_features',
        esc_html__( 'Workspace Features', 'deskly-core' ),
        array( $this, 'render_meta_box' ),
        $this->post_type,
        'normal',
        'default'
      );
    }

    /**
     * Render UI
     */
    public function render_meta_box( $post ) {

      wp_nonce_field(
        'deskly_workspace_features_nonce_action',
        'deskly_workspace_features_nonce'
      );

      $features = get_post_meta( $post->ID, $this->meta_key, true );
      if ( ! is_array( $features ) ) {
        $features = array();
      }

      $workspace_number = get_post_meta( $post->ID, $this->number_key, true );
      ?>

      <!-- WORKSPACE NUMBER FIELD -->
      <div class="deskly-ws-number-wrap">
        <label>Workspace Number (e.g. 01, 02, 03)</label>
        <input
          type="text"
          name="deskly_ws_number"
          class="widefat"
          value="<?php echo esc_attr( $workspace_number ); ?>"
          placeholder="Enter numbering (e.g. 01)"
        />
      </div>

      <!-- REPEATER -->
      <div id="deskly-ws-features-wrapper">

        <?php foreach ( $features as $feature ) :
          $icon = $feature['icon'] ?? '';
          $text = $feature['text'] ?? '';
        ?>
          <div class="deskly-ws-feature-row">

            <div class="deskly-icon-picker-input-wrapper">
              <span class="deskly-icon-preview <?php echo esc_attr( $icon ); ?>"></span>

              <input
                type="text"
                name="deskly_ws_icon[]"
                class="widefat deskly-icon-picker-input"
                value="<?php echo esc_attr( $icon ); ?>"
                placeholder="Click: Choose Icon"
              />
            </div>

            <button type="button" class="button deskly-icon-picker-btn">Choose Icon</button>

            <input
              type="text"
              name="deskly_ws_text[]"
              class="widefat"
              value="<?php echo esc_attr( $text ); ?>"
              placeholder="Feature text (e.g. Square: 45ft)"
            />

            <button type="button" class="button button-secondary deskly-ws-remove-row">Remove</button>

          </div>
        <?php endforeach; ?>

        <?php if ( empty( $features ) ) : ?>
          <div class="deskly-ws-feature-row">

            <div class="deskly-icon-picker-input-wrapper">
              <span class="deskly-icon-preview"></span>

              <input
                type="text"
                name="deskly_ws_icon[]"
                class="widefat deskly-icon-picker-input"
                value=""
                placeholder="Click: Choose Icon"
              />
            </div>

            <button type="button" class="button deskly-icon-picker-btn">Choose Icon</button>

            <input
              type="text"
              name="deskly_ws_text[]"
              class="widefat"
              placeholder="Feature text (e.g. Square: 45ft)"
            />

            <button type="button" class="button button-secondary deskly-ws-remove-row">Remove</button>

          </div>
        <?php endif; ?>

      </div>

      <p>
        <button type="button" class="button button-primary" id="deskly-ws-add-row">Add Feature</button>
      </p>

      <!-- ICON POPUP -->
      <div id="deskly-icon-popup" style="display:none;">
        <div class="deskly-icon-popup-inner">
          <input type="text" id="deskly-icon-search" placeholder="Search icons..." />
          <div class="deskly-icon-list"></div>
        </div>
      </div>

      <?php
    }

    /**
     * SAVE META
     */
    public function save_meta_box( $post_id ) {

      if (
        ! isset( $_POST['deskly_workspace_features_nonce'] ) ||
        ! wp_verify_nonce( $_POST['deskly_workspace_features_nonce'], 'deskly_workspace_features_nonce_action' )
      ) {
        return;
      }

      if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
      }

      if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
      }

      // Save number
      if ( isset( $_POST['deskly_ws_number'] ) ) {
        $number = sanitize_text_field( $_POST['deskly_ws_number'] );
        if ( ! empty( $number ) ) {
          update_post_meta( $post_id, $this->number_key, $number );
        } else {
          delete_post_meta( $post_id, $this->number_key );
        }
      }

      // Save repeater fields
      $icons = $_POST['deskly_ws_icon'] ?? array();
      $texts = $_POST['deskly_ws_text'] ?? array();

      $features = array();

      foreach ( $icons as $i => $icon ) {
        $icon = trim( $icon );
        $text = trim( $texts[$i] ?? '' );

        if ( $icon === '' && $text === '' ) {
          continue;
        }

        $features[] = array(
          'icon' => sanitize_text_field( $icon ),
          'text' => sanitize_text_field( $text ),
        );
      }

      if ( empty( $features ) ) {
        delete_post_meta( $post_id, $this->meta_key );
      } else {
        update_post_meta( $post_id, $this->meta_key, $features );
      }
    }
  }
}

Deskly_Workspace_Features_Meta::init();
