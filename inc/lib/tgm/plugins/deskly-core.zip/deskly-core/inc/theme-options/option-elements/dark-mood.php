<?php
/*
* ====================================
* ===== START Dark Mood Settings =====
* ====================================
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
CSF::createSection( $desklyThemeOption, array(
	'title'  => esc_html__( 'Dark Mood', 'deskly-core' ),
	'id'     => 'dark_mood_settings',
	'icon'   => 'far fa-moon',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Dark Mood Settings', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'      => 'general-settings-enable-dark-mode',
			'type'    => 'switcher',
			'title'   => esc_html__( 'Enable Dark Mode (Global)', 'deskly' ),
			'label'   => esc_html__( 'Turn on to enable dark layout globally.', 'deskly' ),
			'default' => false,
		),
	),
) );

/*
* ====================================
* ====== End Dark Mood Settings ======
* ====================================
*/