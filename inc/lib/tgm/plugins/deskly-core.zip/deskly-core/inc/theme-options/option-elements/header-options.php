<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ===============================
* ====  Start Header Setings ====
* ===============================
*/
CSF::createSection( $desklyThemeOption, array(
	'id'    => 'deskly_header_settings',
	'title' => esc_html__( 'Header Settings', 'deskly-core' ),
	'icon'  => 'far fa-window-maximize',
) );
/*
* =============================
* ====  End Header Setings ====
* =============================
*/

/*
* ============================
* ====  Star Header Style ====
* ============================
*/
CSF::createSection( $desklyThemeOption, array(
	'parent' => 'deskly_header_settings',
	'title'  => esc_html__( 'Header Styles', 'deskly-core' ),
	'icon'   => 'fas fa-arrow-right',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Elementor Header Styles', 'deskly-core' ) . '</h3>',
		),
    // Header Builder Solid
		array(
      'id'             => 'header_builder_solid',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor Solid Header Style', 'deskly-core'),
      'options'        => 'posts',
			'placeholder' 	 => 'Select an option',
      'query_args'     => array(
        'post_type'      => 'wbx_header_builder',
        'posts_per_page' => -1,
      ),
    ),
    // Header Builder Transparent
		array(
      'id'             => 'header_builder_transparent',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor Transparent Header Style', 'deskly-core'),
      'options'        => 'posts',
			'placeholder' 	 => 'Select an option',
      'query_args'     => array(
        'post_type'      => 'wbx_header_builder',
        'posts_per_page' => -1,
      ),
    ),
    // Header Builder Sticky
		array(
      'id'             => 'header_builder_sticky',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor sticky Header Style', 'deskly-core'),
      'options'        => 'posts',
			'placeholder' 	 => 'Select an option',
      'query_args'     => array(
        'post_type'      => 'wbx_header_builder',
        'posts_per_page' => -1,
      ),
    ),

	),
) );
/*
* ===========================
* ====  End Header Style ====
* ===========================
*/