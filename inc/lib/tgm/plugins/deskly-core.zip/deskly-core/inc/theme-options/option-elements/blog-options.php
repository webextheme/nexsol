<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ===============================
* ====  Start Header Setings ====
* ===============================
*/
CSF::createSection( $desklyThemeOption, array(
	'id'    => 'deskly_blog_page_options',
	'title' => esc_html__( 'Blog Page', 'deskly-core' ),
	'icon'  => 'fab fa-font-awesome-flag',
) );
/*
* =============================
* ====  End Header Setings ====
* =============================
*/

/*
* ====================================
* ====  Start Blog Page Settings =====
* ====================================
*/
CSF::createSection( $desklyThemeOption, array(
	'parent' => 'deskly_blog_page_options',
	'title'  => esc_html__( 'Blog Page', 'deskly-core' ),
	'id'     => 'deskly_blog_page',
	'icon'   => 'fas fa-bullhorn',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Blog Page', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'deskly_blog_banner_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Banner', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide / Show Banner.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_blog_title',
			'type'       => 'text',
			'title'      => esc_html__('Blog Page Title', 'deskly-core'),
			'dependency' => array( 'deskly_blog_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type blog Page title here.', 'deskly-core'),
		),
		array(
			'id'       => 'deskly_post_date',
			'type'     => 'switcher',
			'title'    => esc_html__('Show Post Date', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide / Show post date.', 'deskly-core'),
		),
		array(
			'id'       => 'deskly_show_excerpt',
			'type'     => 'switcher',
			'title'    => esc_html__('Show Excerpt', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide / Show Excerpt.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_excerpt_length',
			'type'       => 'number',
			'default' 	 => 36,
			'title'      => esc_html__('Excerpt Length Count', 'deskly-core'),
			'dependency' => array( 'deskly_blog_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type excerpt length count.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_show_comments',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Comments', 'deskly-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'deskly-core'),
			'text_off'   => esc_html__('No', 'deskly-core'),
			'desc'       => esc_html__('Hide / Show post comments.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_show_category',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Category Name', 'deskly-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'deskly-core'),
			'text_off'   => esc_html__('No', 'deskly-core'),
			'desc'       => esc_html__('Hide / Show post category name.', 'deskly-core'),
		),
		array(
			'id'       => 'deskly_post_author',
			'type'     => 'switcher',
			'title'    => esc_html__('Show Author Name', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide / Show post author name.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_show_pagination',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Pagination', 'deskly-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'deskly-core'),
			'text_off'   => esc_html__('No', 'deskly-core'),
			'desc'       => esc_html__('Hide / Show post category name.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_show_readmore',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Readmore Button', 'deskly-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'deskly-core'),
			'text_off'   => esc_html__('No', 'deskly-core'),
			'desc'       => esc_html__('Hide / Show post category name.', 'deskly-core'),
		),
	),
) );
/*
* ==================================
* ====  End Blog Page Settings =====
* ==================================
*/

/*
* ===========================================
* ====  Start Single Blog Post Settings =====
* ===========================================
*/
CSF::createSection( $desklyThemeOption, array(
	'parent' => 'deskly_blog_page_options',
	'title'  => esc_html__( 'Single Blog Post', 'deskly-core' ),
	'id'     => 'deskly_single_blog_post',
	'icon'   => 'fas fa-edit',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Single Blog Post', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'deskly_single_post_author',
			'type'     => 'switcher',
			'title'    => esc_html__('Post Author Name', 'deskly-core'),
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide or show author name on post details page.', 'deskly-core'),
			'default'  => true
		),
		array(
			'id'       => 'deskly_single_post_date',
			'type'     => 'switcher',
			'title'    => esc_html__('Post Date', 'deskly-core'),
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide or show date on post details page.', 'deskly-core'),
			'default'  => true
		),
		array(
			'id'       => 'deskly_single_post_comments',
			'type'     => 'switcher',
			'title'    => esc_html__('Post Comments', 'deskly-core'),
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide or show post comments on post details page.', 'deskly-core'),
			'default'  => true
		),
		array(
			'id'       => 'deskly_single_next_prev_post',
			'type'     => 'switcher',
			'title'    => esc_html__('Next/Prev Posts', 'deskly-core'),
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide or show Next and Prev post option.', 'deskly-core'),
			'default'  => true
		),
	),
) );
/*
* ===========================================
* ====  End Single Blog Post Settings =======
* ===========================================
*/

/*
* ============================================
* ====  Start Blog Archive Page Settings =====
* ============================================
*/
CSF::createSection( $desklyThemeOption, array(
	'parent' => 'deskly_blog_page_options',
	'title'  => esc_html__( 'Blog Archive Page', 'deskly-core' ),
	'id'     => 'deskly_blog_archive_page',
	'icon'   => 'fas fa-archive',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Blog Archive Page', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'deskly_archive_banner',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Banner', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Enable or disable archive page banner.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_archive_banner_title',
			'type'       => 'text',
			'title'      => esc_html__('Archive Page Banner Title', 'deskly-core'),
			'dependency' => array( 'deskly_archive_banner', '==', 'true' ),
			'desc'       => esc_html__('Type Archive Page Banner title here.', 'deskly-core'),
		),
		array(
			'id'       => 'deskly_archive_show_pagination',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Pagination', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Enable or disable archive Pagination.', 'deskly-core'),
		),
	),
) );
/*
* ============================================
* ====  End Blog Archive Page Settings =======
* ============================================
*/

/*
* ============================================
* ====  Start Search Page Settings =====
* ============================================
*/
CSF::createSection( $desklyThemeOption, array(
	'parent' => 'deskly_blog_page_options',
	'title'  => esc_html__( 'Search Page', 'deskly-core' ),
	'id'     => 'deskly_search_page',
	'icon'   => 'fas fa-search',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Search Page', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'deskly_search_banner',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Search Banner', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Enable or disable search page banner.', 'deskly-core'),
		),
		array(
			'id'       => 'deskly_search_show_pagination',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Search Pagination', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Enable or disable search Pagination.', 'deskly-core'),
		),
	),
) );
/*
* ============================================
* ====  End Blog Search Page Settings =======
* ============================================
*/