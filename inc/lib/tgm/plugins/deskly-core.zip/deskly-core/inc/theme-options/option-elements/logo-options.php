<?php
/*
* ===============================
* ===== START Logo Settings =====
* ===============================
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
CSF::createSection( $desklyThemeOption, array(
	'title'  => esc_html__( 'Logo Settings', 'deskly-core' ),
	'id'     => 'logo_settings',
	'icon'   => 'fas fa-dice-d6',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Logo Settings', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'site_logo_type',
			'type'     => 'button_set',
			'title'    => esc_html__( 'Site Logo Type', 'deskly-core' ),
			'subtitle' => esc_html__( 'Select site logo type', 'deskly-core' ),
			'options'  => [
					'text'  => esc_html__( 'Text', 'deskly-core' ),
					'image' => esc_html__( 'Image', 'deskly-core' ),
			],
			'default'  => 'image',
		),
		array(
			'id'         => 'site_text_logo',
			'type'       => 'text',
			'title'      => esc_html__( 'Text logo', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Type logo text', 'deskly-core' ),
			'default'    => esc_html__( 'Deskly', 'deskly-core' ),
			'dependency' => ['site_logo_type', '==', 'text'],
		),
		array(
			'id'       => 'main_logo',
			'type'     => 'media',
			'title'    => esc_html__( 'Main Logo', 'deskly-core' ),
			'subtitle' => esc_html__( 'Upload OR Select image for site logo', 'deskly-core' ),
			'library'    => 'image',
			'url'        => false,
			'default'    => [
					'url'       => get_template_directory_uri() . '/assets/images/logo-dark.svg',
					'thumbnail' => get_template_directory_uri() . '/assets/images/logo-dark.svg',
			],
			'dependency' => ['site_logo_type', '==', 'image'],
		),
		array(
			'id'      => 'deskly_main_logo_size',
			'type'    => 'slider',
			'title'   => esc_html__('Main Logo Size', 'deskly-core'),
			'output'   => '.deskly-site-logo img',
			'output_mode' => 'width',
			'min'     => 72,
			'max'     => 300,
			'step'    => 1,
			'unit'    => 'px',
		),
	),
) );

/*
* ===============================
* ====== End Logo Settings ======
* ===============================
*/