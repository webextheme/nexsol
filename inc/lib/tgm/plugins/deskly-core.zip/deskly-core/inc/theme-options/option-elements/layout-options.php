<?php
/*
* =================================
* ===== START Layout Settings =====
* =================================
*/

if ( !defined( 'ABSPATH' ) ) {
		exit; // Exit if accessed directly
}
CSF::createSection( $desklyThemeOption, array(
	'title'  => esc_html__( 'Layout Sidebar', 'deskly-core' ),
	'id'     => 'layout_options',
	'icon'   => 'fas fa-th-large',
	'fields' => array(

		// Blog Layout
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Blog Layout', 'deskly-core' ) . '</h3>',
		),
		array(
      'id'       => 'blog_layout',
      'type'     => 'palette',
      'title'    => esc_html__('Choose Layout', 'deskly-core'),
      'options'  => array(
        'left-sidebar'   => array('#cccccc', '#eeeeee', '#eeeeee'),
        'full-width'     => array('#dddddd', '#dddddd', '#dddddd'),
        'right-sidebar'  => array('#eeeeee', '#eeeeee', '#cccccc'),
      ),
      'default'    => 'right-sidebar',
    ),

		// Archive Layout
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Archive Layout', 'deskly-core' ) . '</h3>',
		),
		array(
      'id'       => 'archive_layout',
      'type'     => 'palette',
      'title'    => esc_html__('Choose Layout', 'deskly-core'),
      'options'  => array(
        'left-sidebar'   => array('#cccccc', '#eeeeee', '#eeeeee'),
        'full-width'     => array('#dddddd', '#dddddd', '#dddddd'),
        'right-sidebar'  => array('#eeeeee', '#eeeeee', '#cccccc'),
      ),
      'default'    => 'right-sidebar',
    ),

		// Single Blog Layout
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Single Blog Layout', 'deskly-core' ) . '</h3>',
		),
		array(
      'id'       => 'single_blog_layout',
      'type'     => 'palette',
      'title'    => esc_html__('Choose Layout', 'deskly-core'),
      'options'  => array(
        'left-sidebar'   => array('#cccccc', '#eeeeee', '#eeeeee'),
        'full-width'     => array('#dddddd', '#dddddd', '#dddddd'),
        'right-sidebar'  => array('#eeeeee', '#eeeeee', '#cccccc'),
      ),
      'default'    => 'right-sidebar',
    ),

		// Workspaces Layout
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Workspaces Layout', 'deskly-core' ) . '</h3>',
		),
		array(
      'id'       => 'workspaces_layout',
      'type'     => 'palette',
      'title'    => esc_html__('Choose Layout', 'deskly-core'),
      'options'  => array(
        'left-sidebar'   => array('#cccccc', '#eeeeee', '#eeeeee'),
        'full-width'     => array('#dddddd', '#dddddd', '#dddddd'),
        'right-sidebar'  => array('#eeeeee', '#eeeeee', '#cccccc'),
      ),
      'default'    => 'right-sidebar',
    ),

		// Workspaces Archive Layout
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Workspaces Archive Layout', 'deskly-core' ) . '</h3>',
		),
		array(
      'id'       => 'workspaces_archive_layout',
      'type'     => 'palette',
      'title'    => esc_html__('Choose Layout', 'deskly-core'),
      'options'  => array(
        'left-sidebar'   => array('#cccccc', '#eeeeee', '#eeeeee'),
        'full-width'     => array('#dddddd', '#dddddd', '#dddddd'),
        'right-sidebar'  => array('#eeeeee', '#eeeeee', '#cccccc'),
      ),
      'default'    => 'right-sidebar',
    ),

	),
) );

/*
* =================================
* ====== End Layout Settings ======
* =================================
*/