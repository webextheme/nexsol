<?php
/*
* ===============================
* ===== START Logo Settings =====
* ===============================
*/

if ( !defined( 'ABSPATH' ) ) {
		exit; // Exit if accessed directly
}
/*
* ============================
* ====  Star Color Control ====
* ============================
*/
CSF::createSection( $desklyThemeOption, array(
	'title'  => 'Color Control',
	'id'     => 'deskly_color_control',
	'icon'   => 'fas fa-palette',
	'fields' => array(
		array(  //nav bar one start
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Color Settings', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'          => 'webex_primary_color',
			'type'        => 'color',
			'title'       => 'Primery Color',
			'output' => ':root',
			'output_mode' => '--webex-primary-color',
		),
		array(
			'id'          => 'webex_primary_color2',
			'type'        => 'color',
			'title'       => 'Primery Color2',
			'output' => ':root',
			'output_mode' => '--webex-primary-color2',
		),
		array(
			'id'          => 'webex_primary_color3',
			'type'        => 'color',
			'title'       => 'Primery Color3',
			'output' => ':root',
			'output_mode' => '--webex-primary-color3',
		),
		array(
			'id'          => 'webex_primary_color4',
			'type'        => 'color',
			'title'       => 'Primery Color4',
			'output' => ':root',
			'output_mode' => '--webex-primary-color4',
		),
		array(
			'id'          => 'webex_secondary_color',
			'type'        => 'color',
			'title'       => 'Secondary Color',
			'output' => ':root',
			'output_mode' => '--webex-secondary-color',
		),
		array(
			'id'          => 'webex_secondary_color2',
			'type'        => 'color',
			'title'       => 'Secondary Color2',
			'output' => ':root',
			'output_mode' => '--webex-secondary-color2',
		),
		array(
			'id'          => 'webex_secondary_color3',
			'type'        => 'color',
			'title'       => 'Secondary Color3',
			'output' => ':root',
			'output_mode' => '--webex-secondary-color3',
		),
		array(
			'id'          => 'body_font_color',
			'type'        => 'color',
			'title'       => 'Body Font Color',
			'output' => ':root',
			'output_mode' => '--body-font-color',
		),
		array(
			'id'          => 'heading_font_color',
			'type'        => 'color',
			'title'       => 'Heading Font Color',
			'output' => ':root',
			'output_mode' => '--heading-font-color',
		),
		array(
			'id'          => 'default_header_sticky_bg_color',
			'type'        => 'color',
			'title'       => 'Transparent Header Sticky Background Color',
			'output' => ':root',
			'output_mode' => '--default-header-sticky-bg-color',
		),
	),
	) );

/*
* ===============================
* ====== End Color Control ======
* ===============================
*/