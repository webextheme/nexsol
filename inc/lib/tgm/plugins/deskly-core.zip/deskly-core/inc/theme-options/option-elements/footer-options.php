<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/*
* ============================
* ====  Star Footer Styles ====
* ============================
*/
	CSF::createSection( $desklyThemeOption, array(
	'id' => 'deskly_footer_settings',
	'title'  => esc_html__( 'Footer Settings', 'deskly-core' ),
	'icon'   => 'fas fa-ruler-horizontal',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Choose Footer Styles', 'deskly-core' ) . '</h3>',
		),

		array(
			'id'       => 'footer_layout_style',
			'type'        => 'select',
			'title'    => esc_html__( 'Select Style', 'deskly-core' ),
			'options'     => array(
        'footer-default' => esc_html__('Default Footer', 'deskly-core'),
        'footer-custom'  => esc_html__('Elementor Footers', 'deskly-core'),
				'footer-one' => esc_html__('Footer Style1', 'deskly-core'),
				'footer-two' => esc_html__('Footer Style2', 'deskly-core'),
			),
			'default'  => 'footer-default',
			'subtitle' => esc_html__( 'Choose Your Footer Style For Global', 'deskly-core' ),
		),

    // Footer Builder Options
		array(
      'id'             => 'deskly_builder_deta',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor Footer Style', 'deskly-core'),
      'options'        => 'posts',
      'query_args'     => array(
        'post_type'      => 'wbx_footer_builder',
        'posts_per_page' => -1,
      ),
      'dependency' => array('footer_layout_style', '==', 'footer-custom'),
    ),

		array(
			'id'         => 'deskly_footer_text_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Text Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change footer text color here', 'deskly-core' ),
			'output'     => '.footer, .footer a',
			'output_mode' => 'color',
		),
		array(
			'id'         => 'deskly_footer_background_settings',
			'type'       => 'background',
			'title'      => esc_html__( 'Footer Background Options', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Add Background color or Image for footer ', 'deskly-core' ),
			'output'     => '.footer .footer-main-area',
		),
		array(
			'id'      => 'deskly_footer_background_overlay',
			'type'    => 'color',
			'title'   => esc_html__('Footer Background Overlay', 'deskly-core'),
			'output'   => '.footer .footer-main-area:after',
			'output_mode' => 'background',
		),
		array(
			'id'            => 'deskly_copyright_text',
			'type'          => 'wp_editor',
			'title'         => esc_html__( 'Copyright Text', 'deskly-core' ),
			'subtitle'      => esc_html__( 'Site copyright text', 'deskly-core' ),
			'default'       => esc_html__( 'Copyright by WebexTheme © 2025. All rights reserved', 'deskly-core' ),
			'desc'          => esc_html__( 'Place copyright text here.', 'deskly-core' ),
			'tinymce'       => true,
			'quicktags'     => true,
			'media_buttons' => false,
			'height'        => '100px',
		),
		array(
			'id'         => 'deskly_copyright_background_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Copyright Background Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change copyright background color here', 'deskly-core' ),
			'output'     => '.footer-copyright-area',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'deskly_copyright_text_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Copyright Text Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change copyright text color here', 'deskly-core' ),
			'output'     => '.footer-copyright-area .copyright-text',
			'output_mode' => 'color',
		),
		array(
			'id'         => 'deskly_newsletter_background_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Newsletter Background Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change newsletter background color here', 'deskly-core' ),
			'output'     => '.footer-widget .newsletter-from .email input[type="email"]',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'deskly_footer_social_background_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Background Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change footer social background color here', 'deskly-core' ),
			'output'     => '.footer-widget .social-list li a',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'deskly_footer_social_background_hover_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Background Hover Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change footer social background hover color here', 'deskly-core' ),
			'output'     => '.footer-widget .social-list li a:hover',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'deskly_footer_social_text_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Text Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change footer social text color here', 'deskly-core' ),
			'output'     => '.footer-widget .social-list li a',
			'output_mode' => 'color',
		),
		array(
			'id'         => 'deskly_footer_social_text_hover_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Text Hover Color', 'deskly-core' ),
			'subtitle'   => esc_html__( 'Change footer social text hover color here', 'deskly-core' ),
			'output'     => '.footer-widget .social-list li a:hover',
			'output_mode' => 'color',
		),
	),
	) );
/*
* ============================
* ====  End Footer Styles ====
* ============================
*/
