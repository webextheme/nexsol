<?php

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

//
// Metabox of the PAGE
// Set a unique slug-like ID
//
$desklymetabox = 'deskly_metabox';

/*
* ===========================
* ====  Create a metabox ====
* ===========================
*/
CSF::createMetabox( $desklymetabox, array(
	'title'        => 'Deskly Page Meta Options',
	'post_type'    => array( 'page', 'post', 'webex_workspaces' ),
	'show_restore' => true,
	'theme'     => 'dark',
) );


/*
* ====================================
* =====  Dark/Ligh Moode metabox =====
* ====================================
*/
CSF::createSection( $desklymetabox, array(
	'title'  => esc_html__( 'Dark Mood', 'deskly-core' ),
	'icon'   => 'far fa-file-alt',
	'fields' => array(
		array(
			'id'      => 'layout_mode',
			'type'    => 'button_set',
			'title'   => esc_html__( 'Layout Mode (This Page)', 'deskly' ),
			'options' => array(
				'default' => 'Default (use global setting)',
				'dark'    => 'Dark',
				'light'   => 'Light',
			),
			'default' => 'default',
		),
	),
) );

/*
* ================================
* ====  Create Header metabox ====
* ================================
*/
CSF::createSection( $desklymetabox, array(
	'title'  => esc_html__( 'Header Options', 'deskly-core' ),
	'icon'   => 'far fa-window-maximize',
	'fields' => array(

		array(
			'id'          => 'custom_header_builder_solid',
			'type'        => 'select',
			'title'       => esc_html__( 'Solid Header (Override)', 'deskly-core' ),
			'options'     => 'posts',
			'query_args'  => array(
				'post_type'      => 'wbx_header_builder',
				'posts_per_page' => -1,
			),
			'placeholder' => esc_html__( 'Default (use Theme Option)', 'deskly-core' ),
		),

		array(
			'id'          => 'custom_header_builder_transparent',
			'type'        => 'select',
			'title'       => esc_html__( 'Transparent Header (Override)', 'deskly-core' ),
			'options'     => 'posts',
			'query_args'  => array(
				'post_type'      => 'wbx_header_builder',
				'posts_per_page' => -1,
			),
			'placeholder' => esc_html__( 'Default (use Theme Option)', 'deskly-core' ),
		),

		array(
			'id'          => 'custom_header_builder_sticky',
			'type'        => 'select',
			'title'       => esc_html__( 'Sticky Header (Override)', 'deskly-core' ),
			'options'     => 'posts',
			'query_args'  => array(
				'post_type'      => 'wbx_header_builder',
				'posts_per_page' => -1,
			),
			'placeholder' => esc_html__( 'Default (use Theme Option)', 'deskly-core' ),
		),

	),
) );

/*
* ================================
* ====  Create Footer metabox ====
* ================================
*/
CSF::createSection( $desklymetabox, array(
	'title'  => esc_html__( 'Footer Options', 'deskly-core' ),
	'icon'   => 'fas fa-ruler-horizontal',
	'fields' => array(

		array(
			'id'      => 'meta_footer_layout',
			'type'    => 'button_set',
			'title'   => esc_html__('Custom Footer', 'deskly-core'),
			'options' => array(
				'yes'   => esc_html__('Yes', 'deskly-core'),
				'no'    => esc_html__('No', 'deskly-core'),
			),
			'default' => 'no',
		),

		array(
			'id'          => 'meta_footer_style',
			'type'        => 'select',
			'title'       => esc_html__( 'Select Footer Style', 'deskly-core' ),
			'options'     => array(
				'footer-one' => esc_html__('Footer Style1', 'deskly-core'),
				'footer-two' => esc_html__('Footer Style2', 'deskly-core'),
        'footer-custom'  => esc_html__('Elementor Footers', 'deskly-core'),
			),
			'dependency'  => array( 'meta_footer_layout', '==', 'yes' ),
		),

    // Footer Builder Options
		array(
      'id'             => 'deskly_builder_deta',
      'type'           => 'select',
      'title'          => esc_html__('Choose Elementor Footers', 'deskly-core'),
      'options'        => 'posts',
      'query_args'     => array(
        'post_type'      => 'wbx_footer_builder',
        'posts_per_page' => -1,
      ),
      'dependency'  => array(
        array('meta_footer_style', '==', 'footer-custom'),
        array('meta_footer_layout', '==', 'yes'),
      ),
    ),

	),
) );

/*
* ====================================
* ====  Create Breadcrumb metabox ====
* ====================================
*/
CSF::createSection( $desklymetabox, array(
	'title'  => esc_html__( 'Page Title', 'deskly-core' ),
	'icon'   => 'far fa-file-alt',
	'fields' => array(
		array(
			'id'       => 'deskly_meta_enable_page_title',
			'type'     => 'switcher',
			'title'    => esc_html__( 'Enable Page Title', 'deskly-core' ),
			'text_on'  => esc_html__( 'Yes', 'deskly-core' ),
			'text_off' => esc_html__( 'No', 'deskly-core' ),
			'default'  => true,
			'desc'     => esc_html__( 'Enable or disable banner.', 'deskly-core' ),
		),
		array(
			'id'      => 'deskly_meta_page_title_solid_background_options',
			'type'    => 'color',
			'title'   => esc_html__('Page Title Solid Background Color', 'deskly-core'),
			'output'   => '.page-title-section',
			'output_mode' => 'background',
			'dependency'  => array( 'deskly_meta_enable_page_title', '==', 'true' ),
		),
		array(
			'id'      => 'deskly_meta_page_title_background_options',
			'type'    => 'background',
			'title'   => esc_html__('Page Title Background Image', 'deskly-core'),
			'output'   => '.page-title-section',
			'dependency'  => array( 'deskly_meta_enable_page_title', '==', 'true' ),
		),
		array(
			'id'      => 'deskly_meta_page_title_background_overlay',
			'type'    => 'color',
			'title'   => esc_html__('Page Title Background Overlay', 'deskly-core'),
			'output'   => '.page-title-section:after',
			'output_mode' => 'background',
			'dependency'  => array( 'deskly_meta_enable_page_title', '==', 'true' ),
		),
		array(
			'id'          => 'deskly_meta_page_title_spacing',
			'type'        => 'spacing',
			'title'       => esc_html__('Page Title Spacing', 'deskly-core'),
			'subtitle'       => esc_html__('Adjust Page Title Area Spacing', 'deskly-core'),
			'output'      => '.page-title-section',
			'output_mode' => 'padding',
			'dependency'  => array( 'deskly_meta_enable_page_title', '==', 'true' ),
		),
	),
) );