<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ===============================
* ====  Start Header Setings ====
* ===============================
*/
CSF::createSection( $desklyThemeOption, array(
	'id'    => 'deskly_workspace_page_options',
	'title' => esc_html__( 'Workspace Page', 'deskly-core' ),
	'icon'  => 'fab fa-font-awesome-flag',
) );
/*
* =============================
* ====  End Header Setings ====
* =============================
*/

/*
* ====================================
* ====  Start Workspace Page Settings =====
* ====================================
*/
CSF::createSection( $desklyThemeOption, array(
	'parent' => 'deskly_workspace_page_options',
	'title'  => esc_html__( 'Single Workspace', 'deskly-core' ),
	'id'     => 'deskly_workspace_page',
	'icon'   => 'fas fa-bullhorn',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Workspace Single Page', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'workspace_label',
			'type'     => 'text',
			'title'       => esc_html__( 'Workspace Label', 'deskly-core' ),
			'placeholder' => esc_html__( 'Workspaces', 'deskly-core' ),
			'desc'        => esc_html__( 'Rename the Custom Post Type.', 'deskly-core' ),
		),
		array(
			'id'       => 'workspace_slug',
			'type'     => 'text',
			'title'       => esc_html__( 'Workspace Slug', 'deskly-core' ),
			'placeholder' => esc_html__( 'workspace slug', 'deskly-core' ),
			'desc'        => esc_html__( 'You can customize the permalink structure (site_domain/post_type_slug/post_slug) by changing the post type slug (post_type_slug) from here. Don\'t forget to save the permalinks settings from Settings > Permalinks after changing the slug value.', 'deskly-core' ),
		),
		array(
			'id'       => 'workspace_cats_slug',
			'type'     => 'text',
			'title'       => esc_html__( 'Workspace Category Slug', 'deskly-core' ),
			'placeholder' => esc_html__( 'Workspace Category Slug', 'deskly-core' ),
			'desc'        => esc_html__( 'You can customize the permalink structure (site_domain/post_category_slug/) by changing from here. Don\'t forget to save the permalinks settings from Settings > Permalinks after changing the slug value.', 'deskly-core' ),
		),
		array(
			'id'       => 'deskly_workspace_banner_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Banner', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide / Show Banner.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_workspace_title',
			'type'       => 'text',
			'title'      => esc_html__('Workspace Page Title', 'deskly-core'),
			'dependency' => array( 'deskly_workspace_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type workspace Page title here.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_workspace_home_title',
			'type'       => 'text',
			'title'      => esc_html__('Workspace Page Home Title', 'deskly-core'),
			'dependency' => array( 'deskly_workspace_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type workspace Page Home title here.', 'deskly-core'),
		),
		array(
			'id'       => 'deskly_workspace_related_post_show_hide',
			'type'     => 'switcher',
			'title'    => esc_html__('Related Posts', 'deskly-core'),
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide or show Next and Prev post option.', 'deskly-core'),
			'default'  => true
		),
		array(
			'id'         => 'deskly_related_workspace_title',
			'type'       => 'text',
			'title'      => esc_html__('Related Workspace Title', 'deskly-core'),
			'dependency' => array( 'deskly_workspace_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type related workspace title here.', 'deskly-core'),
			'dependency' => array( 'deskly_workspace_related_post_show_hide', '==', 'true' ),
		),
		array(
			'id'       => 'deskly_workspace_single_next_prev_post',
			'type'     => 'switcher',
			'title'    => esc_html__('Next/Prev Posts', 'deskly-core'),
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide or show Next and Prev post option.', 'deskly-core'),
			'default'  => false
		),
	),
) );
/*
* ==================================
* ====  End Workspace Page Settings =====
* ==================================
*/


/*
* ===========================================
* ====  Start Archive Workspace Post Settings =====
* ===========================================
*/
CSF::createSection( $desklyThemeOption, array(
	'parent' => 'deskly_workspace_page_options',
	'title'  => esc_html__( 'Archive Workspace', 'deskly-core' ),
	'id'     => 'deskly_archive_workspace_post',
	'icon'   => 'fas fa-edit',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Workspace Archive Page', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'deskly_archive_workspace_banner',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Banner', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Enable or disable archive page banner.', 'deskly-core'),
		),
		array(
			'id'         => 'deskly_archive_workspace_banner_title',
			'type'       => 'text',
			'title'      => esc_html__('Archive Page Banner Title', 'deskly-core'),
			'dependency' => array( 'deskly_archive_workspace_banner', '==', 'true' ),
			'desc'       => esc_html__('Type Archive Page Banner title here.', 'deskly-core'),
		),
		array(
			'id'       => 'deskly_archive_workspace_show_pagination',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Pagination', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Enable or disable archive Pagination.', 'deskly-core'),
		),
	),
) );
/*
* ===========================================
* ====  End Archive Workspace Post Settings =======
* ===========================================
*/