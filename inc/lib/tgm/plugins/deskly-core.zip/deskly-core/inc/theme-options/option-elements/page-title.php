<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ====================================
* ====  Start Typography Settings ====
* ====================================
*/
CSF::createSection( $desklyThemeOption, array(
	'title'  => esc_html__( 'Page Title', 'deskly-core' ),
	'id'     => 'deskly_page_title_options',
	'icon'   => 'far fa-file-alt',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Page Title Options', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'       => 'deskly_page_title_banner_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Banner', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide / Show Banner.', 'deskly-core'),
		),
		array(
			'id'      => 'deskly_page_title_background_options',
			'type'    => 'background',
			'title'   => esc_html__('Page Title Background Image', 'deskly-core'),
			'output'   => '.page-title-section',
			'output_mode' => 'background',
			'dependency' => array( 'deskly_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'      => 'deskly_page_title_background_overlay',
			'type'    => 'color',
			'title'   => esc_html__('Page Title Background Overlay', 'deskly-core'),
			'output'   => '.page-title-section:after',
			'output_mode' => 'background',
			'dependency' => array( 'deskly_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'      => 'deskly_page_title_background_overlay_opacity',
			'type'    => 'slider',
			'title'   => esc_html__('Page Title Background Overlay Opacity', 'deskly-core'),
			'output'   => '.page-title-section:after',
			'output_mode' => 'opacity',
			'min'     => 0,
			'max'     => 1,
			'step'    => .01,
			'default' => 0.75,
			'unit'    => ' ',
			'dependency' => array( 'deskly_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'       => 'deskly_page_title_color',
			'type'     => 'color',
			'title'    => esc_html__('Page Title Color', 'deskly-core'),
			'output'   => '.page-title-section .breadcrumb-area .page-title',
			'output_mode' => 'color',
			'desc'     => esc_html__('You can change default page title color.', 'deskly-core'),
			'dependency' => array( 'deskly_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'          => 'deskly_page_title_spacing',
			'type'        => 'spacing',
			'title'       => esc_html__('Page Title Spacing', 'deskly-core'),
			'subtitle'       => esc_html__('Adjust Page Title Area Spacing', 'deskly-core'),
			'output'      => '.page-title-section',
			'output_mode' => 'padding',
			'dependency' => array( 'deskly_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'       => 'deskly_page_title_breadcrumb_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Breadcrumb', 'deskly-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'deskly-core'),
			'text_off' => esc_html__('No', 'deskly-core'),
			'desc'     => esc_html__('Hide / Show Breadcrumb.', 'deskly-core'),
			'dependency' => array( 'deskly_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'       => 'deskly_breadcrumb_text_color',
			'type'     => 'color',
			'title'    => esc_html__('Breadcrumb Text Color', 'deskly-core'),
			'output'   => array('.page-title-section .breadcrumb-area .breadcrumbs-link li.active'),
			'output_mode' => 'color',
			'subtitle' => esc_html__('Breadcrumb text color', 'deskly-core'),
			'desc'     => esc_html__('You can change default breadcrumb Text color.', 'deskly-core'),
			'dependency' => array(
				array('deskly_page_title_banner_enable', '==', 'true'),
				array('deskly_page_title_breadcrumb_enable', '==', 'true'),
			),
		),
		array(
			'id'       => 'deskly_breadcrumb_link_text_color',
			'type'     => 'link_color',
			'title'    => esc_html__('Breadcrumb Link Text Color', 'deskly-core'),
			'output'   => array('.page-title-section .breadcrumb-area .breadcrumbs-link li a'),
			'output_mode' => 'color',
			'subtitle' => esc_html__('Breadcrumb Link color', 'deskly-core'),
			'desc'     => esc_html__('You can change default breadcrumb link Text normal and hover color.', 'deskly-core'),
			'dependency' => array(
				array('deskly_page_title_banner_enable', '==', 'true'),
				array('deskly_page_title_breadcrumb_enable', '==', 'true'),
			),
		),
		array(
			'id'       => 'deskly_breadcrumb_arrow_color',
			'type'     => 'color',
			'title'    => esc_html__('Breadcrumb Arrow Color', 'deskly-core'),
			'output'   => array('.page-title-section .breadcrumb-area .breadcrumbs-link li:after'),
			'output_mode' => 'color',
			'subtitle' => esc_html__('Breadcrumb arrow color', 'deskly-core'),
			'desc'     => esc_html__('You can change default breadcrumb arrow color.', 'deskly-core'),
			'dependency' => array(
				array('deskly_page_title_banner_enable', '==', 'true'),
				array('deskly_page_title_breadcrumb_enable', '==', 'true'),
			),
		),
	),
) );
/*
* ==================================
* ====  End Typography Settings ====
* ==================================
*/
