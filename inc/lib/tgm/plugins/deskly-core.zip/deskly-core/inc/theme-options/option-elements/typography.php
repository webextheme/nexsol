<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ====================================
* ====  Start Typography Settings ====
* ====================================
*/
CSF::createSection( $desklyThemeOption, array(
	'title'  => esc_html__( 'Typography', 'deskly-core' ),
	'id'     => 'deskly_typography_options',
	'icon'   => 'fa fa-font',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Body', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'     => 'deskly_body_typography',
			'type'   => 'typography',
			'output' => 'body',
		),
		array(
			'type'    => 'submessage',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'All Headings', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'     => 'deskly_all_headings_typography',
			'type'   => 'typography',
			'output' => array('h1,h2,h3,h4,h5,h6'),
		),
		array(
			'type'       => 'submessage',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Heading (H1 - H6)', 'deskly-core' ) . '</h3>',
		),
		array(
			'id'           => 'deskly_h1_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H1', 'deskly-core' ),
			'output'       => 'h1',
			'subtitle'     => esc_html__( 'Set heading H1 typography.', 'deskly-core' ),
		),
		array(
			'id'           => 'deskly_h2_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H2', 'deskly-core' ),
			'output'       => 'h2',
			'subtitle'     => esc_html__( 'Set heading H2 typography.', 'deskly-core' ),
		),
		array(
			'id'           => 'deskly_h3_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H3', 'deskly-core' ),
			'output'       => 'h3',
			'subtitle'     => esc_html__( 'Set heading H3 typography.', 'deskly-core' ),
		),
		array(
			'id'           => 'deskly_h4_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H4', 'deskly-core' ),
			'output'       => 'h4',
			'subtitle'     => esc_html__( 'Set heading H4 typography.', 'deskly-core' ),
		),
		array(
			'id'           => 'deskly_h5_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H5', 'deskly-core' ),
			'output'       => 'h5',
			'subtitle'     => esc_html__( 'Set heading H5 typography.', 'deskly-core' ),
		),
		array(
			'id'           => 'deskly_h6_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H6', 'deskly-core' ),
			'output'       => 'h6',
			'subtitle'     => esc_html__( 'Set heading H6 typography.', 'deskly-core' ),
		),
	),
) );
/*
* ==================================
* ====  End Typography Settings ====
* ==================================
*/
