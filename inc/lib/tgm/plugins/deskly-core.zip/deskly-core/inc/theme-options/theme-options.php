<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.

  /*
  * ====================================
  * ====  Set a unique slug like ID ====
  * ====================================
  */
  $desklyThemeOption = 'deskly_Theme_Option';

  /*
  * =========================
  * ====  Create options ====
  * =========================
  */
  CSF::createOptions( $desklyThemeOption, array(
    'framework_title'         => esc_html__( 'Deskly Theme Options', 'deskly-core' ),
    'menu_title'              => esc_html__( 'Deskly Options', 'deskly-core' ),
    'menu_slug'               => 'deskly-options',
    'menu_parent'             => 'themes.php',
    'show_in_customizer'      => true,
    'admin_bar_menu_priority' => 50,
    'menu_position'           => 20,
    'class'                   => 'deskly-theme-option-wrapper',
    'menu_icon'               => 'dashicons-admin-generic',
    'admin_bar_menu_icon'     => 'dashicons-admin-generic',
  ) );

  /*
  * ===========================
  * ====  Create sections  ====
  * ===========================
  */
  require_once 'option-elements/general-options.php';
  require_once 'option-elements/dark-mood.php';
  require_once 'option-elements/logo-options.php';
  require_once 'option-elements/header-options.php';
  require_once 'option-elements/footer-options.php';
  require_once 'option-elements/mobile-menu-sidebar-options.php';
  require_once 'option-elements/page-title.php';
  require_once 'option-elements/layout-options.php';
  require_once 'option-elements/typography.php';
  require_once 'option-elements/color-options.php';
  require_once 'option-elements/blog-options.php';
  require_once 'option-elements/workspace-options.php';
  require_once 'option-elements/404-options.php';

  /*
  * ===========================
  * ====  Field: backup    ====
  * ===========================
  */
  CSF::createSection( $desklyThemeOption, array(
    'title'       => esc_html__( 'Backup', 'deskly-core' ),
    'icon'        => 'fas fa-shield-alt',
    'description' => wp_kses_post( __( 'Visit documentation for more details on this field: <a href="http://codestarframework.com/documentation/#/fields?id=backup" target="_blank">Field: backup</a>', 'deskly-core' ) ),
    'fields'      => array(
      array(
        'type' => 'backup',
      ),
    ),
  ) );


