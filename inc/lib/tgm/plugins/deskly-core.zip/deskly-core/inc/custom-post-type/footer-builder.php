<?php

/**
 * Create Footer Post Type
 */
function webex_core_footer_post_type() {
	$labels = [
		'name'                  => _x('Footer Builders', 'Post type general name', 'deskly-core'),
		'singular_name'         => _x('Footer Builder', 'Post type singular name', 'deskly-core'),
		'add_new'               => __('Add New Footer', 'deskly-core'),
		'all_items'             => __('All Footers', 'deskly-core'),
	];

	$args = [
		'labels'             => $labels,
		'public'             => true,
		'rewrite' => array(
			'slug' => 'wbx_footer_builder',
			'with_front' => true
		),
		'menu_position'      => 32,
		'menu_icon' 				 => DESKLY_ADDON_ASSETS .'/images/cpt-icon.png',
		'supports'           => ['title', 'editor'],
	];

	register_post_type('wbx_footer_builder', $args);
}

add_action('init', 'webex_core_footer_post_type');
