<?php

/**
 * Create Header Post Type
 */
function webex_core_header_post_type() {
	$labels = [
		'name'                  => _x('Header Builders', 'Post type general name', 'deskly-core'),
		'singular_name'         => _x('Header Builder', 'Post type singular name', 'deskly-core'),
		'add_new'               => __('Add New Header', 'deskly-core'),
		'all_items'             => __('All Headers', 'deskly-core'),
	];

	$args = [
		'labels'             => $labels,
		'public'             => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_rest'       => true, // Elementor + Gutenberg REST support
		'rewrite' => [
			'slug'       => 'wbx_header_builder',
			'with_front' => true
		],
		'menu_position'      => 31,
		'menu_icon'          => DESKLY_ADDON_ASSETS . '/images/cpt-icon.png',
		'supports'           => ['title', 'editor', 'elementor'], // elementor support যোগ করা হলো
	];

	register_post_type('wbx_header_builder', $args);
}
add_action('init', 'webex_core_header_post_type');

add_action( 'elementor/init', function() {
	add_post_type_support( 'wbx_header_builder', 'elementor' );
});
