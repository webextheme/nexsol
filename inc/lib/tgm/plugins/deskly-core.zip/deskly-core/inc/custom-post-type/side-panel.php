<?php

/**
 * Create Side Panel Post Type
 */
function webex_core_side_panel_post_type() {
	$labels = [
		'name'                  => _x('Side Panels', 'Post type general name', 'deskly-core'),
		'singular_name'         => _x('Side Panel', 'Post type singular name', 'deskly-core'),
		'add_new'               => __('Add New', 'deskly-core'),
		'all_items'             => __('All Items', 'deskly-core'),
	];

	$args = [
		'labels'             => $labels,
		'public'             => true,
		'rewrite' => array(
			'slug' => 'wbx_side_panel',
			'with_front' => true
		),
		'menu_position'      => 34,
		'menu_icon' 				 => DESKLY_ADDON_ASSETS .'/images/cpt-icon.png',
		'supports'           => ['title', 'editor'],
	];

	register_post_type('wbx_side_panel', $args);
}

add_action('init', 'webex_core_side_panel_post_type');
