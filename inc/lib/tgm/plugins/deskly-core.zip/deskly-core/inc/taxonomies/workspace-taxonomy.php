<?php
/**
 * Workspace Taxonomy
 */
function deskly_workspace_taxonomy() {
	$labels = array(
		'name'              => _x( 'Workspace Categories', 'taxonomy general name', 'deskly-core' ),
		'singular_name'     => _x( 'Workspace Category', 'taxonomy singular name', 'deskly-core' ),
		'menu_name'         => __( 'Workspace Categories', 'deskly-core' ),
		'search_items'      => __( 'Search Categories', 'deskly-core' ),
		'all_items'         => __( 'All Categories', 'deskly-core' ),
		'parent_item'       => __( 'Parent Category', 'deskly-core' ),
		'parent_item_colon' => __( 'Parent Category:', 'deskly-core' ),
		'edit_item'         => __( 'Edit Category', 'deskly-core' ),
		'update_item'       => __( 'Update Category', 'deskly-core' ),
		'add_new_item'      => __( 'Add New Category', 'deskly-core' ),
		'new_item_name'     => __( 'New Category Name', 'deskly-core' ),
	);
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'show_in_rest'      => true,
		'rewrite'            => ['slug' => 'deskly-workspace-texonomy'],
	);
	register_taxonomy( 'webex_workspaces_cats', array('webex_workspaces'), $args );
}
add_action('init', 'deskly_workspace_taxonomy');