<?php
/**
 * Custom Icon Integration for Codestar Framework
 * Loads Webexbase custom icon font before Font Awesome
 *
 * @package Deskly
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

/**
 * Register custom icons for Codestar Framework
 */
add_action( 'init', function() {
  add_filter( 'csf_add_icons', 'deskly_register_csf_icons', 5 );
  add_filter( 'csf_field_icon_add_icons', 'deskly_register_csf_icons', 5 );
});

function deskly_register_csf_icons( $icons ) {
  $json_file = WP_PLUGIN_DIR . '/deskly-elementor-core/assets/fonts/webexbaseicon/webexbaseicon.json';

  if ( file_exists( $json_file ) ) {
    $json_data = json_decode( file_get_contents( $json_file ), true );

    if ( ! empty( $json_data['icons'] ) && is_array( $json_data['icons'] ) ) {
      // Prepend Webexbase icons before Font Awesome
      $webexbase_icons = [
        'webexbase-icons' => [
          'title' => esc_html__( 'Webexbase Icons', 'deskly-core' ),
          'icons' => $json_data['icons'],
        ],
      ];

      // Merge with other icon sets (Webexbase first)
      $icons = array_merge( $webexbase_icons, $icons );
    }
  }

  return $icons;
}

/**
 * Enqueue Webexbase icon CSS
 */
add_action( 'admin_enqueue_scripts', 'deskly_enqueue_custom_icons' );
add_action( 'wp_enqueue_scripts', 'deskly_enqueue_custom_icons' );

function deskly_enqueue_custom_icons() {
  $css_file = plugin_dir_path( __DIR__ ) . 'deskly-elementor-core/assets/fonts/webexbaseicon/style.css';

  if ( file_exists( $css_file ) ) {
    wp_enqueue_style(
      'webexbase-icons',
      plugins_url( 'deskly-elementor-core/assets/fonts/webexbaseicon/style.css', dirname( __FILE__ ) ),
      [],
      '1.0'
    );
  }
}
