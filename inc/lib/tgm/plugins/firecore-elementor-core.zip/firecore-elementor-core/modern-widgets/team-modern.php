<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;

class FIRECORE_Modern_Team_Members extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-modern-team-members';
	}

	public function get_title() {
		return esc_html__( 'Modern Team Members', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Team Members Content ===== */
		$this->start_controls_section(
			'section_content_modern_member',
			[
				'label' => esc_html__( 'Modern Team Members', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_team_styles',
			[
				'label' => __( 'Team Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'modern_team_image',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$repeater = new Repeater();
		$repeater->start_controls_tabs( 'tab_member' );
		$repeater->start_controls_tab(
			'member_info_tab',
			[
				'label' => esc_html__( 'Information', 'firecore-elementor-core' ),
			]
		);
		$repeater->add_control(
			'modern_team_image',
			[
				'label' 	=> esc_html__( 'Thumbnail Image', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'webexbase-icon-up-right-arrow',
					'library' 	=> 'firecore_base_icon',
				],
			]
		);
		$repeater->add_control(
			'name',
			[
				'label'       => esc_html__( 'Name', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Member Name', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'name_tag',
			[
				'label' 	=> esc_html__( 'Name Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'designation',
			[
				'label'       => esc_html__( 'Designation', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Designation', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'designation_tag',
			[
				'label' 	=> esc_html__( 'Designation Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'span',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'title_link',
			[
				'label' => esc_html__( "Title Link URL", 'firecore-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
				]
			]
		);
		$repeater->end_controls_tab();
		$repeater->start_controls_tab(
			'member_social_tab',
			[
				'label' => __( 'Social Links', 'firecore-elementor-core' ),
			]
		);
		$repeater->add_control(
			'show_social_links',
			[
				'label'        => esc_html__( 'Show Links', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control(
			'facebook', [
				'label_block' => false,
				'type'        => Controls_Manager::TEXT,
				'label'       => esc_html__( 'Facebook', 'firecore-elementor-core' ),
				'placeholder' => esc_html__( 'Add your Facebook address', 'firecore-elementor-core' ),
				'input_type'  => 'url',
				'condition'   => [
					'show_social_links' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'x', [
				'label_block' => false,
				'type'        => Controls_Manager::TEXT,
				'label'       => esc_html__( 'X', 'firecore-elementor-core' ),
				'placeholder' => esc_html__( 'Add your X address', 'firecore-elementor-core' ),
				'input_type'  => 'url',
				'condition'   => [
					'show_social_links' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'linkedin', [
				'label_block' => false,
				'type'        => Controls_Manager::TEXT,
				'label'       => esc_html__( 'LinkedIn', 'firecore-elementor-core' ),
				'placeholder' => esc_html__( 'Add your LinkedIn address', 'firecore-elementor-core' ),
				'input_type'  => 'url',
				'condition'   => [
					'show_social_links' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'instagram', [
				'label_block' => false,
				'type'        => Controls_Manager::TEXT,
				'label'       => esc_html__( 'Instagram', 'firecore-elementor-core' ),
				'placeholder' => esc_html__( 'Add your Instagram address', 'firecore-elementor-core' ),
				'input_type'  => 'url',
				'condition'   => [
					'show_social_links' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'website', [
				'label_block' => false,
				'type'        => Controls_Manager::TEXT,
				'label'       => esc_html__( 'Website Address', 'firecore-elementor-core' ),
				'placeholder' => esc_html__( 'Add your profile link', 'firecore-elementor-core' ),
				'input_type'  => 'url',
				'condition'   => [
					'show_social_links' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'email', [
				'label_block' => false,
				'type'        => Controls_Manager::TEXT,
				'label'       => esc_html__( 'Email', 'firecore-elementor-core' ),
				'placeholder' => esc_html__( 'Add your Email address', 'firecore-elementor-core' ),
				'input_type'  => 'email',
				'condition'   => [
					'show_social_links' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'github', [
				'label_block' => false,
				'type'        => Controls_Manager::TEXT,
				'label'       => esc_html__( 'Github', 'firecore-elementor-core' ),
				'placeholder' => esc_html__( 'Add your Github address', 'firecore-elementor-core' ),
				'input_type'  => 'url',
				'condition'   => [
					'show_social_links' => 'yes',
				],
			]
		);
		$repeater->end_controls_tab();
		$repeater->end_controls_tabs();
		$this->add_control(
			'modern_team_members',
			[
				'label'       => esc_html__( 'Members', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'name'      => esc_html__( 'Jacob Martin', 'firecore-elementor-core' ),
						'designation' => esc_html__( 'Web Developer', 'firecore-elementor-core' ),
						'facebook'  => '#',
						'x'   => '#',
						'instagram' => '#',
						'linkedin'  => '#',
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'name'      => esc_html__( 'Alica Bendor', 'firecore-elementor-core' ),
						'designation' => esc_html__( 'Interior Designer', 'firecore-elementor-core' ),
						'facebook'  => '#',
						'x'   => '#',
						'instagram' => '#',
						'linkedin'  => '#',
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'name'      => esc_html__( 'Sebastian Turner', 'firecore-elementor-core' ),
						'designation' => esc_html__( 'Web Developer', 'firecore-elementor-core' ),
						'facebook'  => '#',
						'x'   => '#',
						'instagram' => '#',
						'linkedin'  => '#',
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'name'      => esc_html__( 'Robert Tylor', 'firecore-elementor-core' ),
						'designation' => esc_html__( 'Web Developer', 'firecore-elementor-core' ),
						'facebook'  => '#',
						'x'   => '#',
						'instagram' => '#',
						'linkedin'  => '#',
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);
		$this->end_controls_section();
		/* ===== End Team Members Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'team_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'text_align',
			[
				'label'     => esc_html__( 'Alignment', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .team-block .team-bottom-part' => 'text-align: {{Value}};',
				],
			]
		);
		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .team-block-members' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .team-block-members' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_content_item_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .team-block .team-bottom-part' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_content_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .team-block .team-bottom-part' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .team-block .team-bottom-part',
			]
		);
		$this->add_responsive_control(
			'item_box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .team-block .team-bottom-part' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'team_item_tab' );
		$this->start_controls_tab(
			'team_item_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-block .team-bottom-part' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .team-block',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'team_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-block:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .team-block-style_1 .team-bottom-part:after' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .team-block-style_1 .team-bottom-part:before' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .team-block-style_1:hover .team-bottom-part:after' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .team-block-style_1:hover .team-bottom-part:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_hover_shadow',
				'selectors' => [
					'{{WRAPPER}} .team-block:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .team-block-style_1:hover .team-bottom-part' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Content Style ===== */





		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'team_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'team_title_tabs' );
		$this->start_controls_tab(
			'team_title_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'team_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .team-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'team_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .team-title',
			]
		);
		$this->add_responsive_control(
			'team_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'team_title_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'team_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-title:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .team-title a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'team_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .team-title:hover',
			]
		);
		$this->add_responsive_control(
			'team_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'team_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'team_title_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-block:hover .team-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .team-block:hover .team-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Designation Style ===== */
		$this->start_controls_section(
			'team_designation_style',
			[
				'label' => esc_html__( 'Designation Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'team_designation_tabs' );
		$this->start_controls_tab(
			'team_designation_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'team_designation_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-designation' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'team_designation_normal_typography',
				'selector' 	=> '{{WRAPPER}} .team-designation',
			]
		);
		$this->add_responsive_control(
			'team_designation_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-designation' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_designation_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-designation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'team_designation_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'team_designation_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-designation:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'team_designation_hover_typography',
				'selector' 	=> '{{WRAPPER}} .team-designation:hover',
			]
		);
		$this->add_responsive_control(
			'team_designation_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-designation:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_designation_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-designation:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Designation Style ===== */





		/* ===== Begin Social Icons Style ===== */
		$this->start_controls_section(
			'team_social_styling',
			[
				'label' => esc_html__( 'Social Icons', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'team_social_icon_move_left_right',
			[
				'label' => esc_html__( 'Icon Move Left Right', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .social-list' => 'left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'team_styles' => 'style_1',
				],
			]
		);
		$this->add_responsive_control(
			'team_social_icon_move_up_down',
			[
				'label' => esc_html__( 'Icon Move Up Down', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .social-list' => 'bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'team_styles' => 'style_1',
				],
			]
		);
		$this->add_responsive_control(
			'team_social_icon_size',
			[
				'label'      => esc_html__( 'Size', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .social-list li a, {{WRAPPER}} .social-list li a i' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'team_social_icon_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .social-list a, {{WRAPPER}} .social-list a i',
			]
		);
		$this->add_responsive_control(
			'team_social_margin',
			[
				'label'      => esc_html__( 'Icon Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .social-list li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_social_padding',
			[
				'label'      => esc_html__( 'Icon Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .social-list li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'team_social_icon_border',
				'selector' => '{{WRAPPER}} .social-list a',
			]
		);
		$this->add_responsive_control(
			'team_social_icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .social-list li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'team_social_icon_tab' );

		$this->start_controls_tab(
			'team_social_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'team_social_icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .social-list li a, {{WRAPPER}} .social-list li a i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'team_social_icon_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .social-list li a' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'team_social_icon_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);

		$this->add_control(
			'team_social_icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .social-list a:hover, {{WRAPPER}} .social-list li a:hover i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'team_social_icon_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .social-list a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Social Icons Style ===== */





		/* ===== Begin Social Share Icon Style ===== */
		$this->start_controls_section(
			'team_social_share_icon_styling',
			[
				'label' => esc_html__( 'Social Share Icon', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'            => [
					'team_styles' => 'style_2',
				],
			]
		);
		$this->add_responsive_control(
			'team_social_share_icon_move_left_right',
			[
				'label' => esc_html__( 'Icon Move Left Right', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .team-block .team-social-area' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_social_share_icon_move_up_down',
			[
				'label' => esc_html__( 'Icon Move Up Down', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .team-block .team-social-area' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_social_share_icon_size',
			[
				'label'      => esc_html__( 'Size', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .team-block .team-social-area' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'team_social_share_icon_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .team-block .team-social-area .social-share-icon',
			]
		);
		$this->add_responsive_control(
			'team_social_share_margin',
			[
				'label'      => esc_html__( 'Icon Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .team-block .team-social-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'team_social_share_padding',
			[
				'label'      => esc_html__( 'Icon Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .team-block .team-social-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'team_social_share_icon_border',
				'selector' => '{{WRAPPER}} .team-block .team-social-area',
			]
		);
		$this->add_responsive_control(
			'team_social_share_icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .team-block .team-social-area' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'team_social_share_icon_tab' );

		$this->start_controls_tab(
			'team_social_share_icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'team_social_share_icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-block .team-social-area .social-share-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'team_social_share_icon_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-block .team-social-area' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'team_social_share_icon_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);

		$this->add_control(
			'team_social_share_icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .social-list a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'team_social_share_icon_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .social-list a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Social Icons Style ===== */



		/* ===== Begin Carousel Options ===== */
		webex_get_elementor_carousel_options($this);
		/* ===== End Carousel Options ===== */


}

	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( empty( $settings['modern_team_members'] ) ) {
			return;
		}
		$this->add_render_attribute( 'wrapper', 'class', 'modern-team-wrapper' );
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<div id="modern-team-wrapper-<?php echo esc_attr( $settings['modern_team_styles'] ) ?>">
				<?php
					foreach ( $settings['modern_team_members'] as $index => $member ) {
						$this->render_single_member( $index, $member );
					}
				?>
			</div>
		</div>
		<?php
	}

	public function render_single_member( $index, $member ) {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$firecore_icons = $member['firecore_icons']['value'];
		$name = $member['name'];
		$name_tag = $member['name_tag'];
		$designation = $member['designation'];
		$designation_tag = $member['designation_tag'];

		$custom_link = $member['title_link'];
		$target = ( $custom_link && $custom_link['is_external'] ) ? ' target="_blank"' : '';
		$url = ( $custom_link && $custom_link['url'] ) ? $custom_link['url'] : '';

		if ( empty( $member['modern_team_image']['id'] && ! empty( $member['modern_team_image']['url'] ) ) ) {
			$modern_team_image_url = $member['modern_team_image']['url'];
		} else {
			$modern_team_image_url = Group_Control_Image_Size::get_attachment_image_src( $member['modern_team_image']['id'], 'modern_team_image', $settings );
		}

		switch ( $settings['modern_team_styles'] ) {
			case 'style_1':
				include firecore_get_template2( '/team-modern/style1.php' );
				break;
		}

	}
}
