<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;
use WP_Query;

class FIRECORE_Modern_Projects extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-modern-project';
	}

	public function get_title() {
		return esc_html__( 'Modern Projects', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Project Content ===== */
		$this->start_controls_section(
			'section_content_item',
			[
				'label' => esc_html__( 'Projects', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_projects_styles',
			[
				'label' => __( 'Modern Projects Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'modern_projects_image',
			[
				 'label'     => __('Image Size', 'firecore-elementor-core'),
				 'type'      => \Elementor\Controls_Manager::SELECT,
				 'options'   => get_thumbnail_size(),
				 'default'   => 'firecore-image(315x375)'
			]
		);
		$this->add_control(
			'project_category_show_hide',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Show Category?', 'firecore-elementor-core' ),
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'  => esc_html__( 'Show', 'firecore-elementor-core' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'counting',
			[
				'label'       => esc_html__( 'Counting', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( '01', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'excerpt_show_hide',
			[
				'label'        => esc_html__( 'Show Excerpt?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'yes',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'excerpt_count',
			[
				'label'     => esc_html__( 'Excerpt Word', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 12,
				'condition' => [
					'excerpt_show_hide' => 'yes',
				],
			]
		);
		$this->add_control(
			'link_btn_show_hide',
			[
				'label'        => esc_html__( 'Show Link Button?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'yes',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Text Button', 'firecore-elementor-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Read more ', 'firecore-elementor-core' ),
				'condition' => [
					'link_btn_show_hide' => 'yes',
				],
			],
		);
		$this->end_controls_section();





		$this->start_controls_section('query_content', [
			'label' => esc_html__('Projects Query', 'firecore-elementor-core'),
		]);
		$this->add_control('post_from', [
			'label' => esc_html__('Project From', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'all' => esc_html__('All Project', 'firecore-elementor-core'),
				'categories' => esc_html__('Categories', 'firecore-elementor-core'),
				'specific-post' => esc_html__('Specific Project', 'firecore-elementor-core'),
			],
			'default' => 'all',
		]);
		$this->add_control('post_ids', [
			'label' => esc_html__('Select Project', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT2,
			'options' => firecore_select_posts('webex_projects'),
			'multiple' => true,
			'label_block' => true,
			'condition' => [
				'post_from' => 'specific-post',
			],
		]);
		$this->add_control('cat_slugs', [
			'label' => esc_html__('Select Categories', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT2,
			'options' => firecore_select_category('webex_projects_cats'),
			'multiple' => true,
			'label_block' => true,
			'condition' => [
				'post_from' => 'categories',
			],
		]);
		$this->add_control('post_limit', [
			'label' => esc_html__('Item Show Per Page', 'firecore-elementor-core'),
			'type' => Controls_Manager::NUMBER,
			'default' => 3,
			'min' => 1,
		]);
		$this->add_control('order_by', [
			'label' => esc_html__('Order By', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'ID' => esc_html__('ID', 'firecore-elementor-core'),
				'author' => esc_html__('Author', 'firecore-elementor-core'),
				'title' => esc_html__('Title', 'firecore-elementor-core'),
				'date' => esc_html__('Date', 'firecore-elementor-core'),
				'rand' => esc_html__('Random', 'firecore-elementor-core'),
			],
			'default' => 'date',
		]);
		$this->add_control('sort_order', [
			'label' => esc_html__('Sort Order', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'ASC' => esc_html__('Ascending', 'firecore-elementor-core'),
				'DESC' => esc_html__('Descending', 'firecore-elementor-core'),
			],
			'default' => 'DESC',
		]);
		$this->end_controls_section();
		/* ===== End Project Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'project_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'project_item_tab' );
		$this->start_controls_tab(
			'project_item_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .project-block, {{WRAPPER}} .project-block .project-item-thumb',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_normal_border',
				'selector' => '{{WRAPPER}} .project-block, {{WRAPPER}} .project-block .project-item-thumb',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'project_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_hover_shadow',
				'selectors' => [
					'{{WRAPPER}} .project-block:hover, {{WRAPPER}} .project-block:hover .project-item-thumb' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_hover_border',
				'selector' => '{{WRAPPER}} .project-block:hover, {{WRAPPER}} .project-block:hover .project-item-thumb',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'item_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-block:hover, {{WRAPPER}} .project-block .project-item-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */






		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'project_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'project_title_tabs' );
		$this->start_controls_tab(
			'project_title_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .project-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .project-title',
			]
		);
		$this->add_responsive_control(
			'project_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'project_title_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-title:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .project-title a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .project-title:hover',
			]
		);
		$this->add_responsive_control(
			'project_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'project_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_title_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-block:hover .project-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .project-block:hover .project-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Category Style ===== */
		$this->start_controls_section(
			'project_category_style',
			[
				'label' => esc_html__( 'Category Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'project_category_tabs' );
		$this->start_controls_tab(
			'project_category_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_category_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-category a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_category_normal_typography',
				'selector' 	=> '{{WRAPPER}} .project-category a',
			]
		);
		$this->add_responsive_control(
			'project_category_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-category a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_category_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-category a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'project_category_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_category_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-category a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_category_hover_typography',
				'selector' 	=> '{{WRAPPER}} .project-category a:hover',
			]
		);
		$this->add_responsive_control(
			'project_category_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-category a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_category_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-category a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Category Style ===== */






		/* ===== Begin Button Style ===== */
		$this->start_controls_section(
			'project_button_style',
			[
				'label' => esc_html__( 'Button Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'project_button_top_bottom',
			[
				'label' => esc_html__( 'Button Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -800,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .project-link-icon a' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_button_left_right',
			[
				'label' => esc_html__( 'Button Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -800,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .project-link-icon a' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_button_size',
			[
				'label'      => esc_html__( 'Size', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => .1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .project-link-icon a' => 'transform: scale({{SIZE}});',
				],
			]
		);
		$this->add_responsive_control(
			'project_button_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-link-icon a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'project_button_tabs' );
		$this->start_controls_tab(
			'project_button_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-link-icon a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_button_normal_typography',
				'selector' 	=> '{{WRAPPER}} .project-link-icon a',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'project_button_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-link-icon a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_button_hover_typography',
				'selector' 	=> '{{WRAPPER}} .project-link-icon a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Button Style ===== */






		/* ===== Begin Carousel Options ===== */
		webex_get_elementor_carousel_options($this);
		/* ===== End Carousel Options ===== */

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div id="modern-projects-wrapper-<?php echo esc_attr( $settings['modern_projects_styles'] ) ?>" <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >
			<div class="project_sticky_cards_01">
				<?php $this->render_loop( $settings );?>
			</div>
		</div>
		<?php
	}

	public function render_loop( $settings ) {
		$args = [
			'post_type'           => 'webex_projects',
			'post_status'         => 'publish',
			'posts_per_page'      => $settings['post_limit'],
			'orderby'             => $settings['order_by'],
			'order'               => $settings['sort_order'],
			'thumbnail_size'  		=> $settings['modern_projects_image'],
			'ignore_sticky_posts' => 1,
		];

		if ( 'categories' == $settings['post_from'] && $settings['cat_slugs'] ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'webex_projects_cats',
					'field'    => 'slug',
					'terms'    => $settings['cat_slugs'],
				],
			];
		}

		if ( 'specific-post' == $settings['post_from'] && $settings['post_ids'] ) {
			$args['post__in'] = $settings['post_ids'];
		}

		$wp_query = new WP_Query( $args );
		while ( $wp_query->have_posts() ): $wp_query->the_post();?>
			<?php self::render_project_item( $settings ); ?>
		<?php endwhile;
		wp_reset_postdata();
	}

	public static function render_project_item( $settings ) {
		$get_id             = get_the_ID();
		$categories_list = get_the_term_list( $get_id, 'webex_projects_cats', '', '', '' );
		$the_title = get_the_title();
		$excerpt_count = $settings['excerpt_count'];

		switch ( $settings['modern_projects_styles'] ) {
			case 'style_1':
				include firecore_get_template2( '/project-modern/style1.php' );
				break;
		}
	}
}
