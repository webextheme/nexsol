<div class="modern-services-block modern-services-block-style1 pinned_item">
  <div class="modern-services-thumb-wrapper">
    <img src="<?php echo esc_url( $modern_services_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
    <div class="modern-services-content-wrapper">
      <div class="modern-services-mini-thumb-area">
        <div class="modern-services-icon">
          <!-- Icon -->
          <?php if ( !empty($firecore_icons) ): ?>
            <div class="icon">
              <i class="<?php echo esc_attr( $firecore_icons ); ?>"></i>
            </div>
          <?php endif; ?>
        </div>
        <div class="modern-services-mini-thumb">
          <img src="<?php echo esc_url( $modern_services_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
        </div>
      </div>
      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
      <?php echo '<'. esc_attr( $title_tag ) .' class="modern-services-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($title , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($title , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>
      <!-- Description -->
      <?php if( !empty( $description ) ) : ?>
      <p class="modern-services-description"><?php echo esc_html( $description ) ?></p>
      <?php endif; ?>
    </div>
  </div>
</div>