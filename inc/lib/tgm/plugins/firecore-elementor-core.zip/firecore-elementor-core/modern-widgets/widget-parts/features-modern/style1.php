<div class="modern-features-block modern-features-block-style1">
  <div class="modern-feature-inner">
    <div class="modern-feature-nav-part">
      <div class="modern-feature-icon">
        <!-- Icon -->
        <?php if ( !empty($firecore_icons) ): ?>
          <div class="icon">
            <i class="<?php echo esc_attr( $firecore_icons ); ?>"></i>
          </div>
        <?php endif; ?>
      </div>
      <div class="title-part">
        <!-- Title -->
        <?php if( !empty( $title ) ) : ?>
        <?php echo '<'. esc_attr( $title_tag ) .' class="modern-feature-title">'; ?>
        <?php echo wp_kses($title , $allowed_tags) ?>
        <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
        <?php endif; ?>
      </div>
    </div>
    <div class="modern-feature-content-part">
      <div class="modern-feature-thumb">
        <img src="<?php echo esc_url( $modern_features_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
      </div>
      <div class="modern-feature-details-area">
        <!-- counting -->
        <?php if( !empty( $counting ) ) : ?>
          <span class="modern-feature-counting"><?php echo esc_html( $counting ) ?></span>
        <?php endif; ?>
        <!-- Description -->
        <?php if( !empty( $description ) ) : ?>
        <p class="modern-feature-description"><?php echo esc_html( $description ) ?></p>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>