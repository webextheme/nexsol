<div class="modern-team-block modern-team-block-style1">
  <div class="modern-team-block-default">
    <div class="modern-team-bg">
      <!-- Name -->
      <?php if( !empty( $name ) ) : ?>
        <?php echo '<'. esc_attr( $name_tag ) .' class="modern-designation-name">'; ?>
          <?php if( !empty( $url ) ): ?>
          <a
            <?php echo $target;?>
            href="<?php echo esc_url( $url );?>">
            <?php echo wp_kses($name , $allowed_tags) ?>
          </a>
          <?php else: ?>
            <?php echo wp_kses($name , $allowed_tags) ?>
          <?php endif ?>
        <?php echo '</'. esc_attr( $name_tag ) .'>' ?>
      <?php endif; ?>
    </div>
  </div>
  <div class="modern-team-block-expanded">
    <div class="modern-team-thumb">
      <img src="<?php echo esc_url( $modern_team_image_url ) ?>" alt="<?php echo esc_html( $member['name'] ) ?>">
    </div>
    <div class="modern-team-content">
      <div class="modern-team-content-details">
        <!-- Name -->
        <?php if( !empty( $name ) ) : ?>
          <?php echo '<'. esc_attr( $name_tag ) .' class="modern-designation-name">'; ?>
            <?php if( !empty( $url ) ): ?>
            <a
              <?php echo $target;?>
              href="<?php echo esc_url( $url );?>">
              <?php echo wp_kses($name , $allowed_tags) ?>
            </a>
            <?php else: ?>
              <?php echo wp_kses($name , $allowed_tags) ?>
            <?php endif ?>
          <?php echo '</'. esc_attr( $name_tag ) .'>' ?>
        <?php endif; ?>
        <!-- Designation -->
        <?php if( !empty( $designation ) ) : ?>
        <p class="modern-team-designation"><?php echo esc_html( $designation ) ?></p>
        <?php endif; ?>
      </div>
      <?php if ( 'yes' === $member['show_social_links'] ) : ?>
      <div class="team-social">
        <ul class="social-list">
          <?php
            if ( !empty( $member['facebook'] ) ) {
              printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-facebook-f"></i></a></li>',
                esc_url( $member['facebook'] ),
              );
            }
            if ( !empty( $member['x'] ) ) {
              printf('<li><a href="%1$s" aria-label="Social"><i class="webexbase-icon-twitter-2"></i></a></li>',
                esc_url( $member['x'] ),
              );
            }
            if ( !empty( $member['linkedin'] ) ) {
              printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-linkedin-in"></i></a></li>',
                esc_url( $member['linkedin'] ),
              );
            }
            if ( !empty( $member['instagram'] ) ) {
              printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-instagram"></i></a></li>',
                esc_url( $member['instagram'] ),
              );
            }
            if ( !empty( $member['website'] ) ) {
              printf('<li><a href="%1$s" aria-label="Social"><i class="fas fa-globe"></i></a></li>',
                esc_url( $member['website'] ),
              );
            }
            if ( !empty( $member['email'] ) ) {
              printf('<li><a href="%1$s" aria-label="Social"><i class="fas fa-envelope"></i></a></li>',
                esc_url( $member['email'] ),
              );
            }
            if ( !empty( $member['github'] ) ) {
              printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-github"></i></a></li>',
                esc_url( $member['github'] ),
              );
            }
          ?>
        </ul>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>