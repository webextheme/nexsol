<div class="modern-services-block modern-services-block-style2">
  <div class="modern-services-inner">
    <div class="modern-services-left-part">
      <div class="title-part">
        <div class="modern-services-icon"></div>
        <!-- Title -->
        <?php if( !empty( $title ) ) : ?>
        <?php echo '<'. esc_attr( $title_tag ) .' class="modern-services-title">'; ?>
        <?php echo wp_kses($title , $allowed_tags) ?>
        <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
        <?php endif; ?>
      </div>
      <!-- Button -->
      <span class="modern-service-arrow"><i class="webexbase-icon-arrow-up-right2"></i></span>
    </div>
    <div class="modern-services-content-part">
      <div class="modern-services-thumb">
        <img src="<?php echo esc_url( $modern_services_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
      </div>
      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
      <?php echo '<'. esc_attr( $title_tag ) .' class="modern-services-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($title , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($title , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>
      <!-- Description -->
      <?php if( !empty( $description ) ) : ?>
      <p class="modern-services-description"><?php echo esc_html( $description ) ?></p>
      <?php endif; ?>

      <!-- Button -->
      <div class="modern-services-button">
        <div class="firecore_btn_block_style1">
          <div class="firecore-btn-block-2">
            <a class="firecore-btn-2 firecore-btn-2-primary" href="<?php echo esc_url( $btn_url );?>" <?php echo esc_attr($target); ?>><?php echo esc_html($button_text); ?></a>
            <a class="firecore-btn-2 firecore-btn-2-circle" href="<?php echo esc_url( $btn_url );?>" <?php echo esc_attr($target); ?>><i class="webexbase-icon-arrow-up-right2"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>