<?php
/**
 * Plugin Name: Firecore Elementor Widgets
 * Plugin URI: https://webextheme.com
 * Description: Firecore Custom Elementor Widgets Library
 * Version: 1.0
 * Author: WebexTheme
 * Author URI: https://themeforest.net/user/webextheme/portfolio
 * Text Domain: firecore-elementor-core
 */

 if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor Extension main CLass
 * @since 1.0.0
 */
final class FIRECORE_Elementor_Widget {

	// Plugin version
	const VERSION = '1.0.0';

	// Minimum Elementor Version
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	// Minimum PHP Version
	const MINIMUM_PHP_VERSION = '7.0';

	// Instance
	private static $_instance = null;

	/**
	 * SIngletone Instance Method
	 * @since 1.0.0
	 */
	public static function instance() {
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Construct Method
	 * @since 1.0.0
	 */
	public function __construct() {
		// Call Constants Method
		$this->define_constants();
		$this->theme_fallback();
		$this->init_hooks();
		add_action('elementor/editor/after_enqueue_scripts', [$this, 'firecore_enqueue_editor_scripts'] );
	}

	/**
	 * Define Plugin Constants
	 * @since 1.0.0
	 */
	public function define_constants() {
		define( 'FIRECORE_ELEMENTOR_CORE_URL', plugin_dir_url( __FILE__ ) );
		define( 'FIRECORE_ELEMENTOR_CORE_PATH', plugin_dir_path( __FILE__ ) );
		define('FIRECORE_PLUGIN_URL', trailingslashit(plugins_url('/', __FILE__)));
		define('FIRECORE_PLUGIN_PATH', trailingslashit(plugin_dir_path(__FILE__)));
		define('FIRECORE_PLUGIN_DIR', __DIR__);
		define( 'FIRECORE_THEME_ASSETS', untrailingslashit( get_template_directory_uri() ) . '/assets' );
		if ( ! defined( 'FIRECORE_CORE_ASSETS' ) ) {
			define( 'FIRECORE_CORE_ASSETS', plugins_url( 'assets', __FILE__ ) );
		}
	}



	/**
	 * Init Hooks
	 *
	 * Hook into actions and filters.
	 *
	 * @since 1.7.0
	 *
	 * @access private
	 */
	private function init_hooks() {
		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 *
	 * @since 1.7.0
	 *
	 * @access public
	 */
	public function i18n() {
		load_plugin_textdomain('firecore-elementor-core', false, dirname(plugin_basename(__FILE__)) . '/languages');
	}

	/**
	 * register fallback theme functions
	 *
	 * @return void
	 */
	public function theme_fallback()
	{
		include FIRECORE_PLUGIN_DIR . '/functions.php';
	}

	/**
	 * Initialize the plugin
	 * @since 1.0.0
	 */
	public function init() {

		if ( !did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version

		if ( !version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version

		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		add_action('elementor/init', [$this, 'add_elementor_category']);

		// Register Widget Styles
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'firecore_enqueue_plugin_fonts' ] );
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'firecore_enqueue_plugin_fonts' ] );

		// Register Widget Scripts
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_widget_scripts' ] );
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'register_widget_scripts' ] );

		// Register Elementor Widget
		add_action('elementor/widgets/widgets_registered', [$this, 'init_widgets']);

    // load icons
		add_filter('elementor/icons_manager/additional_tabs', array($this, 'add_elementor_custom_icons'));

		// Disable Default elementor animations
    add_action('elementor/frontend/after_enqueue_scripts',function() {
			wp_deregister_style('e-animation-fadeInUp');
			wp_deregister_style('e-animation-fadeInRight');
			wp_deregister_style('e-animation-fadeInBottom');
			wp_deregister_style('e-animation-fadeInLeft');

			wp_dequeue_style('e-animation-fadeInUp');
			wp_dequeue_style('e-animation-fadeInRight');
			wp_dequeue_style('e-animation-fadeInBottom');
			wp_dequeue_style('e-animation-fadeInLeft');
    }, 20 );

    add_action('wp_enqueue_scripts', function() {
      if (class_exists('Elementor\Plugin')) {
			wp_deregister_style('e-animation-fadeInUp');
			wp_deregister_style('e-animation-fadeInRight');
			wp_deregister_style('e-animation-fadeInBottom');
			wp_deregister_style('e-animation-fadeInLeft');

			wp_dequeue_style('e-animation-fadeInUp');
			wp_dequeue_style('e-animation-fadeInRight');
			wp_dequeue_style('e-animation-fadeInBottom');
			wp_dequeue_style('e-animation-fadeInLeft');
      }
    }, 20);
	}


	/**
	 * Admin Notice
	 * Warning when the site doesn't have Elementor installed or activated
	 * @since 1.0.0
	 */
	public function admin_notice_missing_main_plugin() {
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			esc_html__('"%1$s" requires "%2$s" to be installed and activated', 'firecore-elementor-core'),
			'<strong>' . esc_html__('Firecore Elementor Widget', 'firecore-elementor-core') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'firecore-elementor-core') . '</strong>'
		);

		printf('<div class="notice notice-warning is-dimissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Admin Notice
	 * Warning when the site doesn't have a minimum required Elementor version.
	 * @since 1.0.0
	 */
	public function admin_notice_minimum_elementor_version() {
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater', 'firecore-elementor-core'),
			'<strong>' . esc_html__('Firecore Elementor Widget', 'firecore-elementor-core') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'firecore-elementor-core') . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf('<div class="notice notice-warning is-dimissible"><p>%1$s</p></div>', $message);
	}
	/**
	 * Admin Notice
	 * Warning when the site doesn't have a minimum required PHP version.
	 * @since 1.0.0
	 */
	public function admin_notice_minimum_php_version() {
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater', 'firecore-elementor-core'),
			'<strong>' . esc_html__('Firecore Elementor Widget', 'firecore-elementor-core') . '</strong>',
			'<strong>' . esc_html__('PHP', 'firecore-elementor-core') . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf('<div class="notice notice-warning is-dimissible"><p>%1$s</p></div>', $message);
	}
	/**
	 * Add new Elementor Categories
	 * @since 1.0.0
	 */
	public function add_elementor_category() {
		Elementor\Plugin::instance()->elements_manager->add_category(
			'100',
			[
				'title'  => 'Firecore Core Widgets',
				'icon' => 'font',
				'panel' => 'close',
			],
			1
		);
	}

	/**
	 * Register Widget Scripts
	 *
	 * Register custom scripts required to run Saasland Core.
	 *
	 * @since 1.6.0
	 * @since 1.7.1 The method moved to this class.
	 *
	 * @access public
	 */
	public function register_widget_scripts() {
		wp_register_script( 'firecore-elementor-script', plugins_url( '/assets/js/main.js', __FILE__ ), array( 'jquery' ), false, true );
		wp_register_script( 'home1-slider-js', plugins_url( '/assets/js/home1-slider.js', __FILE__ ), array( 'jquery' ), false, true );
		wp_register_script( 'allslider-js', plugins_url( '/assets/js/allsliders.js', __FILE__ ), array( 'jquery' ), false, true );
	}

	/**
	 * Register Widget Styles
	 *
	 * Register custom styles required to run Saasland Core.
	 *
	 * @since 1.7.0
	 * @since 1.7.1 The method moved to this class.
	 *
	 * @access public
	 */

	public function firecore_enqueue_plugin_fonts() {
		wp_enqueue_style('firecore-webexbaseicon', plugins_url('/assets/fonts/webexbaseicon/style.css', __FILE__), '1.0', 'all');
		wp_enqueue_style('firecore-webexfireicon', plugins_url('/assets/fonts/webexfireicon/style.css', __FILE__), '1.0', 'all');
	}

	/**
	 * firecore_enqueue_editor_scripts
	 */
	function firecore_enqueue_editor_scripts()
	{
		wp_enqueue_style('firecore-element-addons-editor', FIRECORE_PLUGIN_URL . 'assets/css/editor.css', null, '1.0');
	}

	/**
	 * Init Widgets
	 * @since 1.0.0
	 */
	public function init_widgets() {

		// Include Widget files
		require_once FIRECORE_PLUGIN_PATH . '/widgets/home-banner.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/headers.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/main-menu.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/service-sidebar-menu.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/footer-menu.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/toggle-search.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/side-panel.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/pricing-switcher.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/mobile-menu.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/contact-info.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/about-image-box.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/experience-box.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/plain-text.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/section-title.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/feature-box.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/award-box.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/icon-box.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/skill.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/pricing.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/moving-text.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/circle-text.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/buttons.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/show-more.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/site-logo.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/before-after-slider.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/working-steps.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/funfact-counter.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/call-to-action.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/about-author.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/video-popup.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/contact-form.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/animated-objects.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/accordion.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/project-info.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/social-list.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/list-icon.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/newsletter.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/project-next-prev-posts.php';

		// Firecore Current Post Widgets
		require_once FIRECORE_PLUGIN_PATH . '/widgets/team.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/services.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/testimonials.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/projects.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/gallery.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/clients.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/news-posts.php';
		require_once FIRECORE_PLUGIN_PATH . '/widgets/shop-products.php';

		// Firecore Modern Widgets
		require_once FIRECORE_PLUGIN_PATH . '/modern-widgets/award-modern.php';
		require_once FIRECORE_PLUGIN_PATH . '/modern-widgets/features-modern.php';
		require_once FIRECORE_PLUGIN_PATH . '/modern-widgets/service-modern.php';
		require_once FIRECORE_PLUGIN_PATH . '/modern-widgets/team-modern.php';
		require_once FIRECORE_PLUGIN_PATH . '/modern-widgets/project-modern.php';

		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Home_Banner() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_About_Image_V1() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Section_Title() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Plain_Text() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Buttons() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Headers() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Main_Menu() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Footer_Menu() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Service_Sidebar_Menu() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Toggle_Search() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Side_Panel() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Pricing_Switcher() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Mobile_Menu() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Contact_Info() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Experience_Box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Feature_Box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Award_Box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Icon_Box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Skill() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Pricing() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Moving_Text() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Circle_Text() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Show_More() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Sit_Logo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Before_After_Slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Working_Steps() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Before_Funfact_Counter() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Call_To_Action() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_About_Author() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Video_Popup() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Contact_Form() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Animated_Objects() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Accordion() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Project_Info() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Social_List() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_List_Icon() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Newsletter() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Project_Next_Prev_Posts() );

		// Firecore Modern Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Modern_Awards() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Modern_Features() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Modern_Services() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Modern_Team_Members() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Modern_Projects() );

		// Firecore Current Post Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Team_Members() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Services() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Testimonials() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Projects() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Gallery() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Clients() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_News_Posts() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FirecoreElementor\Widget\FIRECORE_Products() );


	}

	public function add_elementor_custom_icons($array)
	{
		return array(
			'firecore_base_icon' => array(
				'name'          => 'firecore_base_icon',
				'label'         => 'Firecore Base Icons',
				'url'           => '',
				'enqueue'       => array(
					FIRECORE_PLUGIN_URL . 'assets/fonts/webexbaseicon/style.css',
				),
				'prefix'        => '',
				'displayPrefix' => '',
				'labelIcon'     => 'webexbase-icon-menu',
				'ver'           => '1.0',
				'fetchJson'     => FIRECORE_PLUGIN_URL . 'assets/fonts/webexbaseicon/webexbaseicon.json',
				'native'        => 1,
			),
			'webex_theme_icon' => array(
				'name'          => 'webex_coworking_icon',
				'label'         => 'Firecore Theme Icons',
				'url'           => '',
				'enqueue'       => array(
					FIRECORE_PLUGIN_URL . 'assets/fonts/webexfireicon/style.css',
				),
				'prefix'        => '',
				'displayPrefix' => '',
				'labelIcon'     => 'webextheme-icon-011-fireman',
				'ver'           => '1.0',
				'fetchJson'     => FIRECORE_PLUGIN_URL . 'assets/fonts/webexfireicon/webexfireicon.json',
				'native'        => 1,
			),
		);
	}
}

FIRECORE_Elementor_Widget::instance();