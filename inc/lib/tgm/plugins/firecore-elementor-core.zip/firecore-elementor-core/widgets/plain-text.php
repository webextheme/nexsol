<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class FIRECORE_Plain_Text extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-plain-text';
	}

	public function get_title() {
		return esc_html__( 'Plain Text', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Text Editor', 'firecore-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'plain_text',
			[
				'type' => Controls_Manager::TEXTAREA,
				'default'	=> esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'firecore-elementor-core')
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/



		/*===================================
		Start Editor Style
		=====================================*/
		$this->start_controls_section(
			'webex_text_editor_styles',
			[
				'label' 	=> esc_html__( 'Text Editor', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'webex_text_editor_text_alignments',
			[
				'label' => __('Text Alignments', 'firecore-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'firecore-elementor-core' ),
						'icon' 	=> 'eicon-text-align-justify',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .webex-plain-text ' => 'text-align: {{VALUE}}!important;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'webex_text_editor_typography',
				'selector' 	=> '{{WRAPPER}} .webex-plain-text',
			]
		);

		$this->add_control(
			'webex_text_editor_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex-plain-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'webex_text_editor_background_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex-plain-text' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'webex_text_editor_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-plain-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'webex_text_editor_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-plain-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .webex-plain-text',
			]
		);
		$this->add_responsive_control(
			'button_normal_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-plain-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Editor Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$plain_text 			= $settings['plain_text'];
		?>

		<?php if( !empty( $plain_text  ) ) : ?>
			<div class="webex-plain-text"><?php echo esc_html( $plain_text ) ?></div>
		<?php endif; ?>

		<?php
	}
}
