<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_Before_Funfact_Counter extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-funfact-counter';
	}

	public function get_title() {
		return esc_html__( 'Funfact Counter', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/* ===== Start Content Settings ===== */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'funfact_styles', [
				'label' => __( 'Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'firecore-flaticon',
				],
			]
		);
		$this->add_control(
			'ending_number',
			[
				'label'   => esc_html__( 'Ending Number', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 100,
			]
		);
		$this->add_control(
			'post_symbol',
			[
				'label'       => esc_html__( 'Post Symbol', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Place Post Symbol', 'firecore-elementor-core' ),
				'default'     => esc_html__( '+', 'firecore-elementor-core' ),
				'label_block' => true,
				'separator'   => 'before',
			]
		);
		$this->add_control(
			'duration',
			[
				'label'   => esc_html__( 'Animation Duration', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 2000,
				'min'     => 100,
				'step'    => 100,
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Funfact Counter title', 'firecore-elementor-core' ),
				'default'     => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
				'label_block' => true,
				'separator'   => 'before',
			]
		);
		$this->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$this->add_control(
			'funfact_description',
			[
				'label' => esc_html__( "Paragraph", 'firecore-elementor-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( "Lorem ipsum dolor sit amet consectetur", 'firecore-elementor-core' ),
			]
		);
		$this->add_responsive_control(
			'funfact_alignments',
			[
				'label' => __('alignments', 'firecore-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .funfact-block ' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Settings ===== */






		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'funfact_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'funfact_item_content_border',
				'selector' => '{{WRAPPER}} .funfact-block',
			]
		);
		$this->add_responsive_control(
			'funfact_item_content_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-block' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_item_content_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-block' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_item_content_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-block' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'funfact_item_tab' );
		$this->start_controls_tab(
			'funfact_item_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .funfact-block',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_hover_shadow',
			'selector' => '{{WRAPPER}} .funfact-block:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Content Style ===== */



		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'funfact_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'funfact_title_tabs' );
		$this->start_controls_tab(
			'funfact_title_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .funfact-title',
			]
		);
		$this->add_responsive_control(
			'funfact_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_title_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-title:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .funfact-title:hover',
			]
		);
		$this->add_responsive_control(
			'funfact_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_title_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'services_title_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .funfact-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */



		/* ===== Begin Description Style ===== */
		$this->start_controls_section(
			'funfact_description_style',
			[
				'label' => esc_html__( 'Description Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'funfact_description_tabs' );
		$this->start_controls_tab(
			'funfact_description_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_description_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-description' => 'color: {{VALUE}};',
					'{{WRAPPER}} .funfact-description a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_description_normal_typography',
				'selector' 	=> '{{WRAPPER}} .funfact-description',
			]
		);
		$this->add_responsive_control(
			'funfact_description_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_description_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_description_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_description_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-description:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .funfact-description a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_description_hover_typography',
				'selector' 	=> '{{WRAPPER}} .funfact-description:hover',
			]
		);
		$this->add_responsive_control(
			'funfact_description_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-description:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_description_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .funfact-description:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_description_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_description_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .services-block:hover .funfact-description' => 'color: {{VALUE}};',
					'{{WRAPPER}} .services-block:hover .funfact-description a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Counter Style ===== */
		$this->start_controls_section(
			'funfact_counter_style',
			[
				'label' => esc_html__( 'Counter Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'funfact_counter_tabs' );
		$this->start_controls_tab(
			'funfact_counter_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_counter_normal_stroke_color',
			[
				'label'     => esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .counting-number' => '-webkit-text-stroke-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'funfact_counter_normal_fill_color',
			[
				'label'     => esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .counting-number' => '-webkit-text-fill-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'funfact_counter_normal_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .counting-number' => '-webkit-text-stroke-width: {{VALUE}}px;'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_counter_normal_typography',
				'selector' 	=> '{{WRAPPER}} .counting-number',
			]
		);
		$this->add_responsive_control(
			'funfact_counter_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .counting-number' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_counter_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .counting-number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_counter_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_counter_hover_stroke_color',
			[
				'label'     => esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .counting-number:hover' => '-webkit-text-stroke-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'funfact_counter_hover_fill_color',
			[
				'label'     => esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .counting-number:hover' => '-webkit-text-fill-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'funfact_counter_hover_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .counting-number:hover' => '-webkit-text-stroke-width: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_counter_hover_typography',
				'selector' 	=> '{{WRAPPER}} .counting-number:hover',
			]
		);
		$this->add_responsive_control(
			'funfact_counter_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .counting-number:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_counter_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .counting-number:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_counter_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_counter_block_hover_stroke_color',
			[
				'label'     => esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .counting-number' => '-webkit-text-stroke-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'funfact_counter_block_hover_fill_color',
			[
				'label'     => esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .counting-number' => '-webkit-text-fill-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'funfact_counter_block_hover_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .counting-number' => '-webkit-text-stroke-width: {{VALUE}};'
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Counter Style ===== */



		/* ===== Begin Post Symbol Style ===== */
		$this->start_controls_section(
			'funfact_post_symbol_style',
			[
				'label' => esc_html__( 'Post Symbol Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'funfact_post_symbol_tabs' );
		$this->start_controls_tab(
			'funfact_post_symbol_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_post_symbol_normal_stroke_color',
			[
				'label'     => esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-symbol' => '-webkit-text-stroke-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'funfact_post_symbol_normal_fill_color',
			[
				'label'     => esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-symbol' => '-webkit-text-fill-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'funfact_post_symbol_normal_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .post-symbol' => '-webkit-text-stroke-width: {{VALUE}}px;'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_post_symbol_normal_typography',
				'selector' 	=> '{{WRAPPER}} .post-symbol',
			]
		);
		$this->add_responsive_control(
			'funfact_post_symbol_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-symbol' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_post_symbol_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-symbol' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_post_symbol_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_post_symbol_hover_stroke_color',
			[
				'label'     => esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-symbol:hover' => '-webkit-text-stroke-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'funfact_post_symbol_hover_fill_color',
			[
				'label'     => esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-symbol:hover' => '-webkit-text-fill-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'funfact_post_symbol_hover_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .post-symbol:hover' => '-webkit-text-stroke-width: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'funfact_post_symbol_hover_typography',
				'selector' 	=> '{{WRAPPER}} .post-symbol:hover',
			]
		);
		$this->add_responsive_control(
			'funfact_post_symbol_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-symbol:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'funfact_post_symbol_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-symbol:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'funfact_post_symbol_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'funfact_post_symbol_block_hover_stroke_color',
			[
				'label'     => esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .post-symbol' => '-webkit-text-stroke-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'funfact_post_symbol_block_hover_fill_color',
			[
				'label'     => esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .post-symbol' => '-webkit-text-fill-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'funfact_post_symbol_block_hover_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .post-symbol' => '-webkit-text-stroke-width: {{VALUE}};'
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Post Symbol Style ===== */




		/* ===== Begin Icons Style ===== */
		$this->start_controls_section(
			'icon_styling',
			[
				'label' => esc_html__( 'Icons Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .funfact-icon',
			]
		);
		$this->add_responsive_control(
			'icon_opacity',
			[
				'label' 		=> esc_html__( 'Icon Opacity', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .funfact-icon' => 'opacity: {{SIZE}};',
				],
			]
		);
		$this->start_controls_tabs( 'icon_tab' );

		$this->start_controls_tab(
			'icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .funfact-block:hover .funfact-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Social Icons Style ===== */


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$firecore_icons = $settings['firecore_icons']['value'];
		$title = $settings['title'];
		$title_tag = $settings['title_tag'];
		$allowed_tags = wp_kses_allowed_html('post');

		switch ( $settings['funfact_styles'] ) {
			case 'style_1':
				include firecore_get_template( '/funfact/style1.php' );
				break;

			case 'style_2':
				include firecore_get_template( '/funfact/style2.php' );
				break;

			case 'style_3':
				include firecore_get_template( '/funfact/style3.php' );
				break;
		}
	}
}