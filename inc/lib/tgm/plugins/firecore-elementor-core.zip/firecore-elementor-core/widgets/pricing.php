<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_Pricing extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-pricing';
	}

	public function get_title() {
		return esc_html__( 'Pricing', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'pricing_styles',
			[
				'label' => __( 'Pricing Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'pricing_gradient_styles',
			[
				'label' => __( 'Color Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'color_style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'color_style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
				],
				'default' => 'color_style_1'
			]
		);
		$this->add_responsive_control(
			'pricing_alignments',
			[
				'label' => __('Alignments', 'firecore-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .pricing-item ' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$this->add_control(
			'pricing_item_active',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Active Item?', 'firecore-elementor-core' ),
				'label_on' => esc_html__( 'Yes', 'firecore-elementor-core' ),
				'label_off' => esc_html__( 'No', 'firecore-elementor-core' ),
				'return_value' => 'active',
				'separator' => 'before',
			]
		);
		$this->add_control('pricing_label', [
			'label' => esc_html__('Pricing Label', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => esc_html__('Recommend', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('title', [
			'label' => esc_html__('Pricing Title', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => esc_html__('Basic Plan', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('description', [
			'label' => esc_html__('Pricing Description', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXTAREA,
			'default' => esc_html__('Lorem ipsum dolor sit amet consectetur adipiscing.', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('price_currency', [
			'label' => __('Currency', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => __('$', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('price_monthly_amount', [
			'label' => __('Monthly Amount', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => __('80', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('price_yearly_amount', [
			'label' => __('Yearly Amount', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => __('299', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('price_unit', [
			'label' => __('Price Unit Monthly', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => __('/ month', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('price_unit_yearly', [
			'label' => __('Price Unit Yearly', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => __('/ year', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Text Button', 'firecore-elementor-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Read more ', 'firecore-elementor-core' ),
			],
		);
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__( "Button Link URL", 'firecore-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
				]
			]
		);
		$this->add_control('pricing_features_title', [
			'label' => esc_html__('Pricing Feature Title', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => esc_html__('Services Include:', 'firecore-elementor-core'),
			'label_block' => true,
		]);
		$this->add_control('pricing_features_subtitle', [
			'label' => esc_html__('Pricing Feature Sub Title', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXTAREA,
			'default' => esc_html__('Lorem ipsum dolor sit amet consectetur.', 'firecore-elementor-core'),
			'label_block' => true,
		]);



		$repeater = new Repeater();

		$repeater->add_control('pricing_features_item', [
			'label' => esc_html__('Features Title', 'firecore-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'label_block' => true,
		]);
		$repeater->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
			]
		);
		$this->add_control('features_list', [
			'label' => esc_html__('Feature Item List', 'firecore-elementor-core'),
			'type' => Controls_Manager::REPEATER,
			'fields' => $repeater->get_controls(),
			'default' => [
				[
					'pricing_features_item' => esc_html__('Business Planning', 'firecore-elementor-core'),
					'firecore_icons' => [
						'value' => 'webexbase-icon-check1',
						'library' => 'firecore_base_icon',
					],
				],
				[
					'pricing_features_item' => esc_html__('24/7 Customer Support', 'firecore-elementor-core'),
					'firecore_icons' => [
						'value' => 'webexbase-icon-check1',
						'library' => 'firecore_base_icon',
					],
				],
			],
			'title_field' => '{{{ pricing_features_item }}}',
		]);


		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/














/*===================================
		Start Pricing Wrapper Style
		=====================================*/
		$this->start_controls_section(
			'pricing_wrapper_style',
			[
				'label' 	=> esc_html__( 'Pricing Wrapper Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'pricing_wrapper_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'pricing_wrapper_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_wrapper_border',
				'selector' => '{{WRAPPER}} .pricing-item',
			]
		);
		$this->add_responsive_control(
			'pricing_wrapper_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'pricing_wrapper_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Pricing Title Style
		=====================================*/

		/*===================================
		Start Pricing Title Style
		=====================================*/
		$this->start_controls_section(
			'pricing_title_style',
			[
				'label' 	=> esc_html__( 'Pricing Title Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'pricing_title_typography',
				'selector' 	=> '{{WRAPPER}} .pricing-item .pricing-plan-name',
			]
		);
		$this->add_control(
			'pricing_title_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .pricing-plan-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'pricing_title_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .pricing-plan-name' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'pricing_title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item .pricing-plan-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'pricing_title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item .pricing-plan-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Pricing Title Style
		=====================================*/

		/*===================================
		Start Currency Style
		=====================================*/
		$this->start_controls_section(
			'currency_style',
			[
				'label' 	=> esc_html__( 'Currency Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'currency_typography',
				'selector' 	=> '{{WRAPPER}} .pricing-item .price-currency',
			]
		);
		$this->add_control(
			'currency_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .price-currency' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Currency Style
		=====================================*/

		/*===================================
		Start Price Amount Style
		=====================================*/
		$this->start_controls_section(
			'price_amount_style',
			[
				'label' 	=> esc_html__( 'Price Amount Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'price_amount_typography',
				'selector' 	=> '{{WRAPPER}} .pricing-item .price-amount',
			]
		);
		$this->add_control(
			'price_amount_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .price-amount' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Currency Style
		=====================================*/

		/*===================================
		Start Price Unit Style
		=====================================*/
		$this->start_controls_section(
			'price_unit_style',
			[
				'label' 	=> esc_html__( 'Price Unit Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'price_unit_typography',
				'selector' 	=> '{{WRAPPER}} .pricing-item .price-unit',
			]
		);
		$this->add_control(
			'price_unit_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .price-unit' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Currency Style
		=====================================*/

		/*===================================
		Start Features Title Style
		=====================================*/
		$this->start_controls_section(
			'pricing_features_item_style',
			[
				'label' 	=> esc_html__( 'Features Title Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'pricing_features_item_typography',
				'selector' 	=> '{{WRAPPER}} .pricing-item .list-items li',
			]
		);
		$this->add_control(
			'pricing_features_item_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .list-items li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'pricing_features_item_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item .list-items li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'pricing_features_item_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item .list-items li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Currency Style
		=====================================*/

		/* ===== Begin Button Style ===== */
		$this->start_controls_section(
			'pricing_button_style',
			[
				'label' => esc_html__( 'Button Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'pricing_button_tabs' );
		$this->start_controls_tab(
			'pricing_button_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'pricing_button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .animate-btn-style2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'pricing_button_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .animate-btn-style2' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'pricing_button_normal_bg_object_color',
			[
				'label'     => esc_html__( 'Background Object Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .animate-btn-style2:before' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .pricing-item .animate-btn-style2:after' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_button_normal_border',
				'selector' => '{{WRAPPER}} .pricing-item .animate-btn-style2',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'pricing_button_normal_typography',
				'selector' 	=> '{{WRAPPER}} .pricing-item .animate-btn-style2',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'pricing_button_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'pricing_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .animate-btn-style2:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'pricing_button_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .animate-btn-style2:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'pricing_button_hover_bg_object_color',
			[
				'label'     => esc_html__( 'Background Object Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-item .animate-btn-style2:before' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .pricing-item .animate-btn-style2:after' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_button_hover_border',
				'selector' => '{{WRAPPER}} .pricing-item .animate-btn-style2:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'pricing_button_hover_typography',
				'selector' 	=> '{{WRAPPER}} .pricing-item .animate-btn-style2:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'pricing_button_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item .animate-btn-style2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'pricing_button_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-item .animate-btn-style2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Subtitle Style ===== */

	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html( 'post' );
		$button_text = $settings['button_text'];
		$button_link = $settings['button_link'];
		$btn_target = ( $button_link && $button_link['is_external'] ) ? ' target="_blank"' : '';
		$btn_url = ( $button_link && $button_link['url'] ) ? $button_link['url'] : '';

		$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : '';

		if ( $settings['pricing_styles'] == 'style_1' ) {
			include firecore_get_template('/pricing/style1.php');
		}
		if ( $settings['pricing_styles'] == 'style_2' ) {
			include firecore_get_template('/pricing/style2.php');
		}
	}

}
