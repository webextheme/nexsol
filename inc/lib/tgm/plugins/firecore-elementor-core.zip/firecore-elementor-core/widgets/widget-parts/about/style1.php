<div class="about-image-box-style1 about-side-line wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
	<div class="about-image1">
		<img class="img-full" src="<?php echo esc_url( $about_s1_image1_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
	</div>
	<div class="panel wow"></div>
	<div class="about-image2 js-tilt d-none d-md-block d-lg-block d-xl-block">
		<img class=" img-full" src="<?php echo esc_url( $about_s1_image2_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
	</div>
</div>