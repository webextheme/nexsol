<div class="services-block services-block-<?php echo esc_attr( $settings['services_styles'] ) ?>">
  <div class="services-box-outer">
    <div class="services-inner">
      <!-- Icon -->
      <?php if ( !empty($firecore_icons) ): ?>
        <i class="services-icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
      <?php endif; ?>
      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
      <?php echo '<'. esc_attr( $title_tag ) .' class="services-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($title , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($title , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>
    </div>
  </div>
</div>