<div class="feature-box-block feature-box-block-<?php echo esc_attr( $settings['feature_box_styles'] ) ?>">
  <div class="feature-box-outer">
    <div class="feature-box-inner">
      <div class="feature-box-content">
        <!-- counting -->
        <?php if( !empty( $counting ) ) : ?>
          <span class="counting"><?php echo esc_html( $counting ) ?></span>
        <?php endif; ?>
        <!-- Title -->
        <?php if( !empty( $title ) ) : ?>
        <?php echo '<'. esc_attr( $title_tag ) .' class="feature-box-title">'; ?>
          <?php if( !empty( $url ) ): ?>
          <a
            <?php echo $target;?>
            href="<?php echo esc_url( $url );?>">
            <?php echo wp_kses($title , $allowed_tags) ?>
          </a>
          <?php else: ?>
            <?php echo wp_kses($title , $allowed_tags) ?>
          <?php endif ?>
        <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
        <?php endif; ?>

        <!-- Description -->
        <?php if( !empty( $description ) ) : ?>
          <p class="feature-box-description"><?php echo esc_html( $description ) ?></p>
        <?php endif; ?>
      </div>
      <div class="feature-box-thumb">
        <img class=" img-full" src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
      </div>
    </div>
  </div>
</div>