<div class="project-block project-block-<?php echo esc_attr( $settings['project_styles'] ) ?> <?php echo esc_attr( $settings['project_gradient_styles'] ) ?>">
  <div class="project-thumb">
    <?php echo get_the_post_thumbnail( $get_id, $settings['project_image'] ) ?>
    <?php if( 'yes' == $settings['link_btn_show_hide'] ): ?>
    <div class="project-link-icon">
      <a href="<?php echo esc_url( get_the_permalink() ) ?>"><i class="webexbase-icon-up-right-arrow"></i></a>
    </div>
    <?php endif;?>
    <?php if( !empty( $categories_list ) && ( 'yes' == $settings['project_category_show_hide'] ) ) : ?>
    <div class="project-category"><?php echo $categories_list ?></div>
    <?php endif;?>
  </div>
  <div class="project-details">
    <h4 class="project-title"><a href="<?php echo esc_url( get_the_permalink() ) ?>"><?php echo esc_html( $the_title ) ?></a></h4>
    <?php if( 'yes' == $settings['excerpt_show_hide'] ): ?>
      <?php if( has_excerpt() ): ?>
      <div class="post-excerpt"><?php echo wp_trim_words( get_the_excerpt(), $excerpt_count, '' ); ?></div>
      <?php else: ?>
      <div class="post-excerpt"><?php echo wp_trim_words( get_the_excerpt(), $excerpt_count, '' ); ?></div>
      <?php endif;?>
    <?php endif;?>
  </div>
</div>