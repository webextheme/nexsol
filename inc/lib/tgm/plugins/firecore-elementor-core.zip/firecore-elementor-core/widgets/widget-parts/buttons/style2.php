<div class="theme_btn_block_style2">
  <a href="<?php echo esc_url($settings['button_link']['url']);?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> class="btn_style2 firecore_btn <?php echo esc_attr($settings['button_size']); ?>"><?php echo esc_html($settings['button_text']);?></a>
</div>