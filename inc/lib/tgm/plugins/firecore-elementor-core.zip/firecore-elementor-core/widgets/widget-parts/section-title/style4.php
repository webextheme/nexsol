<div class="section_title section_title_<?php echo esc_attr( $settings['heading_styles'] ) ?> <?php echo esc_attr( $settings['heading_gradient_styles'] ) ?>">
  <?php if ( !empty($subtitle) ): ?>
    <?php echo '<'. esc_html( $settings['subtitle_tag'] ) .' class="subtitle">'; ?>
    <?php echo wp_kses($subtitle , $allowed_tags) ?>
    <?php echo '</'. esc_html( $settings['subtitle_tag'] ) .'>' ?>
  <?php endif; ?>

  <?php if ( !empty($title) ): ?>
    <div class="section_title_anim <?php echo esc_attr( $settings['heading_title_anim_styles'] ) ?>">
    <?php echo '<'. esc_html( $settings['title_tag'] ) .' class="title anim-title">'; ?>
    <?php if ( $title_link != '' ): ?>
      <a href="<?php echo esc_url( $title_link ); ?>"<?php printf( $target ); ?> title="<?php esc_attr($title); ?>">
        <?php echo wp_kses($title , $allowed_tags) ?>
      </a>
    <?php else: ?>
      <?php echo wp_kses($title , $allowed_tags) ?>
    <?php endif; ?>
    <?php echo '</'. esc_html( $settings['title_tag'] ) .'>' ?>
    </div>
  <?php endif; ?>
</div>