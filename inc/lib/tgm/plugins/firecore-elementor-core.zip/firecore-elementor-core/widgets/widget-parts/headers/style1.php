<?php
$main_menu_contact_info_icon = $settings['main_menu_contact_info_icon']['value'];
$firecore_enable_sticky_header = firecore_options('firecore_enable_sticky_header');
if ($firecore_enable_sticky_header ==  true) {
	$sticky_header = 'sticky-header';
} else {
	$sticky_header = 'disable-sticky-header';
}
?>
<header class="header-style-02">
  <?php if ( !empty($show_topbar) ): ?>
  <div class="header-topbar">
    <div class="custom-md-container">
      <div class="header-topbar-inner">
        <div class="header-topbar-leftpart">
          <ul class="topbar-info">
            <?php foreach( $items_info as $item ):
              $type 	= $item['type'];
              ?>
              <li>
                <?php if ( !empty($item['icon']) && $item['icon']['value'] != '' ): ?>
                <i class="<?php echo esc_attr( $item['icon']['value'] ); ?>"></i>
                <?php endif; ?>
                <?php switch ( $type ) {
                  case 'email':
                    $email_address = $item['email_address'];
                    $email_label = $item['email_label'];
                    if( $email_address && $email_label ){
                    ?>
                      <a href="mailto:<?php echo esc_attr( $email_address ) ?> " title="<?php esc_attr_e( 'address', 'firecore-elementor-core' ); ?>">
                        <?php echo esc_html( $email_label ); ?>
                      </a>
                    <?php
                  }
                  break;
                  case 'phone':
                    $phone_address = $item['phone_address'];
                    $phone_label = $item['phone_label'];
                    if( $phone_address && $phone_label ){
                    ?>
                      <a href="tel:<?php echo esc_attr( $phone_address ) ?> " title="<?php esc_attr_e( 'address', 'firecore-elementor-core' ); ?>">
                        <?php echo esc_html( $phone_label ); ?>
                      </a>
                    <?php
                    }
                  break;
                  case 'text':
                    $text = $item['text'];
                    ?>
                      <?php echo esc_html( $text ); ?>
                    <?php
                  break;
                  default:
                  break;
                } ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
        <div class="header-topbar-rightpart">
          <?php if ( !empty($show_header_top_menu) ): ?>
            <?php
              $args = [
                'container'       => 'div',
                'container_class' => 'topbar-nav-area',
                'menu_class'      => 'topbar-nav',
                'after'           => '',
                'link_before'     => '<span class="link-text">',
                'link_after'      => '</span>',
                'fallback_cb'     => false,
              ];
              if ( 'custom' == $settings['header_top_menu_type'] && ! empty( $settings['header_top_selected_menu'] ) ) {
                $args['menu'] = $settings['header_top_selected_menu'];
              } elseif ( has_nav_menu( 'header_topbar_menu' ) ) {
                $args['theme_location'] = 'header_topbar_menu';
              }
            ?>
            <?php wp_nav_menu( $args );?>
          <?php endif; ?>
          <?php if ( !empty($show_social) ): ?>
          <?php if(!empty($settings['social_icon_list'])):?>
          <ul class="topbar-social">
            <?php foreach($settings['social_icon_list'] as $social_icon):
              $social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
              $social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
            ?>
            <li>
              <a href="<?php echo esc_url($social_icon['icon_link']['url']);?>" aria-label="Social Link"
                class="<?php echo esc_attr($social_icon['social_icon']['value']);?>">
              </a>
            </li>
            <?php  endforeach;?>
          </ul>
          <?php endif;?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
  <nav class="main-menu <?php echo esc_attr($sticky_header); ?>">
    <div class="custom-md-container">
      <div class="main-menu-inner">
        <div class="main-menu-logo">
          <a href="<?php echo esc_url( $url ) ?>">
          <?php if ( 'custom' === $settings['logo_form'] ): ?>
            <?php if ( 'text' === $settings['logo_type'] ): ?>
              <?php echo esc_html( $settings['text_logo'] ) ?>
            <?php elseif ( $settings['main_logo']['url'] ): ?>
              <img src="<?php echo esc_url( $settings['main_logo']['url'] ) ?>" alt="<?php echo get_bloginfo() ?>">
            <?php endif;?>
          <?php else: ?>
            <?php if ( 'text' === $site_logo_type && ! empty( $site_text_logo ) ): ?>
              <?php echo esc_html( $site_text_logo ) ?>
            <?php elseif ( 'image' === $site_logo_type && ! empty( $main_logo['url'] ) ): ?>
              <img src="<?php echo esc_url( $main_logo['url'] ) ?>" alt="<?php echo get_bloginfo() ?>">
            <?php endif;?>
          <?php endif;?>
          </a>
        </div>
        <?php
          $args = [
            'container'       => 'ul',
            'menu_class'      => 'main-nav-menu',
            'after'           => '',
            'link_before'     => '<span class="link-text">',
            'link_after'      => '</span>',
            'fallback_cb'     => false,
          ];
          if ( 'primary-custom' == $settings['header_primary_menu_type'] && ! empty( $settings['header_primary_selected_menu'] ) ) {
            $args['menu'] = $settings['header_primary_selected_menu'];
          } elseif ( has_nav_menu( 'primary' ) ) {
            $args['theme_location'] = 'primary';
          }
        ?>
			  <?php wp_nav_menu( $args );?>
        <div class="main-menu-right">
          <a href="#" aria-label="Mobile Nav" class="mobile-nav-toggler">
            <span></span>
            <span></span>
            <span></span>
          </a>
          <?php if ( !empty($show_search_icon) ): ?>
          <a href="#" aria-label="Search" class="search-toggler d-none d-xl-flex">
            <i class="webexbase-icon-magnifying-glass2"></i>
          </a>
          <?php endif; ?>

          <?php if ( !empty($show_main_menu_contact_info) ): ?>
          <div class="header-contact-info">
            <?php if ( !empty($main_menu_contact_info_icon) ): ?>
              <div class="header-contact-info-icon">
                <i class="<?php echo esc_attr( $main_menu_contact_info_icon ); ?>"></i>
              </div>
            <?php endif; ?>
            <div class="header-contact-info-text">
              <?php if(!empty($main_menu_contact_info_title)):?>
              <p class="call-text"><?php echo esc_html($main_menu_contact_info_title);?></p>
              <?php endif; ?>

              <?php if( $label ){ ?>
                <p class="call-text"><?php echo esc_html( $label ); ?></p>
              <?php } ?>

              <?php
                $main_menu_contact_info_type = $settings['main_menu_contact_info_type'];
                switch ( $main_menu_contact_info_type ) {
                case 'email':
                  $main_menu_contact_info_email_address = $settings['main_menu_contact_info_email_address'];
                  $main_menu_contact_info_email_label = $settings['main_menu_contact_info_email_label'];
                  if( $main_menu_contact_info_email_address && $main_menu_contact_info_email_label ) {
                  ?>
                    <a href="mailto:<?php echo esc_attr( $main_menu_contact_info_email_address ); ?>"
                      title="<?php esc_attr_e( 'email address', 'firecore-elementor-core' ); ?>">
                      <?php echo esc_html( $main_menu_contact_info_email_label ); ?>
                    </a>
                  <?php
                  }
                break;

                case 'phone':
                  $main_menu_contact_info_phone_address = $settings['main_menu_contact_info_phone_address'];
                  $main_menu_contact_info_phone_label = $settings['main_menu_contact_info_phone_label'];
                  if( $main_menu_contact_info_phone_address && $main_menu_contact_info_phone_label ) {
                  ?>
                    <a href="tel:<?php echo esc_attr( $main_menu_contact_info_phone_address ); ?>"
                      title="<?php esc_attr_e( 'phone address', 'firecore-elementor-core' ); ?>">
                        <?php echo esc_html( $main_menu_contact_info_phone_label ); ?>
                    </a>
                  <?php
                  }
                break;

                case 'text':
                  $main_menu_contact_info_text = $settings['main_menu_contact_info_text'];
                  if( $main_menu_contact_info_text ) {
                    echo esc_html( $main_menu_contact_info_text );
                  }
                break;
                default:
                break;
              }
              ?>
            </div>
          </div>
          <?php endif; ?>

        </div>
      </div>
    </div>
  </nav>
</header>