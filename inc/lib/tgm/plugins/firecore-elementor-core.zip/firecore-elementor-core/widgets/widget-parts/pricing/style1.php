<div class="pricing-style1 <?php echo esc_html($settings['pricing_item_active']); ?>">
  <div class="pricing-item">
    <div class="table-header">
      <?php if (!empty($settings['pricing_label'])) : ?>
        <span class="pricing-label"><?php echo esc_html($settings['pricing_label']); ?></span>
      <?php endif; ?>
      <?php if (!empty($settings['title'])) : ?>
        <h6 class="pricing-plan-name"><?php echo esc_html($settings['title']); ?></h6>
      <?php endif; ?>
      <div class="price-wrap">
        <span class="price-currency"><?php echo esc_html($settings['price_currency']); ?></span>
        <?php if (!empty($settings['price_monthly_amount'])) : ?>
        <div class="price-amount monthlyPrice"><?php echo esc_html($settings['price_monthly_amount']); ?></div>
        <?php endif; ?>
        <?php if (!empty($settings['price_yearly_amount'])) : ?>
        <div class="price-amount yearlyPrice"><?php echo esc_html($settings['price_yearly_amount']); ?></div>
        <?php endif; ?>
        <?php if (!empty($settings['price_unit'])) : ?>
        <div class="price-unit"><?php echo esc_html($settings['price_unit']); ?></div>
        <?php endif; ?>
      </div>
      <?php if (!empty($settings['description'])) : ?>
        <div class="pricing-plan-description"><?php echo esc_html($settings['description']); ?></div>
      <?php endif; ?>
      <?php if (!empty($settings['button_text'])) : ?>
      <div class="table-footer">
        <div class="firecore_btn_block">
          <a href="<?php echo esc_url($settings['button_link']['url']);?>" <?php echo esc_attr($btn_target); ?> class="cs-btn-one btn-secordary-color firecore_btn btn-block"><?php echo esc_html($settings['button_text']);?></a>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <div class="table-content">
      <?php if (!empty($settings['pricing_features_title'])) : ?>
        <div class="pricing_features_title"><?php echo esc_html($settings['pricing_features_title']); ?></div>
      <?php endif; ?>
      <?php if (!empty($settings['pricing_features_subtitle'])) : ?>
        <div class="pricing_features_subtitle"><?php echo esc_html($settings['pricing_features_subtitle']); ?></div>
      <?php endif; ?>
      <?php if (is_array($settings['features_list'])) : ?>
        <ul class="list-items">
          <?php foreach ($settings['features_list'] as $item) : ?>
            <li>
              <?php if ( !empty($item['firecore_icons']['value']) ): ?>
                <i class="pricing_list_icon <?php echo esc_attr( $item['firecore_icons']['value'] ); ?>"></i>
              <?php endif; ?>
              <?php echo esc_html($item['pricing_features_item']); ?>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>