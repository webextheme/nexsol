<div class="about-image-box-style3">
	<div class="about-image1 js-tilt">
		<img class="img-full d-none d-md-none d-lg-block d-xl-block" src="<?php echo esc_url( $about_s3_image1_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
	</div>

	<div class="about-image2">
		<img class="img-full" src="<?php echo esc_url( $about_s3_image2_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
	</div>
	<div class="panel wow"></div>

	<?php if( 'yes' == $settings['experience_box_show_hide'] ) : ?>
	<div class="call-us-now">
		<?php if ( !empty($experience_years) ): ?>
			<h3 class="years"><?php echo esc_html( $experience_years ); ?>+</h3>
		<?php endif; ?>

		<?php if ( !empty($experience_text) ): ?>
			<p class="experience-text"><?php echo esc_html( $experience_text ); ?></p>
		<?php endif; ?>
	</div>
	<?php endif; ?>
</div>