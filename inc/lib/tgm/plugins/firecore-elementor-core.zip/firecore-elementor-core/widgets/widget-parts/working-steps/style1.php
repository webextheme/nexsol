<div class="working-steps-block gsap-line-anim working-steps-block-<?php echo esc_attr( $settings['working_steps_styles'] ) ?>">
  <div class="working-steps-inner">
    <div class="progress-line">
      <div class="v-line"></div>
    </div>
    <div class="working-details">
      <!-- Description -->
      <?php if( !empty( $counting ) ) : ?>
      <div class="working-count"><span><?php echo esc_html( $counting ) ?></span></div>
      <?php endif; ?>
      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
        <?php echo '<'. esc_attr( $title_tag ) .' class="working-title">'; ?>
          <?php echo esc_html( $title ) ?>
        <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>
      <!-- Description -->
      <?php if( !empty( $description ) ) : ?>
        <?php echo wp_kses($description , $allowed_tags) ?>
      <?php endif; ?>
    </div>
  </div>
</div>