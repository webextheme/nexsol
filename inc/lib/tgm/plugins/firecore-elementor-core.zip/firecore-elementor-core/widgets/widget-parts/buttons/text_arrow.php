<div class="firecore_text_arrow_btn_block">
  <a class="arrow_btn_style1" href="<?php echo esc_url($settings['button_link']['url']);?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>>
    <span class="btn_text firecore_btn"><?php echo esc_html($settings['button_text']);?></span>
    <i class="firecore_btn_icon webexbase-icon-up-right-arrow-1"></i>
  </a>
</div>