<div class="testimonial-block testimonial-block-<?php echo esc_attr( $settings['testimonial_styles'] ) ?>">
  <div class="testimonial-outer">
    <div class="testimonial-inner">
    <div class="testimonial-content">
      <?php if( ( 'yes' == $settings['ratings_show_hide'] ) ) : ?>
      <!-- Ratings -->
      <?php
        printf( '<div class="star-rating">%1$s</div>',
        $this->render_stars( $item['rating'] )
        );
      ?>
      <?php endif; ?>
      <?php if( !empty( $description ) ) : ?>
        <p class="comments"><?php echo esc_html( $description ) ?></p>
      <?php endif; ?>
    </div>
    <div class="testimonial-bottom-part">
      <div class="testimonial-info">
        <div class="testimonial-title-area">
          <?php if( !empty( $title ) && ( 'yes' == $settings['title_show_hide'] ) ) : ?>
          <!-- Title -->
          <?php echo '<'. esc_attr( $title_tag ) .' class="testimonial-title">'; ?>
            <?php if( !empty( $url ) ): ?>
            <a
              <?php echo $target;?>
              href="<?php echo esc_url( $url );?>">
              <?php echo esc_html( $title ) ?>
            </a>
            <?php else: ?>
              <?php echo esc_html( $title ) ?>
            <?php endif ?>
          <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
          <?php endif; ?>
          <?php if( !empty( $subtitle ) && ( 'yes' == $settings['subtitle_show_hide'] ) ) : ?>
          <!-- Subtitle -->
            <?php echo '<'. esc_attr( $subtitle_tag ) .' class="testimonial-subtitle">'; ?>
              <?php echo esc_html( $subtitle ) ?>
            <?php echo '</'. esc_attr( $subtitle_tag ) .'>' ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php if( !empty( $firecore_icons ) && ( 'yes' == $settings['quote_icon_show_hide'] ) ) : ?>
    <!-- Icon -->
      <i class="testimonial-quote-icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
    <?php endif; ?>
  </div>
  </div>
  <?php if( !empty( $image_url ) && isset( $image_url ) ) : ?>
  <div class="testimonial-thumb">
    <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
  </div>
  <?php endif; ?>
</div>