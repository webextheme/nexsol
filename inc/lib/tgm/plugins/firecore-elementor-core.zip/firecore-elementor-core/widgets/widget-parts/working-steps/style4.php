<div class="working-steps-block working-steps-block-<?php echo esc_attr( $settings['working_steps_styles'] ) ?>">
  <div class="working-steps-outer">
    <div class="working-steps-inner">
      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
      <?php echo '<'. esc_attr( $title_tag ) .' class="working-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($title , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($title , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>

      <!-- Description -->
      <?php if( !empty( $description ) ) : ?>
        <p class="working-description"><?php echo esc_html( $description ) ?></p>
      <?php endif; ?>
    </div>
  </div>
  <!-- counting -->
  <?php if( !empty( $counting ) ) : ?>
    <span class="counting"><?php echo esc_html( $counting ) ?></span>
  <?php endif; ?>
</div>