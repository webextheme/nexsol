<div class="working-steps-block gsap-line-anim working-steps-block-<?php echo esc_attr( $settings['working_steps_styles'] ) ?>">
  <div class="working-steps-inner">
    <div class="progress-line">
      <div class="v-line"></div>
    </div>
    <div class="working-details">
      <div class="working-icon">
        <!-- Icon -->
        <?php if ( !empty($firecore_icons) ): ?>
          <i class="icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
        <?php endif; ?>
      </div>
      <div class="working-content">
        <!-- Title -->
        <?php if( !empty( $title ) ) : ?>
          <?php echo '<'. esc_attr( $title_tag ) .' class="working-title">'; ?>
            <?php echo esc_html( $title ) ?>
          <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
        <?php endif; ?>
        <!-- Description -->
        <?php if( !empty( $description ) ) : ?>
          <?php echo wp_kses($description , $allowed_tags) ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>