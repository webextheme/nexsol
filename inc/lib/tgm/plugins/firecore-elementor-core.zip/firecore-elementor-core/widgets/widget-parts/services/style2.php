<div class="services-block services-block-<?php echo esc_attr( $settings['services_styles'] ) ?>">
  <div class="services-inner">
    <div class="title-area">
      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
      <?php echo '<'. esc_attr( $title_tag ) .' class="services-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($title , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($title , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>
      <!-- Icon -->
      <?php if ( !empty($firecore_icons) ): ?>
        <i class="services-icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
      <?php endif; ?>
    </div>
    <div class="service-thumb">
      <img class="img-full" src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
    </div>
    <!-- Description -->
    <?php if( !empty( $description ) ) : ?>
    <p class="services-description"><?php echo esc_html( $description ) ?></p>
	  <?php endif; ?>
    <!-- Button -->
    <div class="services-button">
      <a class="text-btn link-btn" <?php echo $btn_target;?> href="<?php echo esc_url( $btn_url );?>"><?php echo esc_html($button_text); ?></a>
    </div>
  </div>
</div>