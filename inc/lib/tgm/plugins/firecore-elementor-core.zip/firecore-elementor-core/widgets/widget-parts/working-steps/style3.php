<div class="working-steps-block working-steps-block-<?php echo esc_attr( $settings['working_steps_styles'] ) ?>">
  <div class="working-steps-inner">
    <div class="working-thumb-part">
      <div class="working-thumb">
        <img class="img-full" src="<?php echo esc_url( $working_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
      </div>
      <!-- counting -->
      <?php if( !empty( $counting ) ) : ?>
        <span class="counting"><?php echo wp_kses($counting , $allowed_tags) ?></span>
      <?php endif; ?>
      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
      <?php echo '<'. esc_attr( $title_tag ) .' class="working-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($title , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($title , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>
    </div>
    <!-- Description -->
    <?php if( !empty( $description ) ) : ?>
      <p class="working-description"><?php echo esc_html( $description ) ?></p>
    <?php endif; ?>
  </div>
</div>