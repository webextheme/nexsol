<div class="award-box-block award-box-block-<?php echo esc_attr( $settings['award_box_styles'] ) ?>">
  <div class="award-box-inner">

    <div class="title-area">
      <!-- Subtitle -->
      <?php if( !empty( $subtitle ) ) : ?>
        <?php echo '<'. esc_attr( $subtitle_tag ) .' class="award-box-subtitle">'; ?>
          <?php echo esc_html( $subtitle ) ?>
        <?php echo '</'. esc_attr( $subtitle_tag ) .'>' ?>
      <?php endif; ?>

      <!-- Title -->
      <?php if( !empty( $title ) ) : ?>
      <?php echo '<'. esc_attr( $title_tag ) .' class="award-box-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($title , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($title , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
      <?php endif; ?>
    </div>

    <?php if ( !empty($image_url) && ( 'yes' == $settings['award_box_image_show_hide'] ) ): ?>
    <div class="award-thumb">
      <img class=" img-full" src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
    </div>
    <?php endif; ?>

    <!-- Icon -->
    <?php if ( !empty($firecore_icons) ): ?>
      <i class="award-box-icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
    <?php endif; ?>

    <!-- Description -->
    <?php if( !empty( $description ) ) : ?>
    <p class="award-box-description"><?php echo esc_html( $description ) ?></p>
	  <?php endif; ?>

  </div>
</div>