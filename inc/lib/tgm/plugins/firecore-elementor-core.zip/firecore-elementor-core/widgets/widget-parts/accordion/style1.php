<div class="faq-block faq-block-style1">
	<div class="accordion <?php echo esc_attr( $settings['accordion_gradient_styles'] ) ?>">
		<?php foreach ($settings['acordion_items'] as $keys => $item) :
			$firecore_icons = ! empty( $item['firecore_icons']['value'] ) ? $item['firecore_icons']['value'] : '';
			// Image handling
			$image_url = '';
			if ( ! empty( $item['photo'] ) ) {
				if ( ! empty( $item['photo']['id'] ) ) {
					$image_url = wp_get_attachment_url( $item['photo']['id'] );
				}
				elseif ( ! empty( $item['photo']['url'] ) ) {
					$image_url = esc_url( $item['photo']['url'] );
				}
			}
		?>
		<div class="accordion-item<?php if( '0' == $keys ) : ?> active<?php endif; ?>">
			<div class="accordion-header">
				<div class="accordion-upper-part">
					<!-- Icon -->
					<?php if ( !empty($firecore_icons) ): ?>
						<i class="accordion-icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
					<?php endif; ?>

					<!-- Title -->
					<?php if( !empty( $item['title'] ) ) : ?>
						<?php echo '<'. esc_attr( $item['title_tag'] ) .' class="title">'; ?>
							<?php echo wp_kses($item['title'] , $allowed_tags) ?>
						<?php echo '</'. esc_attr( $item['title_tag'] ) .'>' ?>
					<?php endif; ?>
				</div>

				<!-- Inactive Icon -->
				<?php if ( !empty($settings['firecore_inactive_icon']['value']) ): ?>
					<span class="inactive-icon <?php echo esc_attr( $settings['firecore_inactive_icon']['value'] ); ?>"></span>
				<?php endif; ?>
				<!-- Active Icon -->
				<?php if ( !empty($settings['firecore_active_icon']['value']) ): ?>
					<span class="active-icon <?php echo esc_attr( $settings['firecore_active_icon']['value'] ); ?>"></span>
				<?php endif; ?>
			</div>

			<div class="accordion-body">
				<div class="content-wrap">
					<div class="water-mark-icon">
						<!-- Icon -->
						<?php if ( !empty($firecore_icons) ): ?>
							<i class="accordion-icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
						<?php endif; ?>
					</div>
					<!-- Description -->
					<?php if( !empty( $item['description'] ) ) : ?>
					<p class="description"><?php echo esc_html( $item['description'] ) ?></p>
					<?php endif; ?>
					<div class="accordion-thumb">
						<img class=" img-full" src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
					</div>
				</div>
			</div>

		</div>
		<?php endforeach; ?>
	</div>
</div>