<div class="icon-box-item icon-box-style1 <?php echo esc_attr( $icon_text_alignments ); ?> <?php echo esc_attr( $icon_position ); ?> <?php echo esc_attr( $icon_v_alignment ); ?> <?php echo esc_attr( $icon_h_alignment ); ?>">

    <?php if ( ! empty( $icon ) ) : ?>
  <div class="featured-icon">
    <i class="webexflaticon <?php echo esc_attr( $icon ); ?>"></i>
  </div>
  <?php endif; ?>

  <div class="icon-details">
    <?php if ( ! empty( $icon_box_title ) ) : ?>
      <<?php echo tag_escape( $title_tag ); ?> class="icon-box-title">
        <?php echo wp_kses($icon_box_title , $allowed_tags) ?>
      </<?php echo tag_escape( $title_tag ); ?>>
    <?php endif; ?>

    <?php if ( ! empty( $icon_box_content ) ) : ?>
      <p class="icon-box-desc"><?php echo wp_kses( $icon_box_content, $allowed_tags ); ?></p>
    <?php endif; ?>
  </div>
</div>