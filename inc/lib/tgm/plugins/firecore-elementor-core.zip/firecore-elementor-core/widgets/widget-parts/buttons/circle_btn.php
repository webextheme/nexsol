
<div class="firecore_circle_btn_block circle_hover_btn">
  <div class="circle_btn_item">
    <a href="<?php echo esc_url($settings['button_link']['url']);?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> class="circle-btn-style1 firecore_btn"><?php echo esc_html($settings['button_text']);?> <i class="circle-btn-arrow webexbase-icon-black-arrow-1"></i> <br /><?php echo esc_html($settings['button_text2']);?></a>
    <span class="circle_btn_dot"></span>
  </div>
</div>