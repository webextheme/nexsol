<div class="about-image-box-style2 dot-circle wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
	<img class="about-image1 img-full js-tilt d-none d-md-block d-lg-block d-xl-block" src="<?php echo esc_url( $about_s2_image1_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
	<img class="about-image2 img-full" src="<?php echo esc_url( $about_s2_image2_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
	<?php if(!empty($about_s2_badge1_url)):?>
	<img class="about-badge1 img-full js-tilt" src="<?php echo esc_url( $about_s2_badge1_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
	<?php endif;?>
</div>