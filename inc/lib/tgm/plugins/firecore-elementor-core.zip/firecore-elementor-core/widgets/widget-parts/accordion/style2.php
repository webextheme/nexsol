<div class="faq-block faq-block-style2">
	<div class="accordion <?php echo esc_attr( $settings['accordion_gradient_styles'] ) ?>">
		<?php foreach ($settings['acordion_items'] as $keys => $item) : ?>
		<div class="accordion-item<?php if( '0' == $keys ) : ?> active<?php endif; ?>">
			<div class="accordion-header">
				<!-- Title -->
				<?php if( !empty( $item['title'] ) ) : ?>
					<?php echo '<'. esc_attr( $item['title_tag'] ) .' class="title">'; ?>
						<?php echo esc_html( $item['title'] ) ?>
					<?php echo '</'. esc_attr( $item['title_tag'] ) .'>' ?>
				<?php endif; ?>

				<!-- Inactive Icon -->
				<?php if ( !empty($settings['firecore_inactive_icon']['value']) ): ?>
					<span class="inactive-icon <?php echo esc_attr( $settings['firecore_inactive_icon']['value'] ); ?>"></span>
				<?php endif; ?>


				<!-- Active Icon -->
				<?php if ( !empty($settings['firecore_active_icon']['value']) ): ?>
					<span class="active-icon <?php echo esc_attr( $settings['firecore_active_icon']['value'] ); ?>"></span>
				<?php endif; ?>

			</div>

			<div class="accordion-body">
				<!-- Description -->
				<?php if( !empty( $item['description'] ) ) : ?>
				<p class="description"><?php echo esc_html( $item['description'] ) ?></p>
				<?php endif; ?>
			</div>

		</div>
		<?php endforeach; ?>
	</div>
</div>