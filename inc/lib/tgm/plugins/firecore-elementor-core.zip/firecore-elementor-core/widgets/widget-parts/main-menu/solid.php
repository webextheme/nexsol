<nav class="webex_main-menu">
  <?php
  $args = [
    'container'       => 'div',
    'container_class' => 'main-menu-inner menu-' . $settings['menu_alignment'],
    'menu_class'      => 'main-nav-menu_solid_menu',
    'after'           => '',
    'link_before'     => '<span class="link-text">',
    'link_after'      => '</span>',
    'fallback_cb'     => false,
  ];
  if ( 'custom' == $settings['menu_type'] && ! empty( $settings['selected_menu'] ) ) {
    $args['menu'] = $settings['selected_menu'];
  } elseif ( has_nav_menu( 'primary' ) ) {
    $args['theme_location'] = 'primary';
  }
  ?>
  <?php wp_nav_menu( $args );?>
</nav>
<?php
