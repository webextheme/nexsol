<div class="webex-form request-a-call-back-form">
	<?php if(!empty($settings['subtitle']) && ( 'yes' === $settings['sideline_show_hide'] )): ?>
		<h6 class="side-line-left form-subtitle"><?php echo esc_html($settings['subtitle']); ?></h6>
		<?php elseif (!empty($settings['subtitle'])): ?>
		<h6 class="form-subtitle"><?php echo esc_html($settings['subtitle']); ?></h6>
	<?php endif; ?>
	<?php if(!empty($settings['title'])): ?>
		<h3 class="form-title"><?php echo esc_html($settings['title']); ?></h3>
	<?php endif; ?>
	<?php if(!empty($settings['description'])): ?>
		<div class="form-description"><?php echo esc_html($settings['description']); ?></div>
	<?php endif; ?>
	<?php
		if( !empty($settings['firecore_select_contact_form']) ){
			echo do_shortcode( '[contact-form-7 id="'.$settings['firecore_select_contact_form'].'"]' );
		}else{
			echo '<div class="alert alert-danger"><p class="m-0">' . __('Please Select contact form.', 'firecore-elementor-core' ). '</p></div>';
		}
	?>
</div>