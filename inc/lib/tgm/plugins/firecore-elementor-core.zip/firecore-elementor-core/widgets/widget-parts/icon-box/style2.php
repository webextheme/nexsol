<div class="icon-box-item icon-box-style2 <?php echo esc_html( $settings['icon_text_alignments'] ); ?> <?php echo esc_html( $settings['icon_position'] ); ?> <?php echo esc_html( $settings['icon_v_alignment'] ); ?>">
	<?php if ( !empty($icon) ): ?>
	<div class="featured-icon">
		<i class="webexflaticon <?php echo esc_attr( $icon ); ?>"></i>
	</div>
	<?php endif; ?>
	<div class="icon-details">
		<?php if ( !empty($icon_box_title) ): ?>
			<?php echo '<'. esc_html( $settings['title_tag'] ) .' class="icon-box-title">'; ?>
        <?php echo wp_kses($icon_box_title , $allowed_tags) ?><?php echo '</'. esc_html( $settings['title_tag'] ) .'>' ?>
		<?php endif; ?>
		<p class="icon-box-desc"><?php echo wp_kses($icon_box_content , $allowed_tags) ?></p>
	</div>
</div>