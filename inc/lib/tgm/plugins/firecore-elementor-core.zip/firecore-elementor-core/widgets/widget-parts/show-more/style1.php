<div class="show-more-block show-more-block-style1">
  <div class="show-more-inner">
    <?php if ( !empty($firecore_icons) ): ?>
      <!-- Icon -->
      <div class="show-more-icon">
        <i class="icon <?php echo esc_attr( $firecore_icons ); ?>"></i>
      </div>
    <?php endif; ?>
    <?php if ( !empty($title) ): ?>
      <?php echo '<'. esc_html( $settings['title_tag'] ) .' class="title">'; ?> <?php echo wp_kses($title , $allowed_tags) ?>
        <span>
          <a href="<?php echo esc_url($settings['button_link']['url']);?>"
            class="btn-link"><?php echo esc_html($settings['button_text']);?>
          </a>
        </span>
      <?php echo '</'. esc_html( $settings['title_tag'] ) .'>' ?>
    <?php endif; ?>
  </div>
</div>