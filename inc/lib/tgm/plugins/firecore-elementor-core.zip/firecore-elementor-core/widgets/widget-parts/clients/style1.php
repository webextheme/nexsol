<div class="client-block client-item-<?php echo esc_attr( $settings['client_styles'] ) ?> <?php echo esc_attr( $settings['dark_light_styles'] ) ?>">
	<img src="<?php echo esc_url( $client_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
</div>