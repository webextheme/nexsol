<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;
use WP_Query;

class FIRECORE_News_Posts extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-news-posts';
	}

	public function get_title() {
		return esc_html__( 'News', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return array('allslider-js');
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin News Content ===== */
		$this->start_controls_section(
			'section_content_item',
			[
				'label' => esc_html__( 'News', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_styles',
			[
				'label' => __( 'News Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Layout', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid'   => esc_html__( 'Grid', 'firecore-elementor-core' ),
					'slider' => esc_html__( 'Slider', 'firecore-elementor-core' ),
				],
			]
		);
		$this->add_responsive_control(
			'column',
			[
				'label'                => esc_html__( 'Grid Column', 'firecore-elementor-core' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					''  => esc_html__( 'Default', 'firecore-elementor-core' ),
					'1' => esc_html__( '1 column', 'firecore-elementor-core' ),
					'2' => esc_html__( '2 column', 'firecore-elementor-core' ),
					'3' => esc_html__( '3 column', 'firecore-elementor-core' ),
					'4' => esc_html__( '4 column', 'firecore-elementor-core' ),
					'5' => esc_html__( '5 column', 'firecore-elementor-core' ),
					'6' => esc_html__( '6 column', 'firecore-elementor-core' ),
				],
				'default'              => 3,
				'tablet_extra_default' => '',
				'tablet_default'       => '',
				'mobile_default'       => '',
				'condition'            => [
					'layout' => 'grid',
				],
				'selectors'            => [
					'{{WRAPPER}} .news-block-wrapper' => 'grid-template-columns: repeat( {{VALUE}}, 1fr );',
				],
			]
		);
		$this->add_control(
			'item_number',
			[
				'label'       => esc_html__( 'Item Number', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'description' => esc_html__( 'Number Item', 'firecore-elementor-core' ),
				'default'     => 4,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'condition'            => [
					'layout' => 'slider',
				],
			]
		);
		$this->add_control(
			'news_image',
			[
				 'label'     => __('Style', 'firecore-elementor-core'),
				 'type'      => \Elementor\Controls_Manager::SELECT,
				 'options'   => get_thumbnail_size(),
				 'default'   => 'firecore-image(430x300)'
			]
		);
		$this->end_controls_section();


		$this->start_controls_section('query_content', [
			'label' => esc_html__('Query', 'firecore-elementor-core'),
		]);
		$this->add_control('post_from', [
			'label' => esc_html__('News From', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'all' => esc_html__('All News', 'firecore-elementor-core'),
				'categories' => esc_html__('Categories', 'firecore-elementor-core'),
				'specific-post' => esc_html__('Specific News', 'firecore-elementor-core'),
			],
			'default' => 'all',
		]);
		$this->add_control('post_ids', [
			'label' => esc_html__('Select News', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT2,
			'options' => firecore_select_posts(),
			'multiple' => true,
			'label_block' => true,
			'condition' => [
				'post_from' => 'specific-post',
			],
		]);
		$this->add_control('cat_slugs', [
			'label' => esc_html__('Select Categories', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT2,
			'options' => firecore_select_category(),
			'multiple' => true,
			'label_block' => true,
			'condition' => [
				'post_from' => 'categories',
			],
		]);

		$this->add_control('post_limit', [
			'label' => esc_html__('Item Show Per Page', 'firecore-elementor-core'),
			'type' => Controls_Manager::NUMBER,
			'default' => 3,
			'min' => 1,
		]);
		$this->add_control('order_by', [
			'label' => esc_html__('Order By', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'ID' => esc_html__('ID', 'firecore-elementor-core'),
				'author' => esc_html__('Author', 'firecore-elementor-core'),
				'title' => esc_html__('Title', 'firecore-elementor-core'),
				'date' => esc_html__('Date', 'firecore-elementor-core'),
				'rand' => esc_html__('Random', 'firecore-elementor-core'),
			],
			'default' => 'date',
		]);

		$this->add_control('sort_order', [
			'label' => esc_html__('Sort Order', 'firecore-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'ASC' => esc_html__('Ascending', 'firecore-elementor-core'),
				'DESC' => esc_html__('Descending', 'firecore-elementor-core'),
			],
			'default' => 'DESC',
		]);
		$this->add_control(
			'show_pagination',
			[
				'label'        => esc_html__( 'Show Pagination', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'firecore-elementor-core' ),
				'label_off'    => esc_html__( 'No', 'firecore-elementor-core' ),
				'return_value' => 'yes',
				'condition'    => [
					'layout' => 'grid',
				],
			]
		);

		$this->end_controls_section();

		/* ===== End News Content ===== */





		/* ===== Begin News Settings ===== */
		$this->start_controls_section(
			'section_content_settings',
			[
				'label' => esc_html__( 'News Settings', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_thumb_show_hide',
			[
				'label'        => esc_html__( 'Show Thumbnail?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'yes',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'excerpt_show_hide',
			[
				'label'        => esc_html__( 'Show Excerpt?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'yes',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'excerpt_count',
			[
				'label'     => esc_html__( 'Excerpt Word', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 12,
				'condition' => [
					'excerpt_show_hide' => 'yes',
				],
			]
		);
		$this->add_control(
			'news_category_show_hide',
			[
				'label'        => esc_html__( 'Show Category?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'no',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'news_thumb_date_show_hide',
			[
				'label'        => esc_html__( 'Show Date?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'yes',
				'separator' => 'after',
			]
		);
		$this->add_control(
			'choose_meta',
			[
				'label'       => esc_html__( 'Choose Meta', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'default'     => ['author', 'date', 'Comments'],
				'options'     => [
					'author'   => esc_html__( 'Author', 'firecore-elementor-core' ),
					'date'     => esc_html__( 'Date', 'firecore-elementor-core' ),
					'comments' => esc_html__( 'Comments', 'firecore-elementor-core' ),
				],
			]
		);
		$this->add_control(
			'news_post_top_meta_heading',
			[
				'label'     => esc_html__( 'News Meta Options', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_control(
			'hide_date',
			[
				'label'        => esc_html__( 'Show/Hide Date?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'no',
			]
		);
		$this->add_control(
			'hide_comments',
			[
				'label'        => esc_html__( 'Show/Hide Comments?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'no',
			]
		);
		$this->add_control(
			'hide_author',
			[
				'label'        => esc_html__( 'Show/Hide Author?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'no',
			]
		);
		$this->add_control(
			'author_photo',
			[
				'label'        => esc_html__( 'Show/Hide Author Image?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'firecore-elementor-core' ),
				'label_off'    => esc_html__( 'No', 'firecore-elementor-core' ),
				'default'      => 'yes',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'author_note',
			[
				'label'       => esc_html__( 'Author Note', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => false,
				'default'     => esc_html__( 'By', 'firecore-elementor-core' ),
			]
		);
		$this->end_controls_section();
		/* ===== End News Settings ===== */






		/* ===== Begin News Button Settings ===== */
		$this->start_controls_section(
			'section_news_button_settings',
			[
				'label' => esc_html__( 'News Button Settings', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_button',
			[
				'label'        => esc_html__( 'Show/Hide News Button?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'firecore-elementor-core' ),
				'label_off'    => esc_html__( 'No', 'firecore-elementor-core' ),
				'default'      => 'Yes',
				'separator' => 'before',
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'news_button_text',
			[
				'label'       => esc_html__( 'Button Text', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default' 		=>  esc_html__( 'Read More' , 'firecore-elementor-core'),
		]);
		$this->end_controls_section();
		/* ===== End News Button Settings ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'news_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .news-block-wrapper' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .news-block-wrapper' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->start_controls_tabs( 'news_item_tab' );
		$this->start_controls_tab(
			'news_item_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-block-wrapper .news-description' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .news-block-wrapper .news-description',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_normal_border',
				'selector' => '{{WRAPPER}} .news-block-wrapper .news-description',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'news_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-block-wrapper .news-description' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_hover_shadow',
				'selectors' => [
					'{{WRAPPER}} .news-block-wrapper .news-description' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_hover_border',
				'selector' => '{{WRAPPER}} .news-block-wrapper .news-description',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'item_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .news-block-wrapper .news-description' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */






		/* ===== Begin Thumbnail Style ===== */
		$this->start_controls_section(
			'news_item_thumb_style',
			[
				'label' => esc_html__( 'Thumb Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
		\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'news_thumb_border',
				'label' => esc_html__( 'Border', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .news-block-wrapper .news-thumb',
			]
		);
		$this->add_responsive_control(
			'news_thumb_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .news-block-wrapper .news-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .news-block-wrapper .news-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			]
		);
		$this->add_responsive_control(
			'news_thumb_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .news-block-wrapper .news-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */






		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'news_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'news_title_tabs' );
		$this->start_controls_tab(
			'news_title_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .the-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .the-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .the-title',
			]
		);
		$this->add_responsive_control(
			'news_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .the-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'news_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .the-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'news_title_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .the-title:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .the-title a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .the-title:hover',
			]
		);
		$this->add_responsive_control(
			'news_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .the-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'news_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .the-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Excerpt Style ===== */
		$this->start_controls_section(
			'news_excerpt_style',
			[
				'label' => esc_html__( 'Excerpt Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'news_excerpt_tabs' );
		$this->start_controls_tab(
			'news_excerpt_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_excerpt_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-excerpt p' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_excerpt_normal_typography',
				'selector' 	=> '{{WRAPPER}} .post-excerpt p',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'news_excerpt_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_excerpt_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-excerpt p:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_excerpt_hover_typography',
				'selector' 	=> '{{WRAPPER}} .post-excerpt p:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'news_excerpt_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-excerpt p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'news_excerpt_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-excerpt p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Excerpt Style ===== */







		/* ===== Begin Post Meta Style ===== */
		$this->start_controls_section(
			'news_post_meta_style',
			[
				'label' => esc_html__( 'Post Meta Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'news_post_meta_tabs' );
		$this->add_control(
			'news_post_author_name_normal_heading',
			[
				'label'     => esc_html__( 'Name', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->start_controls_tab(
			'news_post_meta_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		// ======  Author Name  ====== //
		$this->add_control(
			'news_post_author_name_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-author .name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_post_author_name_typography',
				'selector' 	=> '{{WRAPPER}} .post-author',
			]
		);

		// ======  Author Note  ====== //
		$this->add_control(
			'news_post_author_note_normal_heading',
			[
				'label'     => esc_html__( 'Note', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'news_post_author_note_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .post-author .note' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_post_author_note_normal_typography',
				'selector' 	=> '{{WRAPPER}} .post-author .note',
			]
		);

		// ======  Author Date  ====== //
		$this->add_control(
			'news_post_author_date_normal_heading',
			[
				'label'     => esc_html__( 'Date', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'news_post_author_date_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .post-date .entry-date a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_post_author_date_normal_typography',
				'selector' 	=> '{{WRAPPER}} .post-date .entry-date a',
			]
		);

		// ======  Author Commnets  ====== //
		$this->add_control(
			'news_post_author_commnets_normal_heading',
			[
				'label'     => esc_html__( 'Commnets', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'news_post_author_commnets_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .post-comments .entry-comments, {{WRAPPER}} .post-comments .entry-comments a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_post_author_commnets_normal_typography',
				'selector' 	=> '{{WRAPPER}} .post-comments .entry-comments, {{WRAPPER}} .post-comments .entry-comments a',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'news_post_meta_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);

		// ======  Author Name  ====== //
		$this->add_control(
			'news_post_author_name_hover_heading',
			[
				'label'     => esc_html__( 'Name', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_control(
			'news_post_author_name_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-author .name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_post_author_name_hover_typography',
				'selector' 	=> '{{WRAPPER}} .post-author .entry-date a:hover',
			]
		);

		// ======  Author Date  ====== //
		$this->add_control(
			'news_post_author_date_hover_heading',
			[
				'label'     => esc_html__( 'Date', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'news_post_author_date_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .post-date .entry-date a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_post_author_date_hover_typography',
				'selector' 	=> '{{WRAPPER}} .post-date .entry-date a:hover',
			]
		);

		// ======  Author Commnets  ====== //
		$this->add_control(
			'news_post_author_commnets_hover_heading',
			[
				'label'     => esc_html__( 'Commnets', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'news_post_author_commnets_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .post-comments .entry-comments:hover, {{WRAPPER}} .post-comments .entry-comments a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_post_author_commnets_hover_typography',
				'selector' 	=> '{{WRAPPER}} .post-comments .entry-comments:hover, {{WRAPPER}} .post-comments .entry-comments a',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Excerpt Style ===== */






		/* ===== Begin Category Style ===== */
		$this->start_controls_section(
			'news_category_style',
			[
				'label' => esc_html__( 'Category Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'news_category_tabs' );
		$this->start_controls_tab(
			'news_category_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_category_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-categories a' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'news_category_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-categories a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_category_normal_typography',
				'selector' 	=> '{{WRAPPER}} .post-categories a',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'news_category_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'news_category_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-categories a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'news_category_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-categories a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'news_category_hover_typography',
				'selector' 	=> '{{WRAPPER}} .post-categories a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'news_category_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-categories a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'news_category_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-categories a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'news_category_normal_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .post-categories a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Category Style ===== */




		/* ===== Begin Carousel Options ===== */
		webex_get_elementor_carousel_options($this);
		/* ===== End Carousel Options ===== */

}


	protected function render() {
		$settings = $this->get_settings_for_display();

		$data_options['items'] 				= $settings['item_number'];
		$data_options['items_lg'] 				= $settings['items_lg'];
		$data_options['items_md'] 				= $settings['items_md'];
		$data_options['items_sm'] 				= $settings['items_sm'];
		$data_options['items_xs'] 				= $settings['items_xs'];


		$data_options['margin']             = $settings['margin_items'];
		$data_options['loop']               = $settings['infinite'] === 'yes' ? true : false;
		$data_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$data_options['nav']               = $settings['nav_control'] === 'yes' ? true : false;
		$data_options['dots']               = $settings['dot_control'] === 'yes' ? true : false;
		$data_options['center']				= $settings['center_mode'] === 'yes' ? true : false;
		$data_options['rtl']				= is_rtl() ? true: false;


		$this->add_render_attribute( 'wrapper', 'class', 'news-block-wrapper' );
		if( 'slider' == $settings['layout'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'firecore-slider-wrapper' );
		}

		?>
		<div id="news-block-<?php echo esc_attr( $settings['news_styles'] ) ?>" <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php if( 'grid' == $settings['layout'] ) : ?>
				<?php $this->render_loop( $settings );?>
				<?php elseif( 'slider' == $settings['layout'] ) : ?>
				<div class="webex-slider">
					<div class="owl-carousel webex-carousel" data-options="<?php echo esc_attr(json_encode($data_options)); ?>">
							<?php $this->render_loop( $settings );?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function render_loop( $settings ) {
		global $wp_ele_query;
		$ele_paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
		$ele_args = [
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $settings['post_limit'],
			'orderby'             => $settings['order_by'],
			'order'               => $settings['sort_order'],
			'thumbnail_size'  		=> $settings['news_image'],
			'ignore_sticky_posts' => 1,
			'paged'               => $ele_paged
		];

		if ( 'categories' == $settings['post_from'] && $settings['cat_slugs'] ) {
			$ele_args['tax_query'] = [
				[
					'taxonomy' => 'category',
					'field'    => 'slug',
					'terms'    => $settings['cat_slugs'],
				],
			];
		}

		if ( 'specific-post' == $settings['post_from'] && $settings['post_ids'] ) {
			$ele_args['post__in'] = $settings['post_ids'];
		}

		$wp_ele_query = new WP_Query( $ele_args );
		while ( $wp_ele_query->have_posts() ): $wp_ele_query->the_post();
			if ( 'grid' == $settings['layout'] ) :
				self::render_news_item( $settings );
			elseif( 'slider' == $settings['layout'] ) : ?>

			<div class="firecore-slider-item">
				<?php self::render_news_item( $settings ); ?>

			</div>
			<?php endif;
		endwhile;
		if ( 'yes' === $settings['show_pagination'] ) {
			firecore_ele_pagination();
		}
		wp_reset_postdata();
	}

	public static function render_news_item( $settings ) {
		$idd             = get_the_ID();
		$categories_list = get_the_term_list( $idd, 'category', '', '', '' );
		$the_title = get_the_title();
		$excerpt_count = $settings['excerpt_count'];
		$choose_meta   = $settings['choose_meta'];

		if ( $settings['news_styles'] == 'style_1' ) {
			include firecore_get_template('/news/style1.php');
		}
		if ( $settings['news_styles'] == 'style_2' ) {
			include firecore_get_template('/news/style2.php');
		}
	}
}
