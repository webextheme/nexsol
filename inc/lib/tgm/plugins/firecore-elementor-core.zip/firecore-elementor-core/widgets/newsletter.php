<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class FIRECORE_Newsletter extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-newsletter';
	}

	public function get_title() {
		return esc_html__( 'Newsletter', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_responsive_control(
			'newsletter_styles',
			[
				'label' => __( 'Button Shape Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'default_btn' => __('Default Button', 'firecore-elementor-core'),
					'float_btn' => __('Float Button', 'firecore-elementor-core'),
					],
				 'default' => 'default_btn',
			]
		);
		$this->add_control(
			'shortcode',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__('Shortcode', 'firecore-elementor-core'),
				'label_block' => true,
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/



		/*===================================
		Start Input Style
		=====================================*/
		$this->start_controls_section(
			'section_newsletter_input_style',
			[
				'label' 	=> esc_html__( 'Input Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'newsletter_input_text_color',
			[
				'label' 	=> esc_html__( 'Text Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from input[type="email"]' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'newsletter_input_placeholder_color',
			[
				'label' 	=> esc_html__( 'Placeholder Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from input[type="email"]::placeholder' => 'color: {{VALUE}} !important',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'newsletter_input_typography',
				'selector' 	=> '{{WRAPPER}} .newsletter-from input[type="email"]',
			]
		);
		$this->add_responsive_control(
			'newsletter_input_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .newsletter-from input[type="email"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'newsletter_input_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .newsletter-from' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'newsletter_input_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .newsletter-from input[type="email"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'newsletter_input_tabs' );
		$this->start_controls_tab(
			'newsletter_input_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'newsletter_input_bg_color_normal',
			[
				'label' 	=> esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from input[type="email"]' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'newsletter_input_border_normal',
				'selector' => '{{WRAPPER}} .newsletter-from input[type="email"]',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'newsletter_input_focus',
			[
				'label' => esc_html__( 'Focus', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'newsletter_input_bg_color_focus',
			[
				'label' 	=> esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from input[type="email"]:focus' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'newsletter_input_border_focus',
				'selector' => '{{WRAPPER}} .newsletter-from input[type="email"]:focus',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Input Style
		=====================================*/




		/*===================================
		Begin Button Style
		=====================================*/
		$this->start_controls_section(
			'newsletter_button_style',
			[
				'label' => esc_html__( 'Button Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'newsletter_button_tabs' );
		$this->start_controls_tab(
			'newsletter_button_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'newsletter_button_icon_color_normal',
			[
				'label'     => esc_html__( 'Icon Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from button[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'newsletter_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from button[type="submit"]' => 'background-color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'newsletter_button_typography_normal',
				'selector' 	=> '{{WRAPPER}} .newsletter-from button[type="submit"]',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'newsletter_button_border_normal',
				'selector' => '{{WRAPPER}} .newsletter-from button[type="submit"]',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'newsletter_button_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'newsletter_button_icon_color_hover',
			[
				'label'     => esc_html__( 'Icon Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from button[type="submit"]:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'newsletter_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .newsletter-from button[type="submit"]:hover' => 'background-color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'newsletter_button_typography_hover',
				'selector' 	=> '{{WRAPPER}} .newsletter-from button[type="submit"]:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'newsletter_button_border_hover',
				'selector' => '{{WRAPPER}} .newsletter-from button[type="submit"]:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'newsletter_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .newsletter-from button[type="submit"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'newsletter_button_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .newsletter-from button[type="submit"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Button Style
		=====================================*/

	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="newsletter-from <?php echo esc_attr($settings['newsletter_styles']); ?>">
			<?php echo do_shortcode($settings['shortcode']); ?>
		</div>

		<?php
	}
}
