<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_Experience_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-experience-box';
	}

	public function get_title() {
		return esc_html__( 'Experience Box', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'experience_text',
			[
				'label'       => __( 'Place Text', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter title here', 'firecore-elementor-core' ),
				'default'	=> esc_html__('Default Text Here', 'firecore-elementor-core')
			]
		);
		$this->add_control(
			'experience_year',
			[
				'label'       => __( 'Place Experience Year', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter Experience', 'firecore-elementor-core' ),
				'default'	=> esc_html__('14', 'firecore-elementor-core')
			]
		);
		$this->add_control(
			'experience_year_tag',
			[
				'label' 	=> esc_html__( 'Experience Year Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 	=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 	=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 	=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'	=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 	=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 	=> esc_html__('h6', 'firecore-elementor-core'),
				]
			]
		);
		$this->add_responsive_control(
			'experience_box_alignments',
			[
				'label' => __('Box Content alignments', 'firecore-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'firecore-elementor-core' ),
						'icon' 	=> 'eicon-text-align-justify',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .experience' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/



		/*===================================
		Start Experience Box Style
		=====================================*/
		$this->start_controls_section(
			'experience_box_style',
			[
				'label' 	=> esc_html__( 'Experience Box Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'experience_year_image_box',
				'label' => esc_html__( 'Background', 'firecore-elementor-core' ),
				'types' => [ 'classic' ],
				'selector' => '{{WRAPPER}} .experience',
			]
		);
		$this->add_control(
			'experience_box_bg_color',
			[
				'label' 	=> esc_html__( 'Experience Box BG Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .experience:after' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'experience_box_bg_color_opacity',
			[
				'label' 		=> esc_html__( 'Experience Box BG Color Opacity', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 0.9,
				],
				'selectors' => [
					'{{WRAPPER}} .experience:after' => 'opacity: {{SIZE}};',
				],
			]
		);
		$this->add_responsive_control(
			'experience_box_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .experience' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'experience_box_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .experience' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'experience_box_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .experience, {{WRAPPER}} .experience:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'experience_box_border',
				'selector' => '{{WRAPPER}} .experience',
			]
		);

		$this->end_controls_section();
		/*===================================
		End Experience Box Style
		=====================================*/



		/*===================================
		Start Experience Text Style
		=====================================*/
		$this->start_controls_section(
			'text_style',
			[
				'label' 	=> esc_html__( 'Text Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'text_typography',
				'selector' 	=> '{{WRAPPER}} .experience .experience-text',
			]
		);
		$this->add_control(
			'text_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .experience .experience-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'text_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .experience .experience-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'text_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .experience .experience-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Experience Text Style
		=====================================*/



		/*===================================
		Start Experience Year Style
		=====================================*/
		$this->start_controls_section(
			'year_style',
			[
				'label' 	=> esc_html__( 'Year Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'year_typography',
				'selector' 	=> '{{WRAPPER}} .experience .experience-year',
			]
		);
		$this->add_control(
			'year_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .experience .experience-year' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'year_stroke_color',
			[
				'label'     => esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .experience .experience-year' => '-webkit-text-stroke-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'year_fill_color',
			[
				'label'     => esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .experience .experience-year' => '-webkit-text-fill-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'year_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .experience .experience-year' => '-webkit-text-stroke-width: {{VALUE}}px;'
				],
			]
		);
		$this->add_responsive_control(
			'year_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .experience .experience-year' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'year_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .experience .experience-year' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Experience Year Style
		=====================================*/
	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$experience_text 			= $settings['experience_text'];
		$experience_year 			= $settings['experience_year'];
		?>

		<div class="experience"
		<?php if (!empty( $url_bg_image )): ?>
			style="background-image: url(<?php echo esc_attr( $url_bg_image ) ; ?>)"
		<?php endif;?>
		>
		<?php if ( !empty($experience_text) ): ?>
			<p class="experience-text"><?php echo esc_html( $experience_text ); ?></p>
		<?php endif; ?>
		<?php if ( !empty($experience_year) ): ?>
			<?php echo '<'. esc_html( $settings['experience_year_tag'] ) .' class="experience-year">'; ?><?php echo esc_html( $experience_year ); ?><?php echo '</'. esc_html( $settings['experience_year_tag'] ) .'>' ?>
		<?php endif; ?>
	</div>

	<?php
}

}
