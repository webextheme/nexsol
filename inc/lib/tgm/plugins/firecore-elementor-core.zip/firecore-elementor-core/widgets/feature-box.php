<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;

class FIRECORE_Feature_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-feature-box';
	}

	public function get_title() {
		return esc_html__( 'Feature Box', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return array('allslider-js');
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Feature Box Content ===== */
		$this->start_controls_section(
			'section_content_item',
			[
				'label' => esc_html__( 'Feature Box', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_styles',
			[
				'label' => __( 'Feature Box Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'firecore-elementor-core' ),
					'style_4' => esc_html__( 'Style 04', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Layout', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid'   => esc_html__( 'Grid', 'firecore-elementor-core' ),
					'slider' => esc_html__( 'Slider', 'firecore-elementor-core' ),
				],
			]
		);
		$this->add_responsive_control(
			'column',
			[
				'label'                => esc_html__( 'Grid Column', 'firecore-elementor-core' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					''  => esc_html__( 'Default', 'firecore-elementor-core' ),
					'1' => esc_html__( '1 column', 'firecore-elementor-core' ),
					'2' => esc_html__( '2 column', 'firecore-elementor-core' ),
					'3' => esc_html__( '3 column', 'firecore-elementor-core' ),
					'4' => esc_html__( '4 column', 'firecore-elementor-core' ),
					'5' => esc_html__( '5 column', 'firecore-elementor-core' ),
					'6' => esc_html__( '6 column', 'firecore-elementor-core' ),
				],
				'default'              => 4,
				'tablet_extra_default' => '',
				'tablet_default'       => '',
				'mobile_default'       => '',
				'condition'            => [
					'layout' => 'grid',
				],
				'selectors'            => [
					'{{WRAPPER}} .feature-box-block-wrapper' => 'grid-template-columns: repeat( {{VALUE}}, 1fr );',
				],
			]
		);
		$this->add_control(
			'item_number',
			[
				'label'       => esc_html__( 'Item Number', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'description' => esc_html__( 'Number Item', 'firecore-elementor-core' ),
				'default'     => 4,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'condition'            => [
					'layout' => 'slider',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'feature_box_image',
				'default'   => 'firecore-image-size5',
				'separator' => 'before',
				'exclude'   => [
					'custom',
				],
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'photo',
			[
				'label'   => __( 'Image', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'firecore-flaticon',
				],
			]
		);
		$repeater->add_control(
			'counting',
			[
				'label'       => esc_html__( 'Counting Number', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( '01', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Item Name', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'subtitle',
			[
				'label'       => esc_html__( 'Subtitle', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'subtitle', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'subtitle_tag',
			[
				'label' 	=> esc_html__( 'Subtitle Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h6',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'title_link',
			[
				'label' => esc_html__( "Title Link URL", 'firecore-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
				]
			]
		);
		$repeater->add_control(
			'description',
			[
				'label' => esc_html__( "Paragraph", 'firecore-elementor-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( "Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.", 'firecore-elementor-core' ),
			]
		);
		$repeater->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Text Button', 'firecore-elementor-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Read more ', 'firecore-elementor-core' ),
			],
		);
		$repeater->add_control(
			'button_link',
			[
				'label' => esc_html__( "Button Link URL", 'firecore-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
				]
			]
		);
		$this->add_control(
			'feature_box_items',
			[
				'label'       => esc_html__( 'Feature Box Items', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'firecore_icons' => [
							'value'   => 'webexbase-icon-diamond',
							'library' => 'firecore_base_icon',
						],
						'title'      => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
						'subtitle' => esc_html__( 'Subtitle Place Here', 'firecore-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.', 'firecore-elementor-core' ),
						'counting' => esc_html__( '01', 'firecore-elementor-core' ),
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'firecore_icons' => [
							'value'   => 'webexbase-icon-diamond',
							'library' => 'firecore_base_icon',
						],
						'title'      => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
						'subtitle' => esc_html__( 'Subtitle Place Here', 'firecore-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.', 'firecore-elementor-core' ),
						'counting' => esc_html__( '01', 'firecore-elementor-core' ),
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'firecore_icons' => [
							'value'   => 'webexbase-icon-diamond',
							'library' => 'firecore_base_icon',
						],
						'title'      => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
						'subtitle' => esc_html__( 'Subtitle Place Here', 'firecore-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.', 'firecore-elementor-core' ),
						'counting' => esc_html__( '01', 'firecore-elementor-core' ),
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		$this->end_controls_section();
		/* ===== End Feature Box Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'feature_box_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'text_align',
			[
				'label'     => esc_html__( 'Alignment', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .feature-box-block' => 'text-align: {{Value}};',
				],
			]
		);
		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .feature-box-block-wrapper' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .feature-box-block-wrapper' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'feature_box_item_border',
				'selector' => '{{WRAPPER}} .feature-box-block .feature-box-inner',
			]
		);
		$this->add_responsive_control(
			'feature_box_item_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-block .feature-box-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-block .feature-box-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-block .feature-box-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'feature_box_item_tab' );
		$this->start_controls_tab(
			'feature_box_item_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block .feature-box-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .feature-box-block .feature-box-inner',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'feature_box_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block:hover .feature-box-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_hover_shadow',
				'selectors' => [
					'{{WRAPPER}} .feature-box-block:hover .feature-box-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Content Style ===== */






		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'feature_box_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'feature_box_title_tabs' );
		$this->start_controls_tab(
			'feature_box_title_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-box-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-title',
			]
		);
		$this->add_responsive_control(
			'feature_box_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'feature_box_title_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-title:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .feature-box-title a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-title:hover',
			]
		);
		$this->add_responsive_control(
			'feature_box_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'feature_box_title_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_title_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block:hover .feature-box-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-box-block:hover .feature-box-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */






		/* ===== Begin Description Style ===== */
		$this->start_controls_section(
			'feature_box_description_style',
			[
				'label' => esc_html__( 'Description Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'feature_box_description_tabs' );
		$this->start_controls_tab(
			'feature_box_description_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_description_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-description' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-box-description a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_description_normal_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-description',
			]
		);
		$this->add_responsive_control(
			'feature_box_description_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_description_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'feature_box_description_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_description_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-description:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .feature-box-description a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_description_hover_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-description:hover',
			]
		);
		$this->add_responsive_control(
			'feature_box_description_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-description:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_description_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-description:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'feature_box_description_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_description_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block:hover .feature-box-description' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-box-block:hover .feature-box-description a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Subtitle Style ===== */
		$this->start_controls_section(
			'feature_box_subtitle_style',
			[
				'label' => esc_html__( 'Subtitle Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'feature_box_subtitle_tabs' );
		$this->start_controls_tab(
			'feature_box_subtitle_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_subtitle_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-subtitle' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_subtitle_normal_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-subtitle',
			]
		);
		$this->add_responsive_control(
			'feature_box_subtitle_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_subtitle_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'feature_box_subtitle_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_subtitle_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-subtitle:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_subtitle_hover_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-subtitle:hover',
			]
		);
		$this->add_responsive_control(
			'feature_box_subtitle_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-subtitle:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_subtitle_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-subtitle:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Subtitle Style ===== */






		/* ===== Begin Button Style ===== */
		$this->start_controls_section(
			'feature_box_button_style',
			[
				'label' => esc_html__( 'Button Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'  => [
					'feature_box_styles' => 'style_1',
				],
			]
		);
		$this->start_controls_tabs( 'feature_box_button_tabs' );
		$this->start_controls_tab(
			'feature_box_button_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-button a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-box-button a:after' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_button_normal_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-button a',
			]
		);
		$this->add_responsive_control(
			'feature_box_button_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_button_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-button a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'feature_box_button_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'feature_box_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-button a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'feature_box_button_hover_typography',
				'selector' 	=> '{{WRAPPER}} .feature-box-button a:hover',
			]
		);
		$this->add_responsive_control(
			'feature_box_button_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-button a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_box_button_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-button a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Subtitle Style ===== */





		/* ===== Begin Icons Style ===== */
		$this->start_controls_section(
			'icon_styling',
			[
				'label' => esc_html__( 'Icons Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .feature-box-block .feature-box-icon',
			]
		);
		$this->add_responsive_control(
			'icon_margin',
			[
				'label'      => esc_html__( 'Icon Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .feature-box-block .feature-box-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_padding',
			[
				'label'      => esc_html__( 'Icon Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .feature-box-block .feature-box-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_border',
				'selector' => '{{WRAPPER}} .feature-box-block .feature-box-icon',
			]
		);
		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-box-block .feature-box-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'icon_tab' );

		$this->start_controls_tab(
			'icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block .feature-box-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block .feature-box-icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block:hover .feature-box-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block:hover .feature-box-icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Social Icons Style ===== */


		/* ===== Begin Button Style ===== */
		$this->start_controls_section(
			'button_styling',
			[
				'label' => esc_html__( 'Button Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .feature-box-block .feature-box-link a, {{WRAPPER}} .feature-box-block .feature-box-button a, {{WRAPPER}} .feature-box-block .feature-box-button span, {{WRAPPER}} .feature-box-block .feature-box-button span i',
			]
		);
		$this->add_responsive_control(
			'button_margin',
			[
				'label'      => esc_html__( 'Icon Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .feature-box-block .feature-box-link a, {{WRAPPER}} .feature-box-block .feature-box-button a, {{WRAPPER}} .feature-box-block .feature-box-button span, {{WRAPPER}} .feature-box-block .feature-box-button span i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => esc_html__( 'Icon Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .feature-box-block .feature-box-link a, {{WRAPPER}} .feature-box-block .feature-box-button a, {{WRAPPER}} .feature-box-block .feature-box-button span, {{WRAPPER}} .feature-box-block .feature-box-button span i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'button_tab' );

		$this->start_controls_tab(
			'button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block .feature-box-link a, {{WRAPPER}} .feature-box-block .feature-box-button a, {{WRAPPER}} .feature-box-block .feature-box-button span, {{WRAPPER}} .feature-box-block .feature-box-button span i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-box-block .feature-box-link a:after, {{WRAPPER}} .feature-box-block .feature-box-button a:after' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-box-block .feature-box-link a:hover, {{WRAPPER}} .feature-box-block .feature-box-button a:hover, {{WRAPPER}} .feature-box-block .feature-box-button:hover span, {{WRAPPER}} .feature-box-block .feature-box-button:hover span i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-box-block .feature-box-link a:hover:after, {{WRAPPER}} .feature-box-block .feature-box-button a:hover:after' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Social Button Style ===== */



		/* ===== Begin Carousel Options ===== */
		webex_get_elementor_carousel_options($this);
		/* ===== End Carousel Options ===== */


}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$data_options['items'] 				= $settings['item_number'];
		$data_options['items_lg'] 				= $settings['items_lg'];
		$data_options['items_md'] 				= $settings['items_md'];
		$data_options['items_sm'] 				= $settings['items_sm'];
		$data_options['items_xs'] 				= $settings['items_xs'];


		$data_options['margin']             = $settings['margin_items'];
		$data_options['loop']               = $settings['infinite'] === 'yes' ? true : false;
		$data_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$data_options['nav']               = $settings['nav_control'] === 'yes' ? true : false;
		$data_options['dots']               = $settings['dot_control'] === 'yes' ? true : false;
		$data_options['center']				= $settings['center_mode'] === 'yes' ? true : false;
		$data_options['rtl']				= is_rtl() ? true: false;


		if ( empty( $settings['feature_box_items'] ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'feature-box-block-wrapper' );
		if( 'slider' == $settings['layout'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'firecore-slider-wrapper' );
		}

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php if( 'grid' == $settings['layout'] ) : ?>
			<?php
				foreach ( $settings['feature_box_items'] as $index => $item ) {
					$this->render_single_item( $index, $item );
				}
			?>
			<?php elseif( 'slider' == $settings['layout'] ) : ?>
				<div class="webex-slider">
					<div class="owl-carousel webex-carousel" data-options="<?php echo esc_attr(json_encode($data_options)); ?>">
						<?php foreach ( $settings['feature_box_items'] as $index => $item ) : ?>
						<div class="firecore-slider-item">
							<?php $this->render_single_item( $index, $item ); ?>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function render_single_item( $index, $item ) {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');

		$firecore_icons = $item['firecore_icons']['value'];
		$title = $item['title'];
		$title_tag = $item['title_tag'];
		$subtitle = $item['subtitle'];
		$subtitle_tag = $item['subtitle_tag'];
		$description = $item['description'];
		$counting = $item['counting'];
		$button_text = $item['button_text'];

		$custom_link = $item['title_link'];
		$target = ( $custom_link && $custom_link['is_external'] ) ? ' target="_blank"' : '';
		$url = ( $custom_link && $custom_link['url'] ) ? $custom_link['url'] : '';

		$button_link = $item['button_link'];
		$btn_target = ( $button_link && $button_link['is_external'] ) ? ' target="_blank"' : '';
		$btn_url = ( $button_link && $button_link['url'] ) ? $button_link['url'] : '';

		if ( empty( $item['photo']['id'] && ! empty( $item['photo']['url'] ) ) ) {
			$image_url = $item['photo']['url'];
		} else {
			$image_url = Group_Control_Image_Size::get_attachment_image_src( $item['photo']['id'], 'feature_box_image', $settings );
		}

		switch ( $settings['feature_box_styles'] ) {
			case 'style_1':
				include firecore_get_template( '/feature-box/style1.php' );
				break;
			case 'style_2':
				include firecore_get_template( '/feature-box/style2.php' );
				break;
			case 'style_3':
				include firecore_get_template( '/feature-box/style3.php' );
				break;
			case 'style_4':
				include firecore_get_template( '/feature-box/style4.php' );
				break;
		}

	}
}
