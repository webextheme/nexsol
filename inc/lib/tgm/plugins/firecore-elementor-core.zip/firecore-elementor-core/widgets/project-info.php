<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_Project_Info extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-project-info';
	}

	public function get_title() {
		return esc_html__( 'Project Info', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Acordion Content ===== */
		$this->start_controls_section(
			'section_content_acordions',
			[
				'label' => esc_html__( 'Project Info', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'project_info_widget_title',
			[
				'label' 	=> __( 'Widget Title', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __( 'Project Info', 'firecore-elementor-core' )
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Title', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Description', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'project_info_items',
			[
				'label'       => esc_html__( 'Items', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'      => esc_html__( 'Project Date:', 'firecore-elementor-core' ),
						'description' => esc_html__( 'May 17, 2025', 'firecore-elementor-core' ),
					],
					[
						'title'      => esc_html__( 'Client:', 'firecore-elementor-core' ),
						'description' => esc_html__( 'WebexTheme', 'firecore-elementor-core' ),
					],
					[
						'title'      => esc_html__( 'Categories:', 'firecore-elementor-core' ),
						'description' => esc_html__( 'Categories', 'firecore-elementor-core' ),
					],
					[
						'title'      => esc_html__( 'Budgets:', 'firecore-elementor-core' ),
						'description' => esc_html__( '$30,000', 'firecore-elementor-core' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		$this->end_controls_section();
		/* ===== End Team Items Content ===== */



		/* ===== Begin Widget Title Style ===== */
		$this->start_controls_section(
			'project_info_widget_title_style',
			[
				'label' => esc_html__( 'Widget Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'project_info_widge_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-info-block .project-info-widget-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_info_widge_title_typography',
				'selector' 	=> '{{WRAPPER}} .project-info-block .project-info-widget-title',
			]
		);
		$this->add_responsive_control(
			'project_info_widge_title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-info-block .project-info-widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_info_widge_title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-info-block .project-info-widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'project_info_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'project_info_item_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-info-block' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_info_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .project-info-block' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_info_item_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .project-info-block' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .project-info-block',
			]
		);
		$this->add_responsive_control(
			'item_box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .project-info-block' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */




		/* ===== Begin Content List Style ===== */
		$this->start_controls_section(
			'project_info_item_content_list_style',
			[
				'label' => esc_html__( 'Content List Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'project_info_item_content_list_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-info-block .project-info-item' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_info_item_content_list_padding',
			[
				'label'      => esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .project-info-block .project-info-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_info_item_content_list_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .project-info-block .project-info-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_content_list_border',
				'selector' => '{{WRAPPER}} .project-info-block .project-info-item',
			]
		);
		$this->add_responsive_control(
			'item_content_list_box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .project-info-block .project-info-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */





		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'project_info_item_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'project_info_item_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-info-block .title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_info_item_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .project-info-block .title',
			]
		);
		$this->add_responsive_control(
			'project_info_item_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-info-block .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_info_item_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-info-block .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'project_info_item_title_width',
			[
				'label' => esc_html__( 'Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .project-info-block .title' => 'min-width: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Description Style ===== */
		$this->start_controls_section(
			'project_info_item_description_style',
			[
				'label' => esc_html__( 'Description Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'project_info_item_description_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-info-block  .description' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'project_info_item_description_normal_typography',
				'selector' 	=> '{{WRAPPER}} .project-info-block .description',
			]
		);
		$this->add_responsive_control(
			'project_info_item_description_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .project-info-block .description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'project_info_item_description_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Description Style ===== */




}

protected function render() {
	$settings = $this->get_settings_for_display();
	?>

	<div class="project-info-block">
			<?php if(!empty($settings['project_info_widget_title'])): ?>
				<h4 class="project-info-widget-title"><?php echo esc_html($settings['project_info_widget_title']); ?></h4>
			<?php endif; ?>
			<ul class="project-info-list">
				<?php foreach ($settings['project_info_items'] as $keys => $item) : ?>

				<li class="project-info-item">
					<!-- Title -->
					<?php if( !empty( $item['title'] ) ) : ?>
					<span class="title"> <?php echo esc_html( $item['title'] ) ?></span>
					<?php endif; ?>

					<!-- Description -->
					<?php if( !empty( $item['description'] ) ) : ?>
					<span class="description"> <?php echo esc_html( $item['description'] ) ?></span>
					<?php endif; ?>
				</li>

				<?php endforeach; ?>
			</ul>
	</div>

	<?php
	}
}
