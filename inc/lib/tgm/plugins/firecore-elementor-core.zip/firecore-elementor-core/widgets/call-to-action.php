<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

class FIRECORE_Call_To_Action extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-call-to-action';
	}

	public function get_title() {
		return esc_html__( 'Call To Action', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'call_to_action_styles',
			[
				'label' => __( 'Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'firecore-flaticon',
				],
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label' => __('Sub Title', 'firecore-elementor-core'),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __('Place Sub Title', 'firecore-elementor-core'),
				'default'	=> esc_html__('We are ready to help you', 'firecore-elementor-core')
			]
		);
		$this->add_control(
			'subtitle_tag',
			[
				'label' 	=> esc_html__( 'Sub Title Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h6',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Place Title', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter title here', 'firecore-elementor-core' ),
				'default'	=> esc_html__('Need Any Interior Design Help?', 'firecore-elementor-core')
			]
		);
		$this->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h3',
				'options' 	=> [
					'h1' 	=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 	=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 	=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'	=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 	=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 	=> esc_html__('h6', 'firecore-elementor-core'),
				]
			]
		);
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Text Button', 'firecore-elementor-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Read more ', 'firecore-elementor-core' ),
			],
		);
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__( "Button Link URL", 'firecore-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
				]
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/



		/*===================================
		Start Wrapper Style
		=====================================*/
		$this->start_controls_section(
			'section_cta_wrapper_style',
			[
				'label' 	=> esc_html__( 'Wrapper Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'cta_wrapper_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-inner' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'cta_wrapper_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cta_wrapper_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'cta_wrapper_border',
				'selector' => '{{WRAPPER}} .call-to-action-inner',
			]
		);
		$this->add_responsive_control(
			'cta_wrapper_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .call-to-action-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Sub Title Style
		=====================================*/



		/*===================================
		Start Sub Title Style
		=====================================*/
		$this->start_controls_section(
			'section_sub_title_style',
			[
				'label' 	=> esc_html__( 'Sub Title', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'sub_title_typography',
				'selector' 	=> '{{WRAPPER}} .call-to-action-sub-title',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-sub-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'sub_title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sub_title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Sub Title Style
		=====================================*/

		/*===================================
		Start Title Style
		=====================================*/
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'firecore-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'selector' 	=> '{{WRAPPER}} .call-to-action-title',
			]
		);
		$this->add_control(
			'title_color_normal',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-title a, {{WRAPPER}} .call-to-action-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Title Style
		=====================================*/


		/*===================================
		Begin Button Style
		=====================================*/
		$this->start_controls_section(
			'cta_button_style',
			[
				'label' => esc_html__( 'Button Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'cta_button_tabs' );
		$this->start_controls_tab(
			'cta_button_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'cta_button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-btn-box a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'cta_button_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-btn-box a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .call-to-action-btn-box a:after' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .call-to-action-btn-box a:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'cta_button_normal_typography',
				'selector' 	=> '{{WRAPPER}} .call-to-action-btn-box a',
			]
		);
		$this->add_responsive_control(
			'cta_button_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-btn-box a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'cta_button_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-btn-box a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'cta_button_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'cta_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-btn-box a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'cta_button_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-btn-box a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .call-to-action-btn-box a:hover:after' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .call-to-action-btn-box a:hover:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'cta_button_hover_typography',
				'selector' 	=> '{{WRAPPER}} .call-to-action-btn-box a:hover',
			]
		);
		$this->add_responsive_control(
			'cta_button_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-btn-box a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'cta_button_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-btn-box a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Button Style
		=====================================*/



		/* ===== Begin Icons Style ===== */
		$this->start_controls_section(
			'icon_styling',
			[
				'label' => esc_html__( 'Icons Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .call-to-action-icon span:before',
			]
		);
		$this->add_responsive_control(
			'icon_margin',
			[
				'label'      => esc_html__( 'Icon Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .call-to-action-icon span:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_padding',
			[
				'label'      => esc_html__( 'Icon Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .call-to-action-icon span:before' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_border',
				'selector' => '{{WRAPPER}} .call-to-action-icon span:before',
			]
		);
		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .call-to-action-icon span:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'icon_tab' );

		$this->start_controls_tab(
			'icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-icon span:before' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .call-to-action-icon span:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .services-block:hover .services-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .services-block:hover .services-icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Social Icons Style ===== */


	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');

		$firecore_icons = $settings['firecore_icons']['value'];
		$title = $settings['title'];
		$title_tag = $settings['title_tag'];
		$subtitle = $settings['subtitle'];
		$subtitle_tag = $settings['subtitle_tag'];
		$button_text = $settings['button_text'];

		$button_link = $settings['button_link'];
		$btn_target = ( $button_link && $button_link['is_external'] ) ? ' target="_blank"' : '';
		$btn_url = ( $button_link && $button_link['url'] ) ? $button_link['url'] : '';
		?>

		<div class="call-to-action-inner">
			<div class="call-to-action-left">
				<div class="call-to-action-icon">
				<!-- Icon -->
				<?php if ( !empty($firecore_icons) ): ?>
					<span class="webexflaticon <?php echo esc_attr( $firecore_icons ); ?>"></span>
				<?php endif; ?>
				</div>
				<div class="call-to-action-content">
					<!-- Subtitle -->
					<?php if( !empty( $subtitle ) ) : ?>
          <?php echo '<'. esc_attr( $subtitle_tag ) .' class="call-to-action-sub-title">'; ?>
            <?php echo esc_html( $subtitle ) ?>
          <?php echo '</'. esc_attr( $subtitle_tag ) .'>' ?>
        	<?php endif; ?>

					<!-- Title -->
					<?php if( !empty( $title ) ) : ?>
					<?php echo '<'. esc_attr( $title_tag ) .' class="call-to-action-title">'; ?>
						<?php if( !empty( $url ) ): ?>
						<a
							<?php echo $target;?>
							href="<?php echo esc_url( $url );?>">
							<?php echo esc_html( $title ) ?>
						</a>
						<?php else: ?>
							<?php echo esc_html( $title ) ?>
						<?php endif ?>
					<?php echo '</'. esc_attr( $title_tag ) .'>' ?>
					<?php endif; ?>
				</div>
			</div>
			<div class="call-to-action-btn-box mrt-md-30">
				<a class="firecore-btn-style1 firecore_btn btn-md" <?php echo $btn_target;?> href="<?php echo esc_url( $btn_url );?>"><?php echo esc_html($button_text); ?></a>
			</div>
		</div>

		<?php
	}
}
