<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_About_Image_V1 extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-about-image-v1';
	}

	public function get_title() {
		return esc_html__( 'About Image Box', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {


		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label'		=> esc_html__( 'Content Settings','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'styles',
			[
				'label' 	=> esc_html__( 'About Styles', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::SELECT,
				'default' 	=> 'style_1',
				'options' 	=> [
					'style_1'  	=> esc_html__( 'Style One', 'firecore-elementor-core' ),
					'style_2' 	=> esc_html__( 'Style Two', 'firecore-elementor-core' ),
					'style_3' 	=> esc_html__( 'Style Three', 'firecore-elementor-core' ),
				],
			]
		);
		$this->add_control(
			'experience_box_show_hide',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Show Experience Box?', 'firecore-elementor-core' ),
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'  => esc_html__( 'Show', 'firecore-elementor-core' ),
				'separator' => 'before',
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/




		/*===================================
		Start About Style 01 Image 01 Settings
		=====================================*/
		$this->start_controls_section(
			'about_s1_image_01_section',
			[
				'label'		=> esc_html__( 'Image 01 Style','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_1']],
			]
		);
		$this->add_control(
			'about_s1_image1',
			[
				'label' 	=> esc_html__( 'About Image 01', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_s1_image1',
				'default'   => 'firecore-image(545x645)',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_image1_width',
			[
				'label' => esc_html__( 'Image Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 170,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1 .about-image1 img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'after'
			]
		);
		// Side Line Styles
		$this->add_control(
			'about_s1_side_line_bg_color',
			[
				'label' 	=> esc_html__( 'Side Line BG Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1.about-side-line:after' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_side_line_height',
			[
				'label' => esc_html__( 'Side Line Height', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1.about-side-line:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_side_line_width',
			[
				'label' => esc_html__( 'Side Line Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1.about-side-line:after' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_side_line_left',
			[
				'label' => esc_html__( 'Side Line Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1.about-side-line:after' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_side_line_top',
			[
				'label' => esc_html__( 'Side Line Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1.about-side-line:after' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_image1_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_image1_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'about_s1_image1_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style1 .about-image1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End About Style 01 Image 01 Settings
		=====================================*/


		/*===================================
		Start About Style 01 Image 02 Settings
		=====================================*/
		$this->start_controls_section(
			'about_s1_image_02_section',
			[
				'label'		=> esc_html__( 'Image 02 Style','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_1']],
			]
		);
		$this->add_control(
			'about_s1_image2',
			[
				'label' 	=> esc_html__( 'About Image 02', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_s1_image2',
				'default'   => 'firecore-image(430x300)',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_image2_width',
			[
				'label' => esc_html__( 'Image Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 170,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1 .about-image2 img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'after'
			]
		);
		$this->add_responsive_control(
			'about_s1_images2_left',
			[
				'label' => esc_html__( 'Image Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1 .about-image2' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s1_images2_bottom',
			[
				'label' => esc_html__( 'Image Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -300,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style1 .about-image2' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'about_s1_images2_border',
				'selector' => '{{WRAPPER}} .about-image-box-style1 .about-image2 img',
			]
		);

		$this->add_responsive_control(
			'about_s1_images2_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style1 .about-image2 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End About Style 01 Image 02 Settings
		=====================================*/



		/*===================================
		Start About Style 02 Image 01 Settings
		=====================================*/
		$this->start_controls_section(
			'about_s2_image_01_section',
			[
				'label'		=> esc_html__( 'Image 01 Style','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_2']],
			]
		);
		$this->add_control(
			'about_s2_image1',
			[
				'label' 	=> esc_html__( 'About Image 01', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_s2_image1',
				'default'   => 'firecore-image(315x375)',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_s2_image1_width',
			[
				'label' => esc_html__( 'Image Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 170,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style2 .about-image1' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'after'
			]
		);
		$this->add_responsive_control(
			'about_s2_images1_left',
			[
				'label' => esc_html__( 'Image Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style2 .about-image1' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s2_images1_bottom',
			[
				'label' => esc_html__( 'Image Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -300,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style2 .about-image1' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s2_images1_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style2 .about-image1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End About Style 02 Image 01 Settings
		=====================================*/



		/*===================================
		Start About Style 02 Image 02 Settings
		=====================================*/
		$this->start_controls_section(
			'about_s2_image_02_section',
			[
				'label'		=> esc_html__( 'Image 02 Style','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_2']],
			]
		);
		$this->add_control(
			'about_s2_image2',
			[
				'label' 	=> esc_html__( 'About Image 02', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_s2_image2',
				'default'   => 'firecore-image(545x645)',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_s2_image2_width',
			[
				'label' => esc_html__( 'Image Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 170,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style2 .about-image2' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'after'
			]
		);
		$this->add_responsive_control(
			'about_s2_images2_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style2 .about-image2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End About Style 02 Image 02 Settings
		=====================================*/



		/*===================================
		Start About Style 02 Badge 01 Settings
		=====================================*/
		$this->start_controls_section(
			'about_s2_badge_01_section',
			[
				'label'		=> esc_html__( 'Badge 01 Style','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_2']],
			]
		);
		$this->add_control(
			'about_s2_badge1',
			[
				'label' 	=> esc_html__( 'Badge Image 01', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_s2_badge1',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_s2_badge1_width',
			[
				'label' => esc_html__( 'Badge Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 90,
						'max' => 300,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style2 .about-badge1' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'after'
			]
		);
		$this->add_responsive_control(
			'about_s2_badge1_left',
			[
				'label' => esc_html__( 'Badge Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style2 .about-badge1' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s2_badge1_bottom',
			[
				'label' => esc_html__( 'Badge Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -300,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style2 .about-badge1' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s2_badge1_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style2 .about-badge1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .about-image-box-style2 .about-badge1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End About Style 02 Badge 01 Settings
		=====================================*/





		/*===================================
		Start About Style 03 Image 01 Settings
		=====================================*/
		$this->start_controls_section(
			'about_s3_image_01_section',
			[
				'label'		=> esc_html__( 'Image 01 Style','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_3']],
			]
		);
		$this->add_control(
			'about_s3_image1',
			[
				'label' 	=> esc_html__( 'About Image 01', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_s3_image1',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_s3_image1_width',
			[
				'label' => esc_html__( 'Image Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 170,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .about-image1' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'after'
			]
		);
		$this->add_responsive_control(
			'about_s3_images1_left',
			[
				'label' => esc_html__( 'Image Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .about-image1' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s3_images1_bottom',
			[
				'label' => esc_html__( 'Image Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -300,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .about-image1' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s3_images1_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style3 .about-image1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End About Style 03 Image 01 Settings
		=====================================*/



		/*===================================
		Start About Style 03 Image 02 Settings
		=====================================*/
		$this->start_controls_section(
			'about_s3_image_02_section',
			[
				'label'		=> esc_html__( 'Image 02 Style','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_3']],
			]
		);
		$this->add_control(
			'about_s3_image2',
			[
				'label' 	=> esc_html__( 'About Image 02', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_s3_image2',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_s3_image2_width',
			[
				'label' => esc_html__( 'Image Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 170,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .about-image2' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'after'
			]
		);
		$this->add_responsive_control(
			'about_s3_images2_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style3 .about-image2 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End About Style 03 Image 02 Settings
		=====================================*/



		/*===================================
		Start Style 03 Content Settings
		=====================================*/
		$this->start_controls_section(
			'about_s3_content_section',
			[
				'label'		=> esc_html__( 'Experience Content','firecore-elementor-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['styles' => ['style_3']],
			]
		);
		$this->add_control(
			'experience_years',
			[
				'label'   => esc_html__( 'Years', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 25,
			]
		);
		$this->add_control(
			'experience_text',
			[
				'label'       => __( 'Place Text', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Years Of Experiences', 'firecore-elementor-core' ),
				'default'     => esc_html__( 'Years Of Experiences', 'firecore-elementor-core' ),
			]
		);

		$this->add_responsive_control(
			'about_s3_content_left',
			[
				'label' => esc_html__( 'Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .call-us-now' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_s3_content_bottom',
			[
				'label' => esc_html__( 'Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .call-us-now' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Style 03 Content Settings
		=====================================*/





		/*===================================
		Start Years Style
		=====================================*/
		$this->start_controls_section(
			'years_style',
			[
				'label' 	=> esc_html__( 'Year Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'year_typography',
				'selector' 	=> '{{WRAPPER}} .about-image-box-style3 .years',
			]
		);
		$this->add_control(
			'year_color',
			[
				'label' 	=> esc_html__( 'Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .years' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'year_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style3 .years' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'year_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style3 .years' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Years Style
		=====================================*/






		/*===================================
		Start Text Style
		=====================================*/
		$this->start_controls_section(
			'text_style',
			[
				'label' 	=> esc_html__( 'Experience Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'text_typography',
				'selector' 	=> '{{WRAPPER}} .about-image-box-style3 .experience-text',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' 		=> 'experience_background',
				'selector' 	=> '{{WRAPPER}} .about-image-box-style3 .call-us-now',
			]
		);
		$this->add_control(
			'text_color',
			[
				'label' 	=> esc_html__( 'Text Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about-image-box-style3 .experience-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'text_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style3 .experience-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'text_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style3 .experience-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'experience_box_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-image-box-style3 .call-us-now' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Year Style
		=====================================*/

	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$experience_text 			= $settings['experience_text'];
		$experience_years 			= $settings['experience_years'];

		if ( $settings['styles'] == 'style_1' ) {
			// About Style1 Images
			if ( empty( $settings['about_s1_image1']['id'] && ! empty( $settings['about_s1_image1']['url'] ) ) ) {
				$about_s1_image1_url = $settings['about_s1_image1']['url'];
			} else {
				$about_s1_image1_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_s1_image1']['id'], 'about_s1_image1', $settings );
			}
			if ( empty( $settings['about_s1_image2']['id'] && ! empty( $settings['about_s1_image2']['url'] ) ) ) {
				$about_s1_image2_url = $settings['about_s1_image2']['url'];
			} else {
				$about_s1_image2_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_s1_image2']['id'], 'about_s1_image2', $settings );
			}
			include firecore_get_template('/about/style1.php');
		}
		if ( $settings['styles'] == 'style_2' ) {
			// About Style2 Images
			if ( empty( $settings['about_s2_image1']['id'] && ! empty( $settings['about_s2_image1']['url'] ) ) ) {
				$about_s2_image1_url = $settings['about_s2_image1']['url'];
			} else {
				$about_s2_image1_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_s2_image1']['id'], 'about_s2_image1', $settings );
			}
			if ( empty( $settings['about_s2_image2']['id'] && ! empty( $settings['about_s2_image2']['url'] ) ) ) {
				$about_s2_image2_url = $settings['about_s2_image2']['url'];
			} else {
				$about_s2_image2_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_s2_image2']['id'], 'about_s2_image2', $settings );
			}
			if ( empty( $settings['about_s2_badge1']['id'] && ! empty( $settings['about_s2_badge1']['url'] ) ) ) {
				$about_s2_badge1_url = $settings['about_s2_badge1']['url'];
			} else {
				$about_s2_badge1_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_s2_badge1']['id'], 'about_s2_badge1', $settings );
			}
			include firecore_get_template('/about/style2.php');
		}
		if ( $settings['styles'] == 'style_3' ) {
			// About Style3 Images
			if ( empty( $settings['about_s3_image1']['id'] && ! empty( $settings['about_s3_image1']['url'] ) ) ) {
				$about_s3_image1_url = $settings['about_s3_image1']['url'];
			} else {
				$about_s3_image1_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_s3_image1']['id'], 'about_s3_image1', $settings );
			}
			if ( empty( $settings['about_s3_image2']['id'] && ! empty( $settings['about_s3_image2']['url'] ) ) ) {
				$about_s3_image2_url = $settings['about_s3_image2']['url'];
			} else {
				$about_s3_image2_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_s3_image2']['id'], 'about_s3_image2', $settings );
			}
			include firecore_get_template('/about/style3.php');
		}
	}
}
