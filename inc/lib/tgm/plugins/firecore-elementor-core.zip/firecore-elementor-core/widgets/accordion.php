<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_Accordion extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-accordion';
	}

	public function get_title() {
		return esc_html__( 'Accordion', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Acordion Content ===== */
		$this->start_controls_section(
			'section_content_acordions',
			[
				'label' => esc_html__( 'Acordion', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'style', [
				'label' => __( 'Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style One', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style Two', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'accordion_gradient_styles',
			[
				'label' => __( 'Color Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'color_style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'color_style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
				],
				'default' => 'color_style_1'
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'accordion_image',
				'default'   => 'firecore-image(530x370)',
				'separator' => 'before',
				'exclude'   => [
					'custom',
				],
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'photo',
			[
				'label'   => __( 'Thumbnail Image', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'firecore-flaticon',
				],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Title', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'counting',
			[
				'label'       => esc_html__( 'Counter', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( '01', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Description', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'acordion_items',
			[
				'label'       => esc_html__( 'Items', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'      => esc_html__( 'Q: Why should I attend community college?', 'firecore-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'firecore-elementor-core' ),
					],
					[
						'title'      => esc_html__( 'Q: Why should I attend community college?', 'firecore-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'firecore-elementor-core' ),
					],
					[
						'title'      => esc_html__( 'Q: Why should I attend community college?', 'firecore-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'firecore-elementor-core' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		$this->add_control(
			'firecore_inactive_icon',
			[
				'label' => esc_html__( 'Inactive Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fas fa-arrow-right',
					'library' 	=> 'firecore-flaticon',
				],
			]
		);
		$this->add_control(
			'firecore_active_icon',
			[
				'label' => esc_html__( 'Active Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fas fa-arrow-down',
					'library' 	=> 'firecore-flaticon',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Team Items Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'accordion_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'accordion_item_item_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .accordion-item',
			]
		);
		$this->add_responsive_control(
			'item_box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */





		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'accordion_item_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'accordion_item_title_tab' );
		$this->start_controls_tab(
			'accordion_item_title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_title_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .title' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_title_normal_border',
				'selector' => '{{WRAPPER}} .accordion-item .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_normal_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'accordion_item_title_item_active',
			[
				'label' => esc_html__( 'Active', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_title_active_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_title_active_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .title' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_title_active_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item.active .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_active_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_active_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_title_active_border',
				'selector' => '{{WRAPPER}} .accordion-item.active .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_active_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item.active .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Description Style ===== */
		$this->start_controls_section(
			'accordion_item_description_style',
			[
				'label' => esc_html__( 'Description Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'accordion_item_description_tab' );
		$this->start_controls_tab(
			'accordion_item_description_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_description_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-body .description' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_description_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-body' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_description_normal_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item .accordion-body .description',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .accordion-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_description_normal_border',
				'selector' => '{{WRAPPER}} .accordion-item .accordion-body',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_border_normal_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'accordion_item_description_item_active',
			[
				'label' => esc_html__( 'Active', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_description_active_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-body .description' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_description_active_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-body' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_description_active_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item.active .accordion-body .description',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_active_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .accordion-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_description_active_border',
				'selector' => '{{WRAPPER}} .accordion-item.active .accordion-body',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_border_active_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item.active .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */



		/* ===== Begin Icons Style ===== */
		$this->start_controls_section(
			'accordion_item_icons_styling',
			[
				'label' => esc_html__( 'Icons Styling', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$this->start_controls_tabs( 'accordion_item_icons_tab' );
		$this->start_controls_tab(
			'accordion_item_icons_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'accordion_item_icons_normal_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .accordion-item .accordion-header span',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_icons_normal_border',
				'selector' => '{{WRAPPER}} .accordion-item .accordion-header span',
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_border_normal_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_normal_size',
			[
				'label' => esc_html__( 'Size', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_normal_move_left_right',
			[
				'label' => esc_html__( 'Icon Move Left Right', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_normal_move_up_down',
			[
				'label' => esc_html__( 'Icon Move Up Down', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'accordion_item_icons_item_active',
			[
				'label' => esc_html__( 'Active', 'firecore-elementor-core' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'accordion_item_icons_active_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .accordion-item.active .accordion-header span',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_icons_active_border',
				'selector' => '{{WRAPPER}} .accordion-item.active .accordion-header span',
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_border_active_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_active_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_active_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_active_size',
			[
				'label' => esc_html__( 'Size', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_active_move_left_right',
			[
				'label' => esc_html__( 'Icon Move Left Right', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_active_move_up_down',
			[
				'label' => esc_html__( 'Icon Move Up Down', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Icon Style ===== */

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html( 'post' );
		// Image handling
		$image_url = '';
		if ( ! empty( $acordion_items['photo']['url'] ) ) {
			if ( ! empty( $acordion_items['photo']['id'] ) ) {
				$image_url = Group_Control_Image_Size::get_attachment_image_src(
					$acordion_items['photo']['id'],
					'accordion_image',
					$acordion_items
				);
			} else {
				$image_url = esc_url( $acordion_items['photo']['url'] );
			}
		}

		if ( $settings['style'] == 'style_1' ) {
			include firecore_get_template('/accordion/style1.php');
		}
		if ( $settings['style'] == 'style_2' ) {
			include firecore_get_template('/accordion/style2.php');
		}

	}
}
