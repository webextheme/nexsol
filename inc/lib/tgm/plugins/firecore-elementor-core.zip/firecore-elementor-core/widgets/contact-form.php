<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;

class FIRECORE_Contact_Form extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-contact-form';
	}

	public function get_title() {
		return esc_html__( 'Contact Form', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function get_as_contact_form(){
		if ( ! class_exists( 'WPCF7' ) ) {
				return;
		}
		$as_cfa         = array();
		$as_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
		$as_forms       = get_posts( $as_cf_args );
		$as_cfa         = ['0' => esc_html__( 'Select Form', 'firecore-elementor-core' ) ];
		if( $as_forms ){
			foreach ( $as_forms as $as_form ){
				$as_cfa[$as_form->ID] = $as_form->post_title;
			}
		}
		else{
			$as_cfa[ esc_html__( 'No contact form found', 'firecore-elementor-core' ) ] = 0;
		}
		return $as_cfa;
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/

		$this->start_controls_section(
			'contact_form_section',
			[
				'label' 	=> __( 'Contact Form', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
    );
		$this->add_control(
			'layout_style',
			[
				'label' => __( 'Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'firecore_select_contact_form',
			[
				'label'   => esc_html__( 'Select Form', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '0',
				'options' => $this->get_as_contact_form(),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label' 	=> __( 'Sub Title', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __( 'Sub Title', 'firecore-elementor-core' ),
				'condition'	=> [
					'layout_style' => ['style_1','style_2'],
				]
			]
		);
		$this->add_control(
			'title',
			[
				'label' 	=> __( 'Title', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __( 'Title', 'firecore-elementor-core' ),
				'condition'	=> [
					'layout_style' => ['style_1','style_2'],
				]
			]
		);
		$this->add_control(
			'description',
			[
				'label' 	=> __( 'Description', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default'  	=> __( 'Lorem ipsum dolor sit amet', 'firecore-elementor-core' ),
				'condition'	=> [
					'layout_style' => ['style_1','style_2'],
				]
			]
		);
		$this->add_control(
			'sideline_show_hide',
			[
				'label'        => esc_html__( 'Show Sub Title Sideline?', 'firecore-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'firecore-elementor-core' ),
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/




		/*===================================
		Start Wrapper Style
		=====================================*/
		$this->start_controls_section(
			'wrapper_style',
			[
				'label' 	=> __( 'Wrapper Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'wrapper_bg_color',
			[
				'label' 		=> __( 'Background Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .contact-form' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .webex-form' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .webex-form-style2' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'sideline_color',
			[
				'label' 		=> __( 'Side Line Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .side-line-left:before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .side-line-left:after' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label' 		=> __( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label' 		=> __( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'wrapper_border',
				'selector' => '{{WRAPPER}} .webex-form',
			]
		);
		$this->add_responsive_control(
			'wrapper_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Wrapper Style
		=====================================*/



		/*===================================
		Start Subtitle Style
		=====================================*/
		$this->start_controls_section(
			'subtitle_style',
			[
				'label' 	=> __( 'Sub Title Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'subtitle_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .form-subtitle' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'subtitle_typography',
				'label' 	=> __( 'Typography', 'firecore-elementor-core' ),
				'selector' 	=> '{{WRAPPER}} .form-subtitle',
			]
		);
		$this->add_responsive_control(
			'subtitle_margin',
			[
				'label' 		=> __( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .form-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'subtitle_padding',
			[
				'label' 		=> __( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .form-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->end_controls_section();
		/*===================================
		End Subtitle Style
		=====================================*/




		/*===================================
		Start Title Style
		=====================================*/
		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> __( 'Title Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .form-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'label' 	=> __( 'Typography', 'firecore-elementor-core' ),
				'selector' 	=> '{{WRAPPER}} .form-title',
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .form-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .form-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->end_controls_section();
		/*===================================
		End Subtitle Style
		=====================================*/


		/*===================================
		Start Description Style
		=====================================*/
		$this->start_controls_section(
			'description_style',
			[
				'label' 	=> __( 'Description Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'description_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .form-description' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'description_typography',
				'label' 	=> __( 'Typography', 'firecore-elementor-core' ),
				'selector' 	=> '{{WRAPPER}} .form-description',
			]
		);
		$this->add_responsive_control(
			'description_margin',
			[
				'label' 		=> __( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .form-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'description_padding',
			[
				'label' 		=> __( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .form-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->end_controls_section();
		/*===================================
		End Subtitle Style
		=====================================*/

		/*===================================
		Start Select Style
		=====================================*/
		$this->start_controls_section(
			'form_select_style',
			[
				'label' 	=> __( 'Select Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'form_select_tabs'
		);
		$this->start_controls_tab(
			'form_select_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'select_normal_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'select_bg_color',
			[
				'label' 		=> __( 'Background Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .webex-form .custom-select-categories .list' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'select_border_color',
			[
				'label' 		=> __( 'Border Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories' => 'border-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'form_select_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'input_select_hover_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories:hover' => 'color: {{VALUE}}!important',
				],
			]
		);
		$this->add_control(
			'select_bg_hover_color',
			[
				'label' 		=> __( 'Background Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'select_border_hover_color',
			[
				'label' 		=> __( 'Border Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories:hover' => 'border-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'form_select_list_hover_tab',
			[
				'label' => esc_html__( 'List Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'input_select_list_hover_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories .option:hover' => 'color: {{VALUE}}!important',
				],
			]
		);
		$this->add_control(
			'select_bg_list_hover_color',
			[
				'label' 		=> __( 'Background Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories .option:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .webex-form .custom-select-categories .option.focus' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .webex-form .custom-select-categories .option.selected.focus' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'select_list_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories .list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'select_list_border',
				'selector' => '{{WRAPPER}} .webex-form .custom-select-categories .list',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'select_typography',
				'label' 	=> __( 'Typography', 'firecore-elementor-core' ),
				'selector' 	=> '{{WRAPPER}} .webex-form .custom-select-categories',
			]
		);
		$this->add_responsive_control(
			'select_margin',
			[
				'label' 		=> __( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'select_padding',
			[
				'label' 		=> __( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'select_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .custom-select-categories' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Select Style
		=====================================*/



		/*===================================
		Start Input Style
		=====================================*/
		$this->start_controls_section(
			'form_input_style',
			[
				'label' 	=> __( 'Input Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'form_input_tabs'
		);
		$this->start_controls_tab(
			'form_input_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'input_normal_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .form-control' => 'color: {{VALUE}}',
					'{{WRAPPER}} .webex-form .form-control::placeholder' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .webex-form .form-control::-webkit-input-placeholder' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .webex-form .form-control:-moz-placeholder' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .webex-form .form-control:-ms-input-placeholder' => 'color: {{VALUE}}!important',
				],
			]
		);
		$this->add_control(
			'input_bg_normal_color',
			[
				'label' 		=> __( 'Background Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .form-control' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'input_border_normal_color',
				'selector' => '{{WRAPPER}} .webex-form .form-control',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'form_input_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'input_hover_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .form-control:hover::placeholder' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .webex-form .form-control:hover::-webkit-input-placeholder' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .webex-form .form-control:hover:-moz-placeholder' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .webex-form .form-control:hover:-ms-input-placeholder' => 'color: {{VALUE}}!important',
				],
			]
		);
		$this->add_control(
			'input_bg_hover_color',
			[
				'label' 		=> __( 'Background Hover Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .form-control:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'input_border_hover_color',
				'selector' => '{{WRAPPER}} .webex-form .form-control:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'input_typography',
				'label' 	=> __( 'Typography', 'firecore-elementor-core' ),
				'selector' 	=> '{{WRAPPER}} .webex-form .form-control',
			]
		);
		$this->add_responsive_control(
			'input_margin',
			[
				'label' 		=> __( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .form-control' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'input_padding',
			[
				'label' 		=> __( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .form-control' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'input_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .form-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'input_height',
			[
				'label' => esc_html__( 'Height', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .webex-form .form-control' => 'height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Input Style
		=====================================*/



		/*===================================
		Start TextArea Style
		=====================================*/
		$this->start_controls_section(
			'form_textarea_style',
			[
				'label' 	=> __( 'Textarea Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'textarea_height',
			[
				'label' => esc_html__( 'Height', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .webex-form textarea.form-control' => 'min-height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'textarea_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form textarea.form-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End TextArea Style
		=====================================*/


		/*===================================
		Start Button Style
		=====================================*/
		$this->start_controls_section(
			'form_button_style',
			[
				'label' 	=> __( 'Button Style', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'form_button_tabs'
		);
		$this->start_controls_tab(
			'form_button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'button_normal_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one' => 'color: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'button_bg_normal_color',
			[
				'label' 		=> __( 'Background Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'button_border_normal_color',
			[
				'label' 		=> __( 'Border Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one' => 'border-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'form_button_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'button_hover_color',
			[
				'label' 		=> __( 'Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one:hover' => 'color: {{VALUE}}!important',
				],
			]
		);
		$this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( 'Background Hover Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'button_border_hover_color',
			[
				'label' 		=> __( 'Border Hover Color', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one:hover' => 'border-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Typography', 'firecore-elementor-core' ),
				'selector' 	=> '{{WRAPPER}} .webex-form .cs-btn-one',
			]
		);
		$this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .webex-form .cs-btn-one' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'textarea_width',
			[
				'label' => esc_html__( 'Width', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .webex-form .cs-btn-one' => 'width: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Button Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( $settings['layout_style'] == 'style_1' ) {
			include firecore_get_template('/contact-form/style1.php');
		}
		if ( $settings['layout_style'] == 'style_2' ) {
			include firecore_get_template('/contact-form/style2.php');
		}
		if ( $settings['layout_style'] == 'style_3' ) {
			include firecore_get_template('/contact-form/style3.php');
		}

	}
}
