<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;

class FIRECORE_Testimonials extends \Elementor\Widget_Base {

	public function get_name() {
		return  'testimonial-block';
	}

	public function get_title() {
		return esc_html__( 'Testimonial', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return array('allslider-js');
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Testimonial Content ===== */
		$this->start_controls_section(
			'section_content_item',
			[
				'label' => esc_html__( 'Testimonials', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_styles',
			[
				'label' => __( 'Testimonial Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Layout', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid'   => esc_html__( 'Grid', 'firecore-elementor-core' ),
					'slider' => esc_html__( 'Slider', 'firecore-elementor-core' ),
				],
			]
		);
		$this->add_responsive_control(
			'column',
			[
				'label'                => esc_html__( 'Grid Column', 'firecore-elementor-core' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					''  => esc_html__( 'Default', 'firecore-elementor-core' ),
					'1' => esc_html__( '1 column', 'firecore-elementor-core' ),
					'2' => esc_html__( '2 column', 'firecore-elementor-core' ),
					'3' => esc_html__( '3 column', 'firecore-elementor-core' ),
					'4' => esc_html__( '4 column', 'firecore-elementor-core' ),
					'5' => esc_html__( '5 column', 'firecore-elementor-core' ),
					'6' => esc_html__( '6 column', 'firecore-elementor-core' ),
				],
				'default'              => 4,
				'tablet_extra_default' => '',
				'tablet_default'       => '',
				'mobile_default'       => '',
				'condition'            => [
					'layout' => 'grid',
				],
				'selectors'            => [
					'{{WRAPPER}} .testimonial-block-wrapper' => 'grid-template-columns: repeat( {{VALUE}}, 1fr );',
				],
			]
		);
		$this->add_control(
			'item_number',
			[
				'label'       => esc_html__( 'Item Number', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'description' => esc_html__( 'Number Item', 'firecore-elementor-core' ),
				'default'     => 4,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'condition'            => [
					'layout' => 'slider',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'testimonial_image',
				'default'   => 'full',
				'separator' => 'before',
				'exclude'   => [
					'custom',
				],
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'photo',
			[
				'label'   => __( 'Image', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Quote Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'firecore-flaticon',
				],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Item Name', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'subtitle',
			[
				'label'       => esc_html__( 'Subtitle', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'subtitle', 'firecore-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'subtitle_tag',
			[
				'label' 	=> esc_html__( 'Subtitle Tag', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h6',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'firecore-elementor-core'),
					'h2' 		=> esc_html__('h2', 'firecore-elementor-core'),
					'h3' 		=> esc_html__('h3', 'firecore-elementor-core'),
					'h4'		=> esc_html__('h4', 'firecore-elementor-core'),
					'h5' 		=> esc_html__('h5', 'firecore-elementor-core'),
					'h6' 		=> esc_html__('h6', 'firecore-elementor-core'),
					'span' 	=> esc_html__('span', 'firecore-elementor-core'),
					'p' 		=> esc_html__('p', 'firecore-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'rating',
			[
				'label' => esc_html__( 'Rating', 'firecore-elementor-core' ),
				'type'  => Controls_Manager::NUMBER,
				'min'   => 0,
				'max'   => 5,
				'step'  => 0.1,
			]
		);
		$repeater->add_control(
			'title_link',
			[
				'label' => esc_html__( "Title Link URL", 'firecore-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
				]
			]
		);
		$repeater->add_control(
			'description',
			[
				'label' => esc_html__( "Paragraph", 'firecore-elementor-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( "Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.", 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_items',
			[
				'label'       => esc_html__( 'Testimonial Items', 'firecore-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'      => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
						'subtitle' => esc_html__( 'Subtitle Place Here', 'firecore-elementor-core' ),
						'rating'      => '3.5',
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.', 'firecore-elementor-core' ),
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'title'      => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
						'subtitle' => esc_html__( 'Subtitle Place Here', 'firecore-elementor-core' ),
						'rating'      => '3.5',
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.', 'firecore-elementor-core' ),
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'title'      => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
						'subtitle' => esc_html__( 'Subtitle Place Here', 'firecore-elementor-core' ),
						'rating'      => '5',
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.', 'firecore-elementor-core' ),
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'title'      => esc_html__( 'Title Place Here', 'firecore-elementor-core' ),
						'subtitle' => esc_html__( 'Subtitle Place Here', 'firecore-elementor-core' ),
						'rating'      => '2',
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing ipsum rephen elit libero facilisis etiam ridiculus.', 'firecore-elementor-core' ),
						'photo'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		$this->end_controls_section();
		/* ===== End Testimonial Content ===== */





		/* ===== Begin Testimonial Settings ===== */
		$this->start_controls_section(
			'section_content_settings',
			[
				'label' => esc_html__( 'Testimonials Settings', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'title_show_hide',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Show Title?', 'firecore-elementor-core' ),
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'  => esc_html__( 'Show', 'firecore-elementor-core' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'subtitle_show_hide',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Show Subtitle?', 'firecore-elementor-core' ),
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'  => esc_html__( 'Show', 'firecore-elementor-core' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'ratings_show_hide',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Show Ratings?', 'firecore-elementor-core' ),
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'  => esc_html__( 'Show', 'firecore-elementor-core' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'quote_icon_show_hide',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Show Quote Icon?', 'firecore-elementor-core' ),
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'firecore-elementor-core' ),
				'label_on'  => esc_html__( 'Show', 'firecore-elementor-core' ),
				'separator' => 'before',
			]
		);
		$this->end_controls_section();
		/* ===== End Testimonial Settings ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'testimonial_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'text_align',
			[
				'label'     => esc_html__( 'Alignment', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'firecore-elementor-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-inner' => 'text-align: {{Value}};',
				],
			]
		);
		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .testimonial-block-wrapper' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .testimonial-block-wrapper' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_item_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-block .testimonial-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'testimonial_item_tab' );
		$this->start_controls_tab(
			'testimonial_item_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .testimonial-block .testimonial-inner',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_normal_border',
				'selector' => '{{WRAPPER}} .testimonial-block .testimonial-inner',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'testimonial_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block:hover .testimonial-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_hover_shadow',
				'selectors' => [
					'{{WRAPPER}} .testimonial-block:hover .testimonial-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_hover_border',
				'selector' => '{{WRAPPER}} .testimonial-block:hover .testimonial-inner',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'item_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-block .testimonial-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */






		/* ===== Begin Thumbnail Style ===== */
		$this->start_controls_section(
			'testimonial_item_thumb_style',
			[
				'label' => esc_html__( 'Thumb Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'testimonial_thumb_box_shadow',
				'label' => __( 'Box Shadow', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .testimonial-block .testimonial-thumb',
			]
		);
		$this->add_group_control(
		\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'testimonial_thumb_border',
				'label' => esc_html__( 'Border', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .testimonial-block .testimonial-thumb',
			]
		);
		$this->add_responsive_control(
			'testimonial_thumb_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .testimonial-block .testimonial-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .testimonial-block .testimonial-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			]
		);
		$this->add_responsive_control(
			'testimonial_thumb_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .testimonial-block .testimonial-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'testimonial_thumb_size',
			[
				'label' => esc_html__( 'Size', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 220,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-thumb' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */





		/* ===== Begin Comments Style ===== */
		$this->start_controls_section(
			'testimonial_comments_style',
			[
				'label' => esc_html__( 'comments Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'testimonial_comments_tabs' );
		$this->start_controls_tab(
			'testimonial_comments_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_comments_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .comments' => 'color: {{VALUE}};',
					'{{WRAPPER}} .comments a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'testimonial_comments_normal_typography',
				'selector' 	=> '{{WRAPPER}} .comments',
			]
		);
		$this->add_responsive_control(
			'testimonial_comments_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .comments' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_comments_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .comments' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'testimonial_comments_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_comments_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .comments:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .comments a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'testimonial_comments_hover_typography',
				'selector' 	=> '{{WRAPPER}} .comments:hover',
			]
		);
		$this->add_responsive_control(
			'testimonial_comments_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .comments:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_comments_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .comments:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'testimonial_comment_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_comments_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block:hover .comments' => 'color: {{VALUE}};',
					'{{WRAPPER}} .testimonial-block:hover .comments a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */






		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'testimonial_title_style',
			[
				'label' => esc_html__( 'Title Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'testimonial_title_tabs' );
		$this->start_controls_tab(
			'testimonial_title_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .testimonial-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'testimonial_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .testimonial-title',
			]
		);
		$this->add_responsive_control(
			'testimonial_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'testimonial_title_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-title:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .testimonial-title a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'testimonial_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .testimonial-title:hover',
			]
		);
		$this->add_responsive_control(
			'testimonial_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'testimonial_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_title_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block:hover .testimonial-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .testimonial-block:hover .testimonial-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Subtitle Style ===== */
		$this->start_controls_section(
			'testimonial_subtitle_style',
			[
				'label' => esc_html__( 'Subtitle Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'testimonial_subtitle_tabs' );
		$this->start_controls_tab(
			'testimonial_subtitle_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_subtitle_normal_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-subtitle' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'testimonial_subtitle_normal_typography',
				'selector' 	=> '{{WRAPPER}} .testimonial-subtitle',
			]
		);
		$this->add_responsive_control(
			'testimonial_subtitle_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_subtitle_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'testimonial_subtitle_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'testimonial_subtitle_hover_color',
			[
				'label'     => esc_html__( 'Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-subtitle:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'testimonial_subtitle_hover_typography',
				'selector' 	=> '{{WRAPPER}} .testimonial-subtitle:hover',
			]
		);
		$this->add_responsive_control(
			'testimonial_subtitle_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-subtitle:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_subtitle_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-subtitle:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Subtitle Style ===== */





		/* ===== Begin Star Ratings Style ===== */
		$this->start_controls_section(
			'testimonial_item_ratings_style',
			[
				'label' => esc_html__( 'Ratings Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'testimonial_rating_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .testimonial-block .star-rating i',
			]
		);
		$this->add_control(
			'testimonial_rating_color',
			[
				'label'     => esc_html__( 'Star Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .star-rating i::before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'testimonial_rating_inactive_color',
			[
				'label'     => esc_html__( 'Inactive Star Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .star-rating i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'testimonial_rating_icon_gap',
			[
				'label' => esc_html__( 'Star gap', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .star-rating i' => 'margin-right: {{SIZE}}{{UNIT}}; margin-left:{{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_rating_icon_margin',
			[
				'label' 		=> esc_html__( 'Icon Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testimonial-block .star-rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */




		/* ===== Begin Quote Style ===== */
		$this->start_controls_section(
			'testimonial_item_quote_style',
			[
				'label' => esc_html__( 'Quote Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'testimonial_quote_typography',
				'label' => esc_html__( 'Typography', 'firecore-elementor-core' ),
				'selector' => '{{WRAPPER}} .testimonial-block .testimonial-quote-icon',
			]
		);
		$this->add_control(
			'testimonial_quote_color',
			[
				'label'     => esc_html__( 'Quote Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-quote-icon' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'testimonial_quote_stroke_color',
			[
				'label'     => esc_html__( 'Quote Stroke Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-quote-icon' => '-webkit-text-stroke-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'testimonial_quote_stroke_width',
			[
				'label'     => esc_html__( 'Quote Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'   => 1,
				'max'   => 5,
				'step'  => 1,
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-quote-icon' => '-webkit-text-stroke-width: {{VALUE}}px;',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_quote_opacity',
			[
				'label' 		=> esc_html__( 'Quote Opacity', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-quote-icon' => 'opacity: {{SIZE}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_quote_top_bottom',
			[
				'label' => esc_html__( 'Quote Icon Top/Bottom Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -400,
						'max' => 400,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-quote-icon' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'testimonial_quote_left_right',
			[
				'label' => esc_html__( 'Quote Icon Left/Right Movement', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -400,
						'max' => 400,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-block .testimonial-quote-icon' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */


		/* ===== Begin Carousel Options ===== */
		webex_get_elementor_carousel_options($this);
		/* ===== End Carousel Options ===== */


}


	protected function render_stars( $rating ) {
		$rating         = (float) $rating;
		$floored_rating = floor( $rating );
		$icon           = '&#xe907;';
		$stars_html = '';

		for ( $stars = 1.0; $stars <= 5; $stars++ ) {
			if ( $stars <= $floored_rating ) {
				$stars_html .= '<i class="webexbase-icon-star">' . $icon . '</i>';
			} elseif ( $floored_rating + 1 === $stars && $rating !== $floored_rating ) {
				$stars_html .= '<i class="star-' . ( $rating - $floored_rating ) * 10 . '">' . $icon . '</i>';
			} else {
				$stars_html .= '<i class="webexbase-icon-star-1">' . $icon . '</i>';
			}
		}
		return $stars_html;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$data_options['items'] 				= $settings['item_number'];
		$data_options['items_lg'] 				= $settings['items_lg'];
		$data_options['items_md'] 				= $settings['items_md'];
		$data_options['items_sm'] 				= $settings['items_sm'];
		$data_options['items_xs'] 				= $settings['items_xs'];


		$data_options['margin']             = $settings['margin_items'];
		$data_options['loop']               = $settings['infinite'] === 'yes' ? true : false;
		$data_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$data_options['nav']               = $settings['nav_control'] === 'yes' ? true : false;
		$data_options['dots']               = $settings['dot_control'] === 'yes' ? true : false;
		$data_options['center']				= $settings['center_mode'] === 'yes' ? true : false;
		$data_options['rtl']				= is_rtl() ? true: false;


		if ( empty( $settings['testimonial_items'] ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'testimonial-block-wrapper' );
		if( 'slider' == $settings['layout'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'firecore-slider-wrapper' );
		}

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php if( 'grid' == $settings['layout'] ) : ?>
			<?php
				foreach ( $settings['testimonial_items'] as $index => $item ) {
					$this->render_single_item( $index, $item );
				}
			?>
			<?php elseif( 'slider' == $settings['layout'] ) : ?>
				<div class="webex-slider testimonial-carousel-<?php echo esc_attr( $settings['testimonial_styles'] ) ?>">
					<div class="owl-carousel webex-carousel" data-options="<?php echo esc_attr(json_encode($data_options)); ?>">
						<?php foreach ( $settings['testimonial_items'] as $index => $item ) : ?>
						<div class="firecore-slider-item">
							<?php $this->render_single_item( $index, $item ); ?>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function render_single_item( $index, $item ) {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');

		$rating_count = $item['rating'];
		$title = $item['title'];
		$title_tag = $item['title_tag'];
		$subtitle = $item['subtitle'];
		$subtitle_tag = $item['subtitle_tag'];
		$description = $item['description'];
		$firecore_icons = $item['firecore_icons']['value'];

		$custom_link = $item['title_link'];
		$target = ( $custom_link && $custom_link['is_external'] ) ? ' target="_blank"' : '';
		$url = ( $custom_link && $custom_link['url'] ) ? $custom_link['url'] : '';

		if ( empty( $item['photo']['id'] && ! empty( $item['photo']['url'] ) ) ) {
			$image_url = $item['photo']['url'];
		} else {
			$image_url = Group_Control_Image_Size::get_attachment_image_src( $item['photo']['id'], 'testimonial_image', $settings );
		}

		switch ( $settings['testimonial_styles'] ) {
			case 'style_1':
				include firecore_get_template( '/testimonials/style1.php' );
				break;
			case 'style_2':
				include firecore_get_template( '/testimonials/style2.php' );
				break;
			case 'style_3':
				include firecore_get_template( '/testimonials/style3.php' );
				break;
		}
	}
}
