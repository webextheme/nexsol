<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_Before_After_Slider extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-before-after-slider';
	}

	public function get_title() {
		return esc_html__( 'Before After Slider', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return 'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'before_image',
			[
				'label' 	=> esc_html__( 'Before Image', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'after_image',
			[
				'label' 	=> esc_html__( 'After Image', 'firecore-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'before_after_image',
				'default'   => 'firecore-image(1300x620)',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		// About Style1 Images
		if ( empty( $settings['before_image']['id'] && ! empty( $settings['before_image']['url'] ) ) ) {
			$before_image_url = $settings['before_image']['url'];
		} else {
			$before_image_url = Group_Control_Image_Size::get_attachment_image_src( $settings['before_image']['id'], 'before_after_image', $settings );
		}
		if ( empty( $settings['after_image']['id'] && ! empty( $settings['after_image']['url'] ) ) ) {
			$after_image_url = $settings['after_image']['url'];
		} else {
			$after_image_url = Group_Control_Image_Size::get_attachment_image_src( $settings['after_image']['id'], 'before_after_image', $settings );
		}
		?>

		<div class="before-after-slider1">
			<!-- The before image is first -->
			<img class="img-full" src="<?php echo esc_url( $before_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
			<!-- The after image is last -->
			<img class=" img-full" src="<?php echo esc_url( $after_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
		</div>

		<?php
	}
}