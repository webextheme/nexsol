<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;

class FIRECORE_Clients extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-clients';
	}

	public function get_title() {
		return esc_html__( 'Clients', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return array('allslider-js');
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Clients Content ===== */
		$this->start_controls_section(
			'section_content_item',
			[
				'label' => esc_html__( 'Clients', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'client_styles',
			[
				'label' => __( 'Client Styles', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'firecore-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'firecore-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'dark_light_styles',
			[
				'label' => __( 'Dark\Light', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'light_client' => esc_html__( 'Light', 'firecore-elementor-core' ),
					'dark_client' => esc_html__( 'Dark', 'firecore-elementor-core' ),
				],
				'default' => 'light_client'
			]
		);
		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Layout', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid'   => esc_html__( 'Grid', 'firecore-elementor-core' ),
					'slider' => esc_html__( 'Slider', 'firecore-elementor-core' ),
				],
			]
		);
		$this->add_responsive_control(
			'column',
			[
				'label'                => esc_html__( 'Grid Column', 'firecore-elementor-core' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					''  => esc_html__( 'Default', 'firecore-elementor-core' ),
					'1' => esc_html__( '1 column', 'firecore-elementor-core' ),
					'2' => esc_html__( '2 column', 'firecore-elementor-core' ),
					'3' => esc_html__( '3 column', 'firecore-elementor-core' ),
					'4' => esc_html__( '4 column', 'firecore-elementor-core' ),
					'5' => esc_html__( '5 column', 'firecore-elementor-core' ),
					'6' => esc_html__( '6 column', 'firecore-elementor-core' ),
				],
				'default'              => 4,
				'tablet_extra_default' => '',
				'tablet_default'       => '',
				'mobile_default'       => '',
				'condition'            => [
					'layout' => 'grid',
				],
				'selectors'            => [
					'{{WRAPPER}} .client-block-items' => 'grid-template-columns: repeat( {{VALUE}}, 1fr );',
				],
			]
		);
		$this->add_control(
			'item_number',
			[
				'label'       => esc_html__( 'Item Number', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'description' => esc_html__( 'Number Item', 'firecore-elementor-core' ),
				'default'     => 4,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8),
				'condition'            => [
					'layout' => 'slider',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'client_image',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'client_image',
			[
				'label' 	=> esc_html__( 'Client Image', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'client_items',
			[
				'label' => __('Client Items', 'firecore-elementor-core'),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'prevent_empty' => false,
			]
		);
		$this->end_controls_section();
		/* ===== End Clients Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'clients_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .client-block-items' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .client-block-items' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_responsive_control(
			'clients_content_item_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .client-block-items .client-block' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'clients_content_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .client-block-items .client-block' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .firecore-slider-item',
			]
		);
		$this->add_responsive_control(
			'item_box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .client-block-items .firecore-slider-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'item_size',
			[
				'label' => esc_html__( 'Logo Size', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 1200,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .client-block-items .client-block img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'clients_item_tab' );
		$this->start_controls_tab(
			'clients_item_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .client-block-items .client-block, {{WRAPPER}} .client-block-items .client-wrap-style_2' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .client-block-items .client-block, {{WRAPPER}} .client-block-items .client-wrap-style_2',
			]
		);
		$this->add_responsive_control(
			'item_normal_opacity',
			[
				'label' 		=> esc_html__( 'Opacity', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .client-block-items .client-block img' => 'opacity: {{SIZE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'clients_item_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'item_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .client-block-items .client-block:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_hover_shadow',
				'selectors' => [
					'{{WRAPPER}} .client-block-items .client-block:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'item_hover_opacity',
			[
				'label' 		=> esc_html__( 'Opacity', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .client-block-items .client-block:hover img' => 'opacity: {{SIZE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Content Style ===== */



		/* ===== Begin Carousel Options ===== */
		webex_get_elementor_carousel_options($this);
		/* ===== End Carousel Options ===== */


}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$data_options['items'] 				= $settings['item_number'];
		$data_options['items_lg'] 				= $settings['items_lg'];
		$data_options['items_md'] 				= $settings['items_md'];
		$data_options['items_sm'] 				= $settings['items_sm'];
		$data_options['items_xs'] 				= $settings['items_xs'];


		$data_options['margin']             = $settings['margin_items'];
		$data_options['loop']               = $settings['infinite'] === 'yes' ? true : false;
		$data_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$data_options['nav']               = $settings['nav_control'] === 'yes' ? true : false;
		$data_options['dots']               = $settings['dot_control'] === 'yes' ? true : false;
		$data_options['center']				= $settings['center_mode'] === 'yes' ? true : false;
		$data_options['rtl']				= is_rtl() ? true: false;


		$this->add_render_attribute( 'wrapper', 'class', 'client-block-items' );
		if( 'slider' == $settings['layout'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'firecore-slider-wrapper' );
		}

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php if( 'grid' == $settings['layout'] ) : ?>
			<?php
				foreach ( $settings['client_items'] as $index => $item ) {
					$this->render_single_item( $index, $item );
				}
			?>
			<?php elseif( 'slider' == $settings['layout'] ) : ?>
				<div class="webex-slider">
					<div class="owl-carousel webex-carousel" data-options="<?php echo esc_attr(json_encode($data_options)); ?>">
						<?php foreach ( $settings['client_items'] as $index => $item ) : ?>
						<div class="firecore-slider-item client-wrap-<?php echo esc_attr( $settings['client_styles'] ) ?>">
							<?php $this->render_single_item( $index, $item ); ?>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function render_single_item( $index, $item ) {
		$settings = $this->get_settings_for_display();

		if ( empty( $item['client_image']['id'] && ! empty( $item['client_image']['url'] ) ) ) {
			$client_image_url = $item['client_image']['url'];
		} else {
			$client_image_url = Group_Control_Image_Size::get_attachment_image_src( $item['client_image']['id'], 'client_image', $settings );
		}

		if ( $settings['client_styles'] == 'style_1' ) {
			include firecore_get_template('/clients/style1.php');
		}
		if ( $settings['client_styles'] == 'style_2' ) {
			include firecore_get_template('/clients/style2.php');
		}

	}
}
