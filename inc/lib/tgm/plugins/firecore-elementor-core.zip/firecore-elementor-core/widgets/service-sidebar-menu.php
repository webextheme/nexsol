<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class FIRECORE_Service_Sidebar_Menu extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-service-sidebar-menu';
	}

	public function get_title() {
		return esc_html__( 'Service Sidebar Menu', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {
		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'section_menu_type',
			[
				'label' => esc_html__( 'Service Sidebar Menu', 'firecore-elementor-core' ),
			]
		);

		$this->add_control(
			'menu_type',
			[
				'label'   => esc_html__( 'Menu', 'firecore-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'theme-default' => esc_html__( 'Theme Default', 'firecore-elementor-core' ),
					'custom'        => esc_html__( 'Custom Menu', 'firecore-elementor-core' ),
				],
				'default' => 'theme-default',
			]
		);

		$this->add_control(
			'selected_menu',
			[
				'label'     => esc_html__( 'Select Menu', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_menus_list(),
				'condition' => [
					'menu_type' => 'custom',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/


		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'service_sidebar_menu_content_style',
			[
				'label' => esc_html__( 'Content Style', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'service_sidebar_menu_content_bg',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .menu-sidebar-service-nav-menu-container' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'service_sidebar_box_shadow',
			'selector' => '{{WRAPPER}} .menu-sidebar-service-nav-menu-container',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'service_sidebar_menu_content_border',
				'selector' => '{{WRAPPER}} .menu-sidebar-service-nav-menu-container',
			]
		);
		$this->add_responsive_control(
			'service_sidebar_menu_content_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .menu-sidebar-service-nav-menu-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'service_sidebar_menu_content_margin',
			[
				'label'      => esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .menu-sidebar-service-nav-menu-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'service_sidebar_menu_content_padding',
			[
				'label'      => esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .menu-sidebar-service-nav-menu-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */



		/*===================================
		Start Menu Styling
		=====================================*/
		$this->start_controls_section(
			'menu_styles',
			[
				'label' => esc_html__( 'Menu Items', 'firecore-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'menu_item_margin',
			[
				'label'      => esc_html__( 'Menu Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'menu_item_padding',
			[
				'label'      => esc_html__( 'Menu Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'service-sidebar-menu-tabs' );
		$this->start_controls_tab(
			'service-sidebar_menu_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'service-sidebar_menu_normal_color',
			[
				'label'     => esc_html__( 'Text Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li > a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'service-sidebar_menu_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li > a' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'service-sidebar_menu_typography',
				'selector' => '{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li > a',
			]
		);
		$this->end_controls_tab();

		//==== Hover Tab ===//
		$this->start_controls_tab(
			'service-sidebar_menu_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'service-sidebar_menu_hover_color',
			[
				'label'     => esc_html__( 'Text Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li:hover > a' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'service-sidebar_menu_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li:hover > a:before' => 'background-color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'service-sidebar_menu_hover_typography',
				'selector' => '{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li:hover > a',
			]
		);
		$this->end_controls_tab();

		//==== Active Tab ===//
		$this->start_controls_tab(
			'service-sidebar_menu_active',
			[
				'label' => esc_html__( 'Active', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'service-sidebar_menu_active_color',
			[
				'label'     => esc_html__( 'Text Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li.current_page_item > a' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'service-sidebar_menu_active_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li.current_page_item > a:before' => 'background-color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'service-sidebar_menu_active_typography',
				'selector' => '{{WRAPPER}} .service-sidebar-block .menu-sidebar-service-nav-menu-container .menu-sidebar-service-nav-menu > li.current_page_item > a',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Menu Styling
		=====================================*/

	}

	protected function render() {
		$settings = $this->get_settings_for_display();?>

		<div class="service-sidebar-block">
			<?php
			$args = [
				'container'       => 'div',
				'container_class' => 'menu-sidebar-service-nav-menu-container',
				'menu_class'      => 'menu-sidebar-service-nav-menu',
				'after'           => '',
				'link_before'     => '<span class="link-text">',
				'link_after'      => '</span>',
				'fallback_cb'     => false,
			];
			if ( 'custom' == $settings['menu_type'] && ! empty( $settings['selected_menu'] ) ) {
				$args['menu'] = $settings['selected_menu'];
			} elseif ( has_nav_menu( 'sidebar_service_menu' ) ) {
				$args['theme_location'] = 'sidebar_service_menu';
			}
			?>
			<?php wp_nav_menu( $args );?>
		</div>
	<?php
	}
	protected function get_menus_list() {
		$nav_menus = [];
		$terms     = get_terms( 'nav_menu' );
		foreach ( $terms as $term ) {
			$nav_menus[$term->name] = $term->name;
		}
		return $nav_menus;
	}
}

