<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
use Elementor\Utils;

class FIRECORE_Moving_Text extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-moving-text';
	}

	public function get_title() {
		return esc_html__( 'Moving Text', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'moving_direction',
			[
				'label' => __( 'Moving Direction', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'marquee_right_active' => esc_html__( 'Left To Right', 'firecore-elementor-core' ),
					'marquee_left_active' => esc_html__( 'Right To Left', 'firecore-elementor-core' ),
				],
				'default' => 'marquee_left_active'
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'moving_text_image',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'moving_text',
			[
				'type'        => Controls_Manager::TEXTAREA,
				'label' => esc_html__( 'Text', 'firecore-elementor-core' ),
			]
		);
		$repeater->add_control(
			'moving_text_icon_type',
			[
				'label' => __( 'Icon Type', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'image_icon' => esc_html__( 'Image Icon', 'firecore-elementor-core' ),
					'flat_icon' => esc_html__( 'Flat Icon', 'firecore-elementor-core' ),
				],
				'default' => 'flat_icon'
			]
		);
		$repeater->add_control(
			'firecore_icons',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'firecore-flaticon',
				],
				'condition' => [
					'moving_text_icon_type' => 'flat_icon',
				]
			]
		);
		$repeater->add_control(
			'firecore_image_icons',
			[
				'label' => esc_html__( 'Image Icon', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'moving_text_icon_type' => 'image_icon',
				]
			]
		);
		$this->add_control(
			'moving_text_block',
			[
				'label' => __('Moving Text', 'firecore-elementor-core'),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'prevent_empty' => false,
				'default'     => [
					[
						'moving_text'      => esc_html__( 'Design', 'firecore-elementor-core' ),
						'firecore_icons' => [
							'value'   => 'base-icon-avatar',
							'library' => 'firecore-flaticon',
						],
					],
				],
				'title_field' => '{{{ moving_text }}}',
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/


		/*===================================
		Start Title Style
		=====================================*/
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'firecore-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'selector' 	=> '{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-item',
			]
		);
		$this->add_control(
			'title_fill_color',
			[
				'label' 	=> esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-item' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'title_stroke_color',
			[
				'label' 	=> esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-item' => '-webkit-text-stroke-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'title_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-item' => '-webkit-text-stroke-width: {{VALUE}}px;'
				],
			]
		);
		$this->add_responsive_control(
			'title_animated_object_duration',
			[
				'label' => esc_html__( 'Animation Duration', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 's' ],
				'range' => [
					's' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list' => 'animation-duration: {{SIZE}}s;',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Title Style
		=====================================*/



		/*===================================
		Start Icon Style
		=====================================*/
		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => esc_html__( 'Icon', 'firecore-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'icon_typography',
				'selector' 	=> '{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-icon',
			]
		);
		$this->add_control(
			'icon_fill_color',
			[
				'label' 	=> esc_html__( 'Fill Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'icon_stroke_color',
			[
				'label' 	=> esc_html__( 'Stroke Color', 'firecore-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-icon' => '-webkit-text-stroke-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'icon_stroke_width',
			[
				'label'     => esc_html__( 'Stroke Width', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-icon' => '-webkit-text-stroke-width: {{VALUE}}px;'
				],
			]
		);
		$this->add_responsive_control(
			'icon_animated_object_duration',
			[
				'label' => esc_html__( 'Animation Duration', 'firecore-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 's' ],
				'range' => [
					's' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-icon' => 'animation-duration: {{SIZE}}s;',
				],
			]
		);

		$this->add_responsive_control(
			'icon_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'firecore-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .moving-text-block .moving-text-wrap .moving-text-list .moving-text-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Icon Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<section class="moving-text-block">
			<div class="moving-text-wrap <?php echo esc_attr( $settings['moving_direction'] ); ?>">

				<?php for ( $i = 0; $i < 2; $i++ ) : ?>
					<div class="moving-text-list" <?php echo $i === 1 ? 'aria-hidden="true"' : ''; ?>>
						<?php
						if ( ! empty( $settings['moving_text_block'] ) && is_array( $settings['moving_text_block'] ) ) :
							foreach ( $settings['moving_text_block'] as $item ) :

								$moving_text_icon_type = ! empty( $item['moving_text_icon_type'] ) ? $item['moving_text_icon_type'] : '';

								// Handle image source safely
								$firecore_image_icons_url = '';
								if ( ! empty( $item['firecore_image_icons']['id'] ) ) {
									$firecore_image_icons_url = Group_Control_Image_Size::get_attachment_image_src(
										$item['firecore_image_icons']['id'],
										'moving_text_image',
										$settings
									);
								} elseif ( ! empty( $item['firecore_image_icons']['url'] ) ) {
									$firecore_image_icons_url = esc_url( $item['firecore_image_icons']['url'] );
								}

								if ( empty( $firecore_image_icons_url ) ) {
									$firecore_image_icons_url = \Elementor\Utils::get_placeholder_image_src();
								}

								// Moving text
								if ( ! empty( $item['moving_text'] ) ) :
									?>
									<div class="moving-text-item"><?php echo esc_html( $item['moving_text'] ); ?></div>
									<?php
								endif;

								// Icon / image type switch
								switch ( $moving_text_icon_type ) {
									case 'flat_icon':
										if ( ! empty( $item['firecore_icons']['value'] ) ) :
											?>
											<span class="moving-text-icon <?php echo esc_attr( $item['firecore_icons']['value'] ); ?>"></span>
											<?php
										endif;
										break;

									case 'image_icon':
										?>
										<div class="moving-text-image-icon">
											<img src="<?php echo esc_url( $firecore_image_icons_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
										</div>
										<?php
										break;
								}

							endforeach;
						endif;
						?>
					</div>
				<?php endfor; ?>

			</div>
		</section>

		<?php
		}
	}
