<?php
// namespace Elementor;
namespace FirecoreElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class FIRECORE_Pricing_Switcher extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-pricing-switcher';
	}

	public function get_title() {
		return esc_html__( 'Pricing Switcher', 'firecore-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'firecore-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'firecore-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_responsive_control(
			'btn_align',
			[
				'label' => __('Search alignments', 'firecore-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'firecore-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .search-toggler  ' => 'justify-content: {{VALUE}}!important;',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/

		/*===================================
		Start Search Style
		=====================================*/
		$this->start_controls_section(
			'search_toggler_style',
			[
				'label' 	=> esc_html__( 'Search Styles', 'firecore-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'search_toggler_typography',
				'selector' => '{{WRAPPER}} .search-toggler',
			]
		);
		$this->add_responsive_control(
			'search_toggler_normal_margin',
			[
				'label'      => esc_html__( 'Search Margin', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .search-toggler' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'search_toggler_normal_padding',
			[
				'label'      => esc_html__( 'Search Padding', 'firecore-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .search-toggler' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .search-toggler',
			]
		);
		$this->start_controls_tabs( 'theme-search_toggler-tabs' );
		$this->start_controls_tab(
			'search_toggler_normal',
			[
				'label' => esc_html__( 'Normal', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'search_toggler_normal_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .search-toggler' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'search_toggler_normal_bg_color',
			[
				'label'     => esc_html__( 'Bg Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .search-toggler' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		//======== Hover Tabs ==========//
		$this->start_controls_tab(
			'search_toggler_hover',
			[
				'label' => esc_html__( 'Hover', 'firecore-elementor-core' ),
			]
		);
		$this->add_control(
			'search_toggler_hover_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .search-toggler:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'search_toggler_hover_bg_color',
			[
				'label'     => esc_html__( 'Bg Color', 'firecore-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .search-toggler:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();


	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

    <div class="pricing-switcher">
			<div class="toggle-btn d-flex align-items-center">
				<p class="mrb-0">Annually</p>
				<label class="switch">
					<input type="checkbox" id="checboxv"/>
					<span class="slider round"></span>
				</label>
				<p class="mrb-0">Monthly</p>
			</div>
		</div>

		<?php
	}

}
