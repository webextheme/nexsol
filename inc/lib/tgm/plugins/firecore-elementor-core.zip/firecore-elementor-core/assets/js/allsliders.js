(function ($) {
  "use strict";

  /**
   * Initialize Owl Carousel sliders (ThemeForest Safe)
   */
  const allSliders = () => {
    const $carousels = $(".webex-carousel");

    if (!$carousels.length) return;

    $carousels.each(function () {
      const $slider = $(this);
      const opts = $slider.data("options") || {};

      // Destroy if already initialized
      if ($slider.hasClass("owl-loaded")) {
        $slider.trigger("destroy.owl.carousel");
        $slider.removeClass("owl-loaded");
        $slider.find(".owl-stage-outer").children().unwrap();
      }

      /**
       * IMPORTANT:
       * Wait for images to load before initializing Owl
       * (Fixes reload layout break issue)
       */
      $slider.imagesLoaded(function () {
        $slider.owlCarousel({
          autoWidth: opts.autoWidth || false,
          margin: opts.margin || 0,
          items: opts.items || 4,
          loop: !!opts.loop,
          autoplay: !!opts.autoplay,
          autoplayTimeout: opts.autoplayTimeout || 5000,
          center: !!opts.center,
          nav: !!opts.nav,
          dots: !!opts.dots,
          thumbs: !!opts.thumbs,
          slideBy: opts.slideBy || 1,
          smartSpeed: 800,
          rtl: !!opts.rtl,
          navText: [
            '<i class="webexbase-icon-left-arrow1" aria-hidden="true"></i>',
            '<i class="webexbase-icon-next" aria-hidden="true"></i>'
          ],
          responsive: {
            0: {
              items: opts.items_xs ?? opts.items
            },
            425: {
              items: opts.items_sm ?? opts.items
            },
            768: {
              items: opts.items_md ?? opts.items
            },
            1024: {
              items: opts.items_lg ?? opts.items
            },
            1200: {
              items: opts.items_xl ?? opts.items
            },
            1366: {
              items: opts.items_xxl ?? opts.items
            },
            1440: {
              items: opts.items
            }
          }
        });

        /**
         * Extra safety refresh after init
         * (Elementor async render fix)
         */
        setTimeout(function () {
          $slider.trigger("refresh.owl.carousel");
        }, 100);
      });
    });
  };

  /**
   * Elementor Hook Initialization
   */
  const initElementor = () => {
    const widgets = [
      "products-block",
      "testimonial-block",
      "team-block-members",
      "gallery-block",
      "services-block",
      "projects-block",
      "webex-news-posts",
      "webex-clients",
      "webex-award-box",
      "webex-feature-box"
    ];

    widgets.forEach((widget) => {
      elementorFrontend.hooks.addAction(
        `frontend/element_ready/${widget}.default`,
        allSliders
      );
    });
  };

  /**
   * Elementor Frontend Init
   */
  $(window).on("elementor/frontend/init", initElementor);

})(jQuery);
