(function($){
  "use strict";

  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-funfact-counter.default', function () {

      if ($('.count-box').length) {
        $('.count-box').appear(function() {
          var $t = $(this),
          n = $t.find(".counting-number").attr("data-stop"),
          r = parseInt($t.find(".counting-number").attr("data-speed"), 10);
          if (!$t.hasClass("counted")) {
            $t.addClass("counted");
            $({
              countNum: $t.find(".counting-number").text()
            }).animate({
              countNum: n
            }, {
              duration: r,
              easing: "linear",
              step: function() {
                $t.find(".counting-number").text(Math.floor(this.countNum));
              },
              complete: function() {
                $t.find(".counting-number").text(this.countNum);
              }
            });
          }
        }, {
          accY: 0
        });
      }

    });
  });


  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-skill.default', function () {

      if ($('.count-box2').length) {
        $('.count-box2').appear(function() {
          var $t = $(this),
          n = $t.find(".counting-number").attr("data-stop"),
          r = parseInt($t.find(".counting-number").attr("data-speed"), 10);
          if (!$t.hasClass("counted")) {
            $t.addClass("counted");
            $({
              countNum: $t.find(".counting-number").text()
            }).animate({
              countNum: n
            }, {
              duration: r,
              easing: "linear",
              step: function() {
                $t.find(".counting-number").text(Math.floor(this.countNum));
              },
              complete: function() {
                $t.find(".counting-number").text(this.countNum);
              }
            });
          }
        }, {
          accY: 0
        });
      }
      /*========== [_Progress_line] ============*/
      if ($('.progress-line').length) {
        $('.progress-line').appear(function() {
          var el = $(this);
          var percent = el.data('width');
          $(el).css('width', percent + '%');
        }, {
          accY: 0
        });
      }
    });
  });

  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-before-after-slider.default', function () {
      $(function(){
        $(".before-after-slider1").twentytwenty({
          default_offset_pct: 0.5, // How much of the before image is visible when the page loads
          orientation: 'horizontal', // Orientation of the before and after images ('horizontal' or 'vertical')
          no_overlay: false, //Do not show the overlay with before and after
          move_slider_on_hover: false, // Move slider on mouse hover?
          move_with_handle_only: true, // Allow a user to swipe anywhere on the image to control slider movement.
          click_to_move: true // Allow a user to click (or tap) anywhere on the image to move the slider to that location.
        });
      });
    });
  });

  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-contact-form.default', function () {
      /*========= [_Nice_select] =========*/
      $('select').niceSelect();
    });
  });

  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-modern-feature.default', function () {
      /*========= [modern-features-block-style1] =========*/
      var $items = $('.modern-features-block-style1 .modern-feature-inner');
      // Set the second item active by default if it exists
      if ($items.length > 0) {
        $items.eq(0).addClass('active');
      } else {
        $items.first().addClass('active'); // Fallback if only one item exists
      }
      $items.click(function () {
        $items.removeClass('active'); // Remove active from all
        $(this).addClass('active'); // Add active to hovered item
      });
    });
  });

   $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-modern-service.default', function () {
      /*========= [modern-services-block-style_1] =========*/
      var $items = $('.modern-services-block-style-1');
      // Set the second item active by default if it exists
      if ($items.length > 1) {
        $items.eq(1).addClass('active');
      } else {
        $items.first().addClass('active'); // Fallback if only one item exists
      }
      $items.hover(function () {
        $items.removeClass('active'); // Remove active from all
        $(this).addClass('active'); // Add active to hovered item
      });
    });
  });

  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-feature-box.default', function () {

      /*========= [feature-box-block-style_3] =========*/
      var $items = $('.feature-box-block-style_3 .feature-box-inner');
      // Set the second item active by default if it exists
      if ($items.length > 1) {
        $items.eq(1).addClass('active');
      } else {
        $items.first().addClass('active'); // Fallback if only one item exists
      }
      $items.hover(function () {
        $items.removeClass('active'); // Remove active from all
        $(this).addClass('active'); // Add active to hovered item
      });

    });
  });


  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-modern-team-members.default', function () {
      /*========= [modern-team-block-style1] =========*/
      const cards = document.querySelectorAll('.modern-team-block-style1');
      if (cards.length > 0) {
        cards.forEach((c, i) => {
          if (i === 0) { // 2nd card (index starts from 0)
            c.classList.add('active');
            gsap.set(c, { flex: 4 }); // active size
          } else {
            gsap.set(c, { flex: 1 }); // inactive size
          }
        });
      }

      cards.forEach((card) => {
        card.addEventListener('click', () => {
          cards.forEach(c => {
            if (c !== card) {
              c.classList.remove('active');
              gsap.to(c, { flex: 1, duration: 0.1 });
            }
          });

          const isActive = card.classList.contains('active');
          if (!isActive) {
            card.classList.add('active');
            gsap.to(card, { flex: 4, duration: 0.1 });
          }
        });
      });
    });
  });


  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-modern-project.default', function () {
      /*========= [modern-projects-block-style1] =========*/
      const cards = document.querySelectorAll('.modern-projects-block-style1');
      if (cards.length > 0) {
        cards.forEach((c, i) => {
          if (i === 0) { // 2nd card (index starts from 0)
            c.classList.add('active');
            gsap.set(c, { flex: 5 }); // active size
          } else {
            gsap.set(c, { flex: 1 }); // inactive size
          }
        });
      }

      cards.forEach((card) => {
        card.addEventListener('click', () => {
          cards.forEach(c => {
            if (c !== card) {
              c.classList.remove('active');
              gsap.to(c, { flex: 1, duration: 0.1 });
            }
          });

          const isActive = card.classList.contains('active');
          if (!isActive) {
            card.classList.add('active');
            gsap.to(card, { flex: 5, duration: 0.1 });
          }
        });
      });
    });
  });


  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-accordion.default', function () {
      /*========= [_Accordion] =========*/
      $('.accordion-header').on('click', function(e) {
        var element = $(this).parent('.accordion-item');
        if (element.hasClass('active')) {
          element.removeClass('active');
          element.find('.accordion-body').removeClass('active');
          element.find('.accordion-body').slideUp(300, "swing");
        } else {
          element.addClass('active');
          element.children('.accordion-body').slideDown(300, "swing");
          element.siblings('.accordion-item').children('.accordion-body').slideUp(300, "swing");
          element.siblings('.accordion-item').removeClass('active');
          element.siblings('.accordion-item').find('.accordion-header').removeClass('active');
          element.siblings('.accordion-item').find('.accordion-body').slideUp(300, "swing");
        }
      });
    });
  });

})(jQuery);