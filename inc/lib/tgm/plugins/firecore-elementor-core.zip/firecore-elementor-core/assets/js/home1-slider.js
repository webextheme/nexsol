(function($){
	"use strict";

  $(window).on('elementor/frontend/init',function(){
    elementorFrontend.hooks.addAction('frontend/element_ready/webex-home-banner.default', function () {

    $(".home_banner_01 .home-carousel").each(function(){
      var webex_home_slider 		= $(this) ;
      var webex_home_slider_fn = webex_home_slider.data('options') ? webex_home_slider.data('options') : {};

      webex_home_slider.owlCarousel({
        loop: webex_home_slider_fn.loop,
        autoplay: webex_home_slider_fn.autoplay,
        autoplayTimeout: webex_home_slider_fn.autoplayTimeout,
        nav: webex_home_slider_fn.nav,
        dots: false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        smartSpeed: 1000,
        rtl: webex_home_slider_fn.rtl,
        navText: ["<i class='webexbase-icon-left-arrow-11'></i>", "<i class='webexbase-icon-right-arrow-angle'></i>"],
        responsive : {
          0: {
            items: 1
          },
          425: {
            items: 1
          },
          768: {
            items: 1
          },
          1024: {
            items: 1
          },
          1440: {
            items: 1
          }
        }
      });

      webex_home_slider.find(".owl-nav button.owl-prev").attr("title", "Previous");
      webex_home_slider.find(".owl-nav button.owl-next").attr("title", "Next");
      webex_home_slider.find(".owl-dots button").attr("title", "Dots");

    });

    });
  });

})(jQuery);