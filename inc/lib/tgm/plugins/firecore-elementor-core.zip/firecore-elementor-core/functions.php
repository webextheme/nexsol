<?php

/**
 *
 * @package firecore
 */
if (!defined('ABSPATH')) {
  exit(); //exit if access directly
}
//Elementor Widgets Folder Path
if (!function_exists('firecore_get_template')) :
  function firecore_get_template($template_name = null)
  {
		$template_path = apply_filters('firecore-elementor/template-path', 'elementor-templates/');
		$template = locate_template($template_path . $template_name);
		if (!$template) {
			$template = FIRECORE_PLUGIN_DIR  . '/widgets/widget-parts/' . $template_name;
		}
		if (file_exists($template)) {
			return $template;
		} else {
			return false;
		}
  }
endif;

//Elementor Modern Widgets Folder Path
if (!function_exists('firecore_get_template2')) :
  function firecore_get_template2($template_name2 = null)
  {
		$template_path2 = apply_filters('firecore-elementor/template-path', 'elementor-templates/');
		$template2 = locate_template($template_path2 . $template_name2);
		if (!$template2) {
			$template2 = FIRECORE_PLUGIN_DIR  . '/modern-widgets/widget-parts/' . $template_name2;
		}
		if (file_exists($template2)) {
			return $template2;
		} else {
			return false;
		}
  }
endif;


// ============================
// Elementro Carousel Options
// ============================
if (!function_exists('webex_get_elementor_carousel_options')):
	function webex_get_elementor_carousel_options($arg) {
		/* ===== Begin Carousel Options ===== */
		$arg->start_controls_section(
			'section_additional_options',
			[
				'label'     => esc_html__( 'Carousel Options', 'firecore-elementor-core' ),
				'condition' => [
					'layout' => 'slider',
				],
			]
		);
		$arg->add_control(
			'margin_items',
			[
				'label'   => esc_html__( 'Item Gap', 'firecore-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 30,
				'separator' => 'after',
			]
		);
		$arg->add_control(
			'responsive_heading',
			[
					'label' => esc_html__( 'Responsive', 'firecore-elementor-core' ),
					'type'  => \Elementor\Controls_Manager::HEADING,
			]
		);
		$arg->add_control(
			'items_xxl',
			[
				'label'     => __('Responsive Items for (Up to 1366px)', 'firecore-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 4,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8),
				'separator' => 'before',
			]
		);
		$arg->add_control(
			'items_xl',
			[
				'label'     => __('Responsive Items for  (Up to 1200px)', 'firecore-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 3,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8),
				'separator' => 'before',
			]
		);
		$arg->add_control(
			'items_lg',
			[
				'label'     => __('Responsive Items for (Up to 1024px)', 'firecore-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 3,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8),
				'separator' => 'before',
			]
		);
		$arg->add_control(
			'items_md',
			[
				'label'     => __('Responsive Items for (Up to 768px)', 'firecore-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 2,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8)
			]
		);
		$arg->add_control(
			'items_sm',
			[
				'label'     => __('Responsive Items for (Up to 425px)', 'firecore-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 1,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8)
			]
		);
		$arg->add_control(
			'items_xs',
			[
				'label'     => __('Responsive Items for Extra Small Screen', 'firecore-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 1,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8),
				'separator' => 'after',
			]
		);
		$arg->add_control(
			'slider_controlling',
			[
					'label' => esc_html__( 'Slider Controlling', 'firecore-elementor-core' ),
					'type'  => \Elementor\Controls_Manager::HEADING,
			]
		);
		$arg->add_control(
			'infinite',
			[
				'label'   => esc_html__( 'Infinite Loop', 'firecore-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => esc_html__( 'Yes', 'firecore-elementor-core' ),
					'no'  => esc_html__( 'No', 'firecore-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'center_mode',
			[
				'label'   => esc_html__( 'Center Mode', 'firecore-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'firecore-elementor-core' ),
					'no'  => esc_html__( 'No', 'firecore-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'autoplay',
			[
				'label'   => esc_html__( 'Autoplay', 'firecore-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => esc_html__( 'Yes', 'firecore-elementor-core' ),
					'no'  => esc_html__( 'No', 'firecore-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__( 'Autoplay Speed', 'firecore-elementor-core' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 8000,
				'condition' => [
					'autoplay' => 'yes',
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'nav_control',
			[
				'label'   => esc_html__( 'Show Nav', 'firecore-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'firecore-elementor-core' ),
					'no'  => esc_html__( 'No', 'firecore-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'dot_control',
			[
				'label'   => esc_html__( 'Show Dots', 'firecore-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'firecore-elementor-core' ),
					'no'  => esc_html__( 'No', 'firecore-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->end_controls_section();
		/* ===== End Carousel Options ===== */




		/* ===== Begin Dots Style ===== */
		$arg->start_controls_section('dots_style', [
			'label' => esc_html__('Carousel Dots Style', 'firecore-elementor-core'),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			'condition' => [
				'dot_control' => 'yes',
				'layout' => 'slider',
			],
		]);
		$arg->add_responsive_control(
			'dots_move_up_down',
			[
				'label' => esc_html__( 'Dots Move Up Down', 'firecore-elementor-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$arg->add_responsive_control(
			'dots_alignment',
			[
				'label'       => esc_html__( 'Dots Alignment', 'firecore-elementor-core' ),
				'type'        => \Elementor\Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'firecore-elementor-core' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'firecore-elementor-core' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'firecore-elementor-core' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'     => 'center',
				'toggle'      => false,
				'selectors' => [
					'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots ' => 'justify-content: {{VALUE}};',
				],
			]
		);
		$arg->start_controls_tabs('tabs_dots_style');

		$arg->start_controls_tab('tab_dots_normal', [
			'label' => esc_html__('Normal', 'firecore-elementor-core'),
		]);
		$arg->add_control('dot_color', [
			'label' => esc_html__('Background Color', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->add_responsive_control('dots_width', [
			'label' => esc_html__('Width', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_responsive_control('dots_height', [
			'label' => esc_html__('Height', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_control('dots_border_radius', [
			'label' => esc_html__('Border Radius', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);
		$arg->end_controls_tab();

		$arg->start_controls_tab('tab_dots_active', [
			'label' => esc_html__('Active', 'firecore-elementor-core'),
		]);
		$arg->add_control('dot_color_active', [
			'label' => esc_html__('Background Color', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->add_responsive_control('dots_width_active', [
			'label' => esc_html__('Width', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_responsive_control('dots_height_active', [
			'label' => esc_html__('Height', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_control('dots_border_radius_active', [
			'label' => esc_html__('Border Radius', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);
		$arg->end_controls_tab();
		$arg->end_controls_tabs();
		$arg->end_controls_section();
		/* ===== End Dots Style ===== */





		/* ===== Begin Nav Style ===== */
		$arg->start_controls_section('nav_style', [
			'label' => esc_html__('Carousel Nav Style', 'firecore-elementor-core'),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			'condition' => [
				'nav_control' => 'yes',
				'layout' => 'slider',
			],
		]);
		$arg->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' 		=> 'nav_icon_typography',
				'selector' 	=> '{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button i',
			]
		);
		$arg->add_responsive_control('nav_width', [
			'label' => esc_html__('Width', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-next' =>
					'width: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-prev' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_responsive_control('nav_height', [
			'label' => esc_html__('Height', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-next' =>
					'height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-prev' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->start_controls_tabs('tabs_nav_style');
		$arg->start_controls_tab('tab_nav_normal', [
			'label' => esc_html__('Normal', 'firecore-elementor-core'),
		]);
		$arg->add_control('nav_color_normal', [
			'label' => esc_html__('Color', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button i' =>
					'color: {{VALUE}}',
			],
		]);
		$arg->add_control('nav_bgcolor_normal', [
			'label' => esc_html__('Background Color', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-next, {{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-prev' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->end_controls_tab();

		$arg->start_controls_tab('tab_nav_hover', [
			'label' => esc_html__('Hover', 'firecore-elementor-core'),
		]);
		$arg->add_control('nav_color_hover', [
			'label' => esc_html__('Color', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button:hover i' =>
					'color: {{VALUE}}',
			],
		]);
		$arg->add_control('nav_bgcolor_hover', [
			'label' => esc_html__('Background Color', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-next:hover, {{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button.owl-prev:hover' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->end_controls_tab();
		$arg->end_controls_tabs();
		$arg->add_control('nav_border_radius', [
			'label' => esc_html__('Border Radius', 'firecore-elementor-core'),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%'],
			'selectors' => [
				'{{WRAPPER}} .firecore-slider-wrapper .webex-carousel .owl-nav button' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);
		$arg->end_controls_section();
		/* ===== End Nav Style ===== */


	}
endif;

function firecore_select_posts($post_type = 'post')
{
  $args = [
    'post_type' => $post_type,
    'numberposts' => -1,
    'orderby' => 'title',
    'order' => 'ASC',
  ];
  $query_query = get_posts($args);
  $posts = [];
  if ($query_query) {
    foreach ($query_query as $query) {
      $posts[$query->ID] = $query->post_title;
    }
  }
  return $posts;
}

function firecore_select_category($category = 'category'){
	$terms = get_terms( array(
		'taxonomy' => $category,
		'hide_empty' => true,
	));
	$options = [];
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		foreach ( $terms as $term ) {
			$options[ $term->slug ] = $term->name;
		}
	}
	return $options;
}

function get_thumbnail_size(){
	global $_wp_additional_image_sizes;
	$results = array(
			'full'      => 'full',
			'large'     => 'large',
			'medium'    => 'medium',
			'thumbnail' => 'thumbnail'
	);
	foreach ($_wp_additional_image_sizes as $key => $size) {
			$results[$key] = $key;
	}
	return $results;
}

// Custom Elementor Motion Animation
if ( ! function_exists( 'firecore_ele_theme_animations' ) ) {
  add_filter( 'elementor/controls/animations/additional_animations', 'firecore_ele_theme_animations' );
  function firecore_ele_theme_animations( $ele_theme_animations ) {
    $ele_theme_animations = array_merge(
      $ele_theme_animations,
      array(
        esc_html__( 'Firecore Animations', 'firecore-elementor-core' ) => array(
          'webex_fadeinup'        => esc_html__( 'Fade In Up', 'firecore-elementor-core' ),
          'webex_fadeinright'     => esc_html__( 'Fade In Right', 'firecore-elementor-core' ),
          'webex_fadeinleft'      => esc_html__( 'Fade In Left', 'firecore-elementor-core' ),
          'webex_fadeindown'      => esc_html__( 'Fade In Down', 'firecore-elementor-core' ),
          'webex_fadein'          => esc_html__( 'Fade In', 'firecore-elementor-core' ),
          'webex_popup'           => esc_html__( 'Pop Up', 'firecore-elementor-core' ),
          'webex_infiniterotate'  => esc_html__( 'Infinite Rotate', 'firecore-elementor-core' ),
        ),
      )
    );
    return $ele_theme_animations;
  }
}

// Custom Widgets Appear Animations
if ( ! function_exists( 'webextheme_firecore_widget_animations' ) ) {
  function webextheme_firecore_widget_animations() {
    $firecore_widget_animations = array(
      ''                    => esc_html__( 'None', 'firecore-elementor-core' ),
      'wow webex_fadeinup'      => esc_html__( 'Fade In Up', 'firecore-elementor-core' ),
      'wow webex_fadeinright'   => esc_html__( 'Fade In Right', 'firecore-elementor-core' ),
      'wow webex_fadeinleft'    => esc_html__( 'Fade In Left', 'firecore-elementor-core' ),
      'wow webex_fadeindown'    => esc_html__( 'Fade In Down', 'firecore-elementor-core' ),
      'wow webex_fadein'        => esc_html__( 'Fade In', 'firecore-elementor-core' ),
      'wow webex_popup'         => esc_html__( 'Pop Up', 'firecore-elementor-core' ),
      'wow webex_infiniterotate'=> esc_html__( 'Infinite Rotate', 'firecore-elementor-core' ),
    );
    return $firecore_widget_animations;
  }
}