<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;

class DESKLY_Modern_Services extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-modern-service';
	}

	public function get_title() {
		return esc_html__( 'Modern Services', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Modern Services Content ===== */
		$this->start_controls_section(
			'section_content_modern_services',
			[
				'label' => esc_html__( 'Modern Services', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_styles',
			[
				'label' => __( 'Modern Services Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'deskly-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'modern_services_image',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'modern_services_image',
			[
				'label' 	=> esc_html__( 'Thumbnail Image', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'modern_services_icon_type',
			[
				'label' => __( 'Icon Type', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'image_icon' => esc_html__( 'Image Icon', 'deskly-elementor-core' ),
					'flat_icon' => esc_html__( 'Flat Icon', 'deskly-elementor-core' ),
				],
				'default' => 'flat_icon'
			]
		);
		$repeater->add_control(
			'deskly_icons',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'webexbase-icon-up-right-arrow',
					'library' 	=> 'deskly_base_icon',
				],
				'condition' => [
					'modern_services_icon_type' => 'flat_icon',
				]
			]
		);
		$repeater->add_control(
			'deskly_image_icons',
			[
				'label' => esc_html__( 'Image Icon', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'modern_services_icon_type' => 'image_icon',
				]
			]
		);
		$repeater->add_control(
			'counting',
			[
				'label'       => esc_html__( 'Counting Number', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( '01', 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Title', 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 		=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 		=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'		=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 		=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 		=> esc_html__('h6', 'deskly-elementor-core'),
					'span' 	=> esc_html__('span', 'deskly-elementor-core'),
					'p' 		=> esc_html__('p', 'deskly-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'title_link',
			[
				'label' => esc_html__( "Title Link URL", 'deskly-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
				]
			]
		);
		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Description', 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'list_content',
			[
				'label' => esc_html__( "List Content", 'deskly-elementor-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => esc_html__( "Lorem ipsum dolor sit amet", 'deskly-elementor-core' ),
			]
		);
		$repeater->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Text Button', 'deskly-elementor-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Read more ', 'deskly-elementor-core' ),
			],
		);
		$repeater->add_control(
			'button_link',
			[
				'label' => esc_html__( "Button Link URL", 'deskly-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '#',
				]
			]
		);
		$this->add_control(
			'modern_services_items',
			[
				'label'       => esc_html__( 'Items', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'      => esc_html__( 'Title Place Here', 'deskly-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'deskly-elementor-core' ),
						'counting' => esc_html__( '01', 'deskly-elementor-core' ),
						'modern_services_image'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'title'      => esc_html__( 'Title Place Here', 'deskly-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'deskly-elementor-core' ),
						'counting' => esc_html__( '02', 'deskly-elementor-core' ),
						'modern_services_image'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'title'      => esc_html__( 'Title Place Here', 'deskly-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'deskly-elementor-core' ),
						'counting' => esc_html__( '03', 'deskly-elementor-core' ),
						'modern_services_image'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'title'      => esc_html__( 'Title Place Here', 'deskly-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'deskly-elementor-core' ),
						'counting' => esc_html__( '04', 'deskly-elementor-core' ),
						'modern_services_image'     => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		$this->end_controls_section();
		/* ===== End Team Items Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'modern_services_content_style',
			[
				'label' => esc_html__( 'Content Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'modern_services_content_item_margin',
			[
				'label'      => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .modern-services-block .services_wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_content_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .modern-services-block .services_wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */





		/* ===== Begin Icons Style ===== */
		$this->start_controls_section(
			'modern_services_icons_styling',
			[
				'label' => esc_html__( 'Icons Styling', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'modern_services_icons_size',
			[
				'label'      => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .modern-services-block .services_icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'modern_services_icons_typography',
				'label' => esc_html__( 'Typography', 'deskly-elementor-core' ),
				'selector' => '{{WRAPPER}} .modern-services-block .services_icon',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'modern_services_icons_border',
				'selector' => '{{WRAPPER}} .modern-services-block .services_icon',
			]
		);
		$this->add_responsive_control(
			'modern_services_icons_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}}.modern-services-block .services_icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'modern_services_icons_tab' );

		$this->start_controls_tab(
			'modern_services_icons_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_icons_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block .services_icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'modern_services_icons_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block .services_icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'modern_services_icons_item_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);

		$this->add_control(
			'modern_services_icons_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block:hover .services_icon ' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'modern_services_icons_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block:hover .services_icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Icons Style ===== */






		/* ===== Begin Counting Style ===== */
		$this->start_controls_section(
			'modern_services_counting_styling',
			[
				'label' => esc_html__( 'Counting Styling', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'modern_services_counting_size',
			[
				'label'      => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .modern-services-block .service_count' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'modern_services_counting_typography',
				'label' => esc_html__( 'Typography', 'deskly-elementor-core' ),
				'selector' => '{{WRAPPER}} .modern-services-block .service_count',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'modern_services_counting_border',
				'selector' => '{{WRAPPER}} .modern-services-block .service_count',
			]
		);
		$this->add_responsive_control(
			'modern_services_counting_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .service_count' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_counting_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .working_count' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_counting_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .service_count' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'modern_services_counting_tab' );

		$this->start_controls_tab(
			'modern_services_counting_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_counting_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block .service_count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'modern_services_counting_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block .service_count' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'modern_services_counting_item_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);

		$this->add_control(
			'modern_services_counting_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block:hover .service_count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'modern_services_counting_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block:hover .service_count' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Icons Style ===== */




		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'modern_services_title_style',
			[
				'label' => esc_html__( 'Title Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'modern_services_title_tabs' );
		$this->start_controls_tab(
			'modern_services_title_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block .modern-services-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'modern_services_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .modern-services-block .modern-services-title',
			]
		);
		$this->add_responsive_control(
			'modern_services_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .modern-services-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .modern-services-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'modern_services_title_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block .modern-services-title:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'modern_services_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .modern-services-block .modern-services-title:hover',
			]
		);
		$this->add_responsive_control(
			'modern_services_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .modern-services-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .modern-services-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'modern_services_title_active',
			[
				'label' => esc_html__( 'Active', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_title_active_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-block .modern-services-inner.active .modern-services-title' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'modern_services_title_active_typography',
				'selector' 	=> '{{WRAPPER}} .modern-services-block .modern-services-inner.active .modern-services-title',
			]
		);
		$this->add_responsive_control(
			'modern_services_title_active_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .modern-services-inner.active .modern-services-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_title_active_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-block .modern-services-inner.active .modern-services-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Description Style ===== */
		$this->start_controls_section(
			'modern_services_description_style',
			[
				'label' => esc_html__( 'Description Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'modern_services_description_tabs' );
		$this->start_controls_tab(
			'modern_services_description_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_description_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-services-description' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'modern_services_description_normal_typography',
				'selector' 	=> '{{WRAPPER}} .modern-services-description',
			]
		);
		$this->add_responsive_control(
			'modern_services_description_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_description_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-services-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'modern_services_description_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'modern_services_description_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .modern-service-block:hover .modern-services-description' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'modern_services_description_hover_typography',
				'selector' 	=> '{{WRAPPER}} .modern-service-block:hover .modern-services-description',
			]
		);
		$this->add_responsive_control(
			'modern_services_description_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-service-block:hover .modern-services-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'modern_services_description_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .modern-service-block:hover .modern-services-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Description Style ===== */
}

	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( empty( $settings['modern_services_items'] ) ) {
			return;
		}
		$this->add_render_attribute( 'wrapper', 'class', 'modern-services-wrapper' );
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<div id="modern-services-wrapper-<?php echo esc_attr( $settings['modern_services_styles'] ) ?>">
				<?php
					foreach ( $settings['modern_services_items'] as $index => $item ) {
						$this->render_single_item( $index, $item );
					}
				?>
			</div>
		</div>
		<?php
	}

	public function render_single_item( $index, $item ) {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');

		// Safe values
		$modern_services_icon_type          = ! empty( $item['modern_services_icon_type'] ) ? $item['modern_services_icon_type'] : '';
		$deskly_icons = ! empty( $item['deskly_icons']['value'] ) ? $item['deskly_icons']['value'] : '';
		$title          = ! empty( $item['title'] ) ? $item['title'] : '';
		$title_tag      = ! empty( $item['title_tag'] ) ? $item['title_tag'] : 'h4';
		$description    = ! empty( $item['description'] ) ? $item['description'] : '';
		$list_content   = ! empty( $item['list_content'] ) ? $item['list_content'] : '';
		$counting       = ! empty( $item['counting'] ) ? $item['counting'] : '';
		$button_text    = ! empty( $item['button_text'] ) ? $item['button_text'] : '';

		// Title link
		$custom_link = ! empty( $item['title_link'] ) ? $item['title_link'] : [];
		$url         = ! empty( $custom_link['url'] ) ? esc_url( $custom_link['url'] ) : '';
		$target      = ( ! empty( $custom_link['is_external'] ) ) ? ' target="_blank" rel="noopener noreferrer"' : '';

		// Button link
		$button_link = ! empty( $item['button_link'] ) ? $item['button_link'] : [];
		$btn_url     = ! empty( $button_link['url'] ) ? esc_url( $button_link['url'] ) : '';
		$btn_target  = ( ! empty( $button_link['is_external'] ) ) ? ' target="_blank" rel="noopener noreferrer"' : '';

		// Image handling
		if ( empty( $item['modern_services_image']['id'] && ! empty( $item['modern_services_image']['url'] ) ) ) {
			$modern_services_image_url = $item['modern_services_image']['url'];
		} else {
			$modern_services_image_url = Group_Control_Image_Size::get_attachment_image_src( $item['modern_services_image']['id'], 'modern_services_image', $settings );
		}

		// Image handling
		$deskly_image_icons_url = '';
		if ( ! empty( $item['deskly_image_icons']['id'] ) ) {
			// If ID exists → get resized Elementor image
			$deskly_image_icons_url = Group_Control_Image_Size::get_attachment_image_src(
				$item['deskly_image_icons']['id'],
				'modern_services_image',
				$settings
			);
		} elseif ( ! empty( $item['deskly_image_icons']['url'] ) ) {
			// If only URL exists → use it directly
			$deskly_image_icons_url = esc_url( $item['deskly_image_icons']['url'] );
		}

		// Fallback to Elementor placeholder if still empty
		if ( empty( $deskly_image_icons_url ) ) {
			$deskly_image_icons_url = \Elementor\Utils::get_placeholder_image_src();
		}

		switch ( $settings['modern_services_styles'] ) {
			case 'style_1':
				include deskly_get_template2( '/service-modern/style1.php' );
				break;
			case 'style_2':
				include deskly_get_template2( '/service-modern/style2.php' );
				break;
			case 'style_3':
				include deskly_get_template2( '/service-modern/style3.php' );
				break;
		}

	}
}
