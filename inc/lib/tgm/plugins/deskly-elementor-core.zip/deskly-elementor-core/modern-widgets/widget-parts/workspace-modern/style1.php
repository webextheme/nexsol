<?php
$workspace_number = get_post_meta( get_the_ID(), '_deskly_workspace_number', true );
?>

<div class="modern-workspace-block modern-workspace-block-style1">
  <div class="modern-workspace-inner">
    <div class="modern-workspace-left-part">
      <div class="title-part">
        <!-- Title -->
        <h4 class="modern-workspace-title"><?php echo esc_html( $the_title ) ?></h4>
        <div class="modern-workspace-count"><?php echo esc_html( $workspace_number );?></div>
      </div>
    </div>
    <div class="modern-workspace-content-part">
      <div class="modern-workspace-thumb">
        <?php echo get_the_post_thumbnail( $get_id, $settings['modern_workspace_image'] ) ?>
      </div>
      <div class="modern-workspace-details-area">
        <!-- Title -->
        <h3 class="modern-workspace-title"><?php echo esc_html( $the_title ) ?></h3>
        <!-- Excerpt -->
        <?php if( 'yes' == $settings['excerpt_show_hide'] ): ?>
          <?php if( has_excerpt() ): ?>
          <div class="modern-workspace-excerpt"><?php echo wp_trim_words( get_the_excerpt(), $excerpt_count, '' ); ?></div>
          <?php else: ?>
          <div class="modern-workspace-excerpt"><?php echo wp_trim_words( get_the_excerpt(), $excerpt_count, '' ); ?></div>
          <?php endif;?>
        <?php endif;?>

        <?php
        // ============================
        // GET WORKSPACE FEATURES META
        // ============================
        $features = get_post_meta( $get_id, '_deskly_workspace_features', true );
        if ( !empty($features) && is_array($features) ) :
        ?>
          <div class="workspace-features-list">

            <?php foreach ( $features as $item ) :
              $icon = $item['icon'] ?? '';
              $text = $item['text'] ?? '';
            ?>
            <div class="workspace-feature">
              <?php if ( !empty($icon) ) : ?>
                <span class="workspace-feature-icon">
                  <i class="<?php echo esc_attr( $icon ); ?>"></i>
                </span>
              <?php endif; ?>

              <?php if ( !empty($text) ) : ?>
                <span class="workspace-feature-text">
                  <?php echo esc_html( $text ); ?>
                </span>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>

            <?php if( 'yes' == $settings['link_btn_show_hide'] ): ?>
            <div class="theme_btn_block_style1">
              <a href="<?php echo esc_url( get_the_permalink() ) ?>" class="btn_style1"><?php echo esc_html($settings['button_text']);?></a>
            </div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>