<div class="modern-services-block modern-services-block-style3">
  <div class="services_item deskly-hover-reveal-item2">
    <div class="services_wrap">
      <div class="services_title_area">
        <?php
          switch ( $modern_services_icon_type ) {
            case 'flat_icon':
              if ( !empty($deskly_icons) ): ?>
              <div class="services_icon">
                <i class="<?php echo esc_attr( $deskly_icons ); ?>"></i>
              </div>
              <?php endif;
              break;

            case 'image_icon':?>
              <div class="modern-services-image-icon">
                <img src="<?php echo esc_url( $deskly_image_icons_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
              </div>
              <?php
          }
        ?>
        <!-- Title -->
        <?php if( !empty( $title ) ) : ?>
        <?php echo '<'. esc_attr( $title_tag ) .' class="modern-services-title">'; ?>
          <?php if( !empty( $url ) ): ?>
          <a
            <?php echo $target;?>
            href="<?php echo esc_url( $url );?>">
            <?php echo wp_kses($title , $allowed_tags) ?>
          </a>
          <?php else: ?>
            <?php echo wp_kses($title , $allowed_tags) ?>
          <?php endif ?>
        <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
        <?php endif; ?>
      </div>
      <div class="modern_services_content">
        <!-- Description -->
        <?php if( !empty( $description ) ) : ?>
        <p class="modern-services-description description"><?php echo esc_html( $description ) ?></p>
        <?php endif; ?>
        <!-- List Content -->
        <?php if( !empty( $list_content ) ) : ?>
        <div class="list-content">
          <?php echo wp_kses($list_content , $allowed_tags) ?>
        </div>
        <?php endif; ?>
      </div>
      <a class="services_link" href="<?php echo esc_url( $btn_url );?>"><i class="webexbase-icon-up-right-arrow-1"></i></a>
    </div>
    <div class="deskly-hover-reveal-bg" data-background="<?php echo esc_url( $modern_services_image_url ); ?>"></div>
  </div>
</div>