<div class="modern-services-block modern-services-block-style1">
  <div class="modern-services-icon">
    <!-- Icon -->
    <?php if ( !empty($deskly_icons) ): ?>
      <div class="icon">
        <i class="<?php echo esc_attr( $deskly_icons ); ?>"></i>
      </div>
    <?php endif; ?>
  </div>

  <!-- Title -->
  <?php if( !empty( $title ) ) : ?>
  <?php echo '<'. esc_attr( $title_tag ) .' class="modern-services-title">'; ?>
    <?php if( !empty( $url ) ): ?>
    <a
      <?php echo $target;?>
      href="<?php echo esc_url( $url );?>">
      <?php echo wp_kses($title , $allowed_tags) ?>
    </a>
    <?php else: ?>
      <?php echo wp_kses($title , $allowed_tags) ?>
    <?php endif ?>
  <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
  <?php endif; ?>
  <div class="modern-services-thumb">
    <img src="<?php echo esc_url( $modern_services_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
  </div>
  <!-- Description -->
  <?php if( !empty( $description ) ) : ?>
  <p class="modern-services-description"><?php echo esc_html( $description ) ?></p>
  <?php endif; ?>
</div>