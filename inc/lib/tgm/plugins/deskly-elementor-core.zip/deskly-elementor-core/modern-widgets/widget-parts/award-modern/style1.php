<div class="modern-award-block modern-award-block-style1">
  <div class="award_item deskly-hover-reveal-item">
    <div class="award_content">
      <!-- Award Name -->
      <?php if( !empty( $award_name ) ) : ?>
      <?php echo '<'. esc_attr( $award_name_tag ) .' class="award_name">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo wp_kses($award_name , $allowed_tags) ?>
        </a>
        <?php else: ?>
          <?php echo wp_kses($award_name , $allowed_tags) ?>
        <?php endif ?>
      <?php echo '</'. esc_attr( $award_name_tag ) .'>' ?>
      <?php endif; ?>
      <div class="award_title_area">
        <!-- Sub Title -->
        <?php if( !empty( $subtitle ) ) : ?>
        <?php echo '<'. esc_attr( $subtitle_tag ) .' class="award_subtitle">'; ?>
          <?php if( !empty( $url ) ): ?>
          <a
            <?php echo $target;?>
            href="<?php echo esc_url( $url );?>">
            <?php echo wp_kses($subtitle , $allowed_tags) ?>
          </a>
          <?php else: ?>
            <?php echo wp_kses($subtitle , $allowed_tags) ?>
          <?php endif ?>
        <?php echo '</'. esc_attr( $subtitle_tag ) .'>' ?>
        <?php endif; ?>
        <!-- Title -->
        <?php if( !empty( $title ) ) : ?>
        <?php echo '<'. esc_attr( $title_tag ) .' class="award_title">'; ?>
          <?php if( !empty( $url ) ): ?>
          <a
            <?php echo $target;?>
            href="<?php echo esc_url( $url );?>">
            <?php echo wp_kses($title , $allowed_tags) ?>
          </a>
          <?php else: ?>
            <?php echo wp_kses($title , $allowed_tags) ?>
          <?php endif ?>
        <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
        <?php endif; ?>
      </div>
      <!-- Year -->
      <?php if( !empty( $year ) ) : ?>
      <div class="award_year"><?php echo esc_html( $year ) ?></div>
      <?php endif; ?>
      <div class="award_logo">
        <img src="<?php echo esc_url( $modern_awards_brand_image_url ); ?>" alt="" />
      </div>
    </div>
    <div class="deskly-hover-reveal-bg" data-background="<?php echo esc_url( $modern_awards_image_url ); ?>"></div>
  </div>
</div>