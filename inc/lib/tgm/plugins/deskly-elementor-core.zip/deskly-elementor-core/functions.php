<?php

/**
 *
 * @package deskly
 */
if (!defined('ABSPATH')) {
  exit(); //exit if access directly
}
//Elementor Widgets Folder Path
if (!function_exists('deskly_get_template')) :
  function deskly_get_template($template_name = null)
  {
		$template_path = apply_filters('deskly-elementor/template-path', 'elementor-templates/');
		$template = locate_template($template_path . $template_name);
		if (!$template) {
			$template = DESKLY_PLUGIN_DIR  . '/widgets/widget-parts/' . $template_name;
		}
		if (file_exists($template)) {
			return $template;
		} else {
			return false;
		}
  }
endif;

//Elementor Modern Widgets Folder Path
if (!function_exists('deskly_get_template2')) :
  function deskly_get_template2($template_name2 = null)
  {
		$template_path2 = apply_filters('deskly-elementor/template-path', 'elementor-templates/');
		$template2 = locate_template($template_path2 . $template_name2);
		if (!$template2) {
			$template2 = DESKLY_PLUGIN_DIR  . '/modern-widgets/widget-parts/' . $template_name2;
		}
		if (file_exists($template2)) {
			return $template2;
		} else {
			return false;
		}
  }
endif;


// ============================
// Elementro Carousel Options
// ============================
if (!function_exists('webex_get_elementor_carousel_options')):
	function webex_get_elementor_carousel_options($arg) {
		/* ===== Begin Carousel Options ===== */
		$arg->start_controls_section(
			'section_additional_options',
			[
				'label'     => esc_html__( 'Carousel Options', 'deskly-elementor-core' ),
				'condition' => [
					'layout' => 'slider',
				],
			]
		);
		$arg->add_control(
			'margin_items',
			[
				'label'   => esc_html__( 'Item Gap', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 30,
				'separator' => 'after',
			]
		);
		$arg->add_control(
			'responsive_heading',
			[
					'label' => esc_html__( 'Responsive', 'deskly-elementor-core' ),
					'type'  => \Elementor\Controls_Manager::HEADING,
			]
		);
		$arg->add_control(
			'items_xxl',
			[
				'label'     => __('Responsive Items for (Up to 1366px)', 'deskly-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 4,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'separator' => 'before',
			]
		);
		$arg->add_control(
			'items_xl',
			[
				'label'     => __('Responsive Items for  (Up to 1200px)', 'deskly-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 3,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'separator' => 'before',
			]
		);
		$arg->add_control(
			'items_lg',
			[
				'label'     => __('Responsive Items for (Up to 1024px)', 'deskly-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 3,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'separator' => 'before',
			]
		);
		$arg->add_control(
			'items_md',
			[
				'label'     => __('Responsive Items for (Up to 768px)', 'deskly-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 2,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6)
			]
		);
		$arg->add_control(
			'items_sm',
			[
				'label'     => __('Responsive Items for (Up to 425px)', 'deskly-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 1,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6)
			]
		);
		$arg->add_control(
			'items_xs',
			[
				'label'     => __('Responsive Items for Extra Small Screen', 'deskly-elementor-core'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 1,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'separator' => 'after',
			]
		);
		$arg->add_control(
			'slider_controlling',
			[
					'label' => esc_html__( 'Slider Controlling', 'deskly-elementor-core' ),
					'type'  => \Elementor\Controls_Manager::HEADING,
			]
		);
		$arg->add_control(
			'infinite',
			[
				'label'   => esc_html__( 'Infinite Loop', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'center_mode',
			[
				'label'   => esc_html__( 'Center Mode', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'autoplay',
			[
				'label'   => esc_html__( 'Autoplay', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__( 'Autoplay Speed', 'deskly-elementor-core' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 8000,
				'condition' => [
					'autoplay' => 'yes',
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'nav_control',
			[
				'label'   => esc_html__( 'Show Nav', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->add_control(
			'dot_control',
			[
				'label'   => esc_html__( 'Show Dots', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$arg->end_controls_section();
		/* ===== End Carousel Options ===== */




		/* ===== Begin Dots Style ===== */
		$arg->start_controls_section('dots_style', [
			'label' => esc_html__('Carousel Dots Style', 'deskly-elementor-core'),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			'condition' => [
				'dot_control' => 'yes',
				'layout' => 'slider',
			],
		]);
		$arg->add_responsive_control(
			'dots_move_up_down',
			[
				'label' => esc_html__( 'Dots Move Up Down', 'deskly-elementor-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$arg->add_responsive_control(
			'dots_alignment',
			[
				'label'       => esc_html__( 'Dots Alignment', 'deskly-elementor-core' ),
				'type'        => \Elementor\Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'deskly-elementor-core' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'deskly-elementor-core' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'deskly-elementor-core' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'     => 'center',
				'toggle'      => false,
				'selectors' => [
					'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots ' => 'justify-content: {{VALUE}};',
				],
			]
		);
		$arg->start_controls_tabs('tabs_dots_style');

		$arg->start_controls_tab('tab_dots_normal', [
			'label' => esc_html__('Normal', 'deskly-elementor-core'),
		]);
		$arg->add_control('dot_color', [
			'label' => esc_html__('Background Color', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->add_responsive_control('dots_width', [
			'label' => esc_html__('Width', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_responsive_control('dots_height', [
			'label' => esc_html__('Height', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_control('dots_border_radius', [
			'label' => esc_html__('Border Radius', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot span' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);
		$arg->end_controls_tab();

		$arg->start_controls_tab('tab_dots_active', [
			'label' => esc_html__('Active', 'deskly-elementor-core'),
		]);
		$arg->add_control('dot_color_active', [
			'label' => esc_html__('Background Color', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->add_responsive_control('dots_width_active', [
			'label' => esc_html__('Width', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_responsive_control('dots_height_active', [
			'label' => esc_html__('Height', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_control('dots_border_radius_active', [
			'label' => esc_html__('Border Radius', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%'],
			'selectors' => [
				'{{WRAPPER}} .webex-slider .webex-carousel .owl-dots .owl-dot.active span' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);
		$arg->end_controls_tab();
		$arg->end_controls_tabs();
		$arg->end_controls_section();
		/* ===== End Dots Style ===== */





		/* ===== Begin Nav Style ===== */
		$arg->start_controls_section('nav_style', [
			'label' => esc_html__('Carousel Nav Style', 'deskly-elementor-core'),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			'condition' => [
				'nav_control' => 'yes',
				'layout' => 'slider',
			],
		]);
		$arg->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' 		=> 'nav_icon_typography',
				'selector' 	=> '{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button i',
			]
		);
		$arg->add_responsive_control('nav_width', [
			'label' => esc_html__('Width', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-next' =>
					'width: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-prev' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->add_responsive_control('nav_height', [
			'label' => esc_html__('Height', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-next' =>
					'height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-prev' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$arg->start_controls_tabs('tabs_nav_style');
		$arg->start_controls_tab('tab_nav_normal', [
			'label' => esc_html__('Normal', 'deskly-elementor-core'),
		]);
		$arg->add_control('nav_color_normal', [
			'label' => esc_html__('Color', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button i' =>
					'color: {{VALUE}}',
			],
		]);
		$arg->add_control('nav_bgcolor_normal', [
			'label' => esc_html__('Background Color', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-next, {{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-prev' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->end_controls_tab();

		$arg->start_controls_tab('tab_nav_hover', [
			'label' => esc_html__('Hover', 'deskly-elementor-core'),
		]);
		$arg->add_control('nav_color_hover', [
			'label' => esc_html__('Color', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button:hover i' =>
					'color: {{VALUE}}',
			],
		]);
		$arg->add_control('nav_bgcolor_hover', [
			'label' => esc_html__('Background Color', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-next:hover, {{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button.owl-prev:hover' =>
					'background-color: {{VALUE}}',
			],
		]);
		$arg->end_controls_tab();
		$arg->end_controls_tabs();
		$arg->add_control('nav_border_radius', [
			'label' => esc_html__('Border Radius', 'deskly-elementor-core'),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%'],
			'selectors' => [
				'{{WRAPPER}} .deskly-slider-wrapper .webex-carousel .owl-nav button' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);
		$arg->end_controls_section();
		/* ===== End Nav Style ===== */


	}
endif;

function deskly_select_posts($post_type = 'post')
{
  $args = [
    'post_type' => $post_type,
    'numberposts' => -1,
    'orderby' => 'title',
    'order' => 'ASC',
  ];
  $query_query = get_posts($args);
  $posts = [];
  if ($query_query) {
    foreach ($query_query as $query) {
      $posts[$query->ID] = $query->post_title;
    }
  }
  return $posts;
}

function deskly_select_category($category = 'category'){
	$terms = get_terms( array(
		'taxonomy' => $category,
		'hide_empty' => true,
	));
	$options = [];
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		foreach ( $terms as $term ) {
			$options[ $term->slug ] = $term->name;
		}
	}
	return $options;
}

function get_thumbnail_size(){
	global $_wp_additional_image_sizes;
	$results = array(
			'full'      => 'full',
			'large'     => 'large',
			'medium'    => 'medium',
			'thumbnail' => 'thumbnail'
	);
	foreach ($_wp_additional_image_sizes as $key => $size) {
			$results[$key] = $key;
	}
	return $results;
}

// Custom Elementor Motion Animation
if ( ! function_exists( 'deskly_ele_theme_animations' ) ) {
  add_filter( 'elementor/controls/animations/additional_animations', 'deskly_ele_theme_animations' );
  function deskly_ele_theme_animations( $ele_theme_animations ) {
    $ele_theme_animations = array_merge(
      $ele_theme_animations,
      array(
        esc_html__( 'Deskly Animations', 'deskly-elementor-core' ) => array(
          'webex_fadeinup'        => esc_html__( 'Fade In Up', 'deskly-elementor-core' ),
          'webex_fadeinright'     => esc_html__( 'Fade In Right', 'deskly-elementor-core' ),
          'webex_fadeinleft'      => esc_html__( 'Fade In Left', 'deskly-elementor-core' ),
          'webex_fadeindown'      => esc_html__( 'Fade In Down', 'deskly-elementor-core' ),
          'webex_fadein'          => esc_html__( 'Fade In', 'deskly-elementor-core' ),
          'webex_popup'           => esc_html__( 'Pop Up', 'deskly-elementor-core' ),
          'webex_infiniterotate'  => esc_html__( 'Infinite Rotate', 'deskly-elementor-core' ),
        ),
      )
    );
    return $ele_theme_animations;
  }
}

// Custom Widgets Appear Animations
if ( ! function_exists( 'webextheme_deskly_widget_animations' ) ) {
  function webextheme_deskly_widget_animations() {
    $deskly_widget_animations = array(
      ''                    => esc_html__( 'None', 'deskly-elementor-core' ),
      'wow webex_fadeinup'      => esc_html__( 'Fade In Up', 'deskly-elementor-core' ),
      'wow webex_fadeinright'   => esc_html__( 'Fade In Right', 'deskly-elementor-core' ),
      'wow webex_fadeinleft'    => esc_html__( 'Fade In Left', 'deskly-elementor-core' ),
      'wow webex_fadeindown'    => esc_html__( 'Fade In Down', 'deskly-elementor-core' ),
      'wow webex_fadein'        => esc_html__( 'Fade In', 'deskly-elementor-core' ),
      'wow webex_popup'         => esc_html__( 'Pop Up', 'deskly-elementor-core' ),
      'wow webex_infiniterotate'=> esc_html__( 'Infinite Rotate', 'deskly-elementor-core' ),
    );
    return $deskly_widget_animations;
  }
}