<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Side_Panel extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-side-panel';
	}

	public function get_title() {
		return esc_html__( 'Side Panel', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Choose Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'webexbase-icon-menu-2',
					'library' 	=> 'deskly_base_icon',
				],
			]
		);
		$this->add_responsive_control(
			'btn_align',
			[
				'label' => __('Search alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .side-panel-icon  ' => 'justify-content: {{VALUE}}!important;',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/

		/*===================================
		Start Search Style
		=====================================*/
		$this->start_controls_section(
			'search_toggler_style',
			[
				'label' 	=> esc_html__( 'Search Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'search_toggler_typography',
				'selector' => '{{WRAPPER}} .side-panel-icon',
			]
		);
		$this->add_responsive_control(
			'search_toggler_normal_margin',
			[
				'label'      => esc_html__( 'Search Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .side-panel-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'search_toggler_normal_padding',
			[
				'label'      => esc_html__( 'Search Padding', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .side-panel-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .side-panel-icon',
			]
		);
		$this->start_controls_tabs( 'theme-search_toggler-tabs' );
		$this->start_controls_tab(
			'search_toggler_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'search_toggler_normal_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .side-panel-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'search_toggler_normal_bg_color',
			[
				'label'     => esc_html__( 'Bg Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .side-panel-icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		//======== Hover Tabs ==========//
		$this->start_controls_tab(
			'search_toggler_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'search_toggler_hover_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .side-panel-icon:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'search_toggler_hover_bg_color',
			[
				'label'     => esc_html__( 'Bg Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .side-panel-icon:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();


	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$icon     = ! empty( $settings['icon']['value'] ) ? $settings['icon']['value'] : '';

		?>

    <!-- Header Search Popup Start -->
		<div class="side-panel side-panel-trigger">
			<i class="side-panel-icon <?php echo esc_attr( $icon ); ?>"></i>
		</div>
    <!-- Header Search Popup End -->

		<?php
	}

}
