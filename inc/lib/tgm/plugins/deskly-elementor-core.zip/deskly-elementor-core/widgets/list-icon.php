<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
use Elementor\Utils;

class DESKLY_List_Icon extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-list-icon';
	}

	public function get_title() {
		return esc_html__( 'List Icon', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Acordion Content ===== */
		$this->start_controls_section(
			'section_content_acordions',
			[
				'label' => esc_html__( 'List Icon', 'deskly-elementor-core' ),
			]
		);
		$this->add_responsive_control(
			'display_type',
			[
				'label' => __('Display Type', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'list-style' => [
						'title' => __( 'List', 'deskly-elementor-core' ),
						'icon' => 'eicon-editor-list-ul',
					],
					'inline-style' => [
						'title' => __( 'Inline', 'deskly-elementor-core' ),
						'icon' => 'eicon-ellipsis-h',
					],
				],
				'default' => 'list',
				'toggle' => true,
			]
		);
		$this->add_responsive_control(
			'list_style_align',
			[
				'label' => __('alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .list-icon-items  ' => 'align-items: {{VALUE}}!important;',
				],
				'condition'            => [
					'display_type' => 'list-style',
				],
			]
		);
		$this->add_responsive_control(
			'list_style_inline_align',
			[
				'label' => __('alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .list-icon-items.inline-style  ' => 'justify-content: {{VALUE}}!important;',
				],
				'condition'            => [
					'display_type' => 'inline-style',
				],
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'deskly_icons',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'base-icon-avatar',
					'library' => 'deskly-flaticon',
				],
			]
		);
		$repeater->add_control(
			'text',
			[
				'label'       => esc_html__( 'Text', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'List Text Place Here', 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'link_url',
			[
				'label' => esc_html__( 'Link URL', 'deskly-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
			]
		);

		$this->add_control(
			'list_icon_items',
			[
				'label'   => esc_html__( 'List Items', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'text' => esc_html__( 'List Text Place Here', 'deskly-elementor-core' ),
						'deskly_icons' => [
							'value' => 'webexbase-icon-check1',
							'library' => 'deskly_base_icon',
						],
					],
					[
						'text' => esc_html__( 'List Text Place Here', 'deskly-elementor-core' ),
						'deskly_icons' => [
							'value' => 'webexbase-icon-check1',
							'library' => 'deskly_base_icon',
						],
					],
					[
						'text' => esc_html__( 'List Text Place Here', 'deskly-elementor-core' ),
						'deskly_icons' => [
							'value' => 'webexbase-icon-check1',
							'library' => 'deskly_base_icon',
						],
					],
				],
				'title_field' => '<i class="{{ deskly_icons.value }}"></i> {{ deskly_icons.value }}{{ text }}',
				// 'title_field' => '{{{ text }}}',
			]
		);
		$this->end_controls_section();
		/* ===== End Team Items Content ===== */




		/* ===== Begin List Style ===== */
		$this->start_controls_section(
			'list_style',
			[
				'label' => esc_html__( 'List Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'list_style_spacing',
			[
				'label' => esc_html__( 'Spacing', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon-items' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);$this->add_responsive_control(
			'list_style_margin',
			[
				'label'      => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .list-icon-block .list-icon-items' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'list_style_padding',
			[
				'label'      => esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .list-icon-block .list-icon-items' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */



		/*===================================
		Start Icon  Style
		=====================================*/
		$this->start_controls_section(
			'list_style_icon_style',
			[
				'label' => esc_html__( 'Icon Styling', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'list_style_icon_gap',
			[
				'label' => esc_html__( 'Spacing', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon-item, {{WRAPPER}} .list-icon-block .list-icon-item a' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_style_icon_typography',
				'selector' => '{{WRAPPER}} .list-icon-block .list-icon',
			]
		);
		$this->add_control(
			'list_style_icon_bg_size',
			[
				'label' => esc_html__( 'Background Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 300,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'icon-tabs' );
		$this->start_controls_tab(
			'list_style_icon_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'list_style_icon_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_style_icon_border',
				'selector' => '{{WRAPPER}} .list-icon-block .list-icon',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'list_style_icon_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'list_style_icon_hover_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon-item:hover .list-icon' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'list_style_icon_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon-item:hover .list-icon' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_style_icon_border_hover',
				'selector' => '{{WRAPPER}} .list-icon-block .list-icon-item:hover .list-icon',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'list_style_icon_margin',
			[
				'label' => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .list-icon-block .list-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'list_style_icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .list-icon-block .list-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Icon  Style
		=====================================*/




		/* ===== Begin Text Style ===== */
		$this->start_controls_section(
			'list_style_text',
			[
				'label' => esc_html__( 'Text Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'working_steps_description_tabs' );
		$this->start_controls_tab(
			'list_style_text_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'list_style_text_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-icon-text' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'list_style_text_normal_typography',
				'selector' 	=> '{{WRAPPER}} .list-icon-text',
			]
		);
		$this->add_responsive_control(
			'list_style_text_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .list-icon-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'list_style_text_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .list-icon-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'list_style_text_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'list_style_text_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-icon-item:hover .list-icon-text' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'list_style_text_hover_typography',
				'selector' 	=> '{{WRAPPER}} .list-icon-item:hover .list-icon-text',
			]
		);
		$this->add_responsive_control(
			'list_style_text_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .list-icon-item:hover .list-icon-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'list_style_text_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .list-icon-item:hover .list-icon-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Description Style ===== */




}

protected function render() {
	$settings = $this->get_settings_for_display();
	?>

	<div class="list-icon-block">
  <?php if ( ! empty( $settings['list_icon_items'] ) ) : ?>
    <ul class="list-icon-items <?php echo esc_attr( $settings['display_type'] ) ?>">
      <?php foreach ( $settings['list_icon_items'] as $item ) :

        $link_url    = ! empty( $item['link_url']['url'] ) ? esc_url( $item['link_url']['url'] ) : '';
        $is_external = ! empty( $item['link_url']['is_external'] ) ? ' target="_blank"' : '';
        $nofollow    = ! empty( $item['link_url']['nofollow'] ) ? ' rel="nofollow noopener noreferrer"' : ' rel="noopener noreferrer"';

        $icon_class  = ! empty( $item['deskly_icons']['value'] ) ? esc_attr( $item['deskly_icons']['value'] ) : '';
        $text        = ! empty( $item['text'] ) ? esc_html( $item['text'] ) : '';

      ?>
        <li class="list-icon-item">
          <?php if ( $link_url ) : ?>
            <a href="<?php echo $link_url; ?>"<?php echo $is_external . $nofollow; ?>>
          <?php endif; ?>

              <?php if ( $icon_class ) : ?>
                <span class="list-icon">
                  <i class="<?php echo $icon_class; ?>" aria-hidden="true"></i>
                </span>
              <?php endif; ?>

              <?php if ( $text ) : ?>
                <span class="list-icon-text"><?php echo $text; ?></span>
              <?php endif; ?>

          <?php if ( $link_url ) : ?>
            </a>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>


	<?php
	}
}
