<?php
// namespace Elementor;
namespace DesklyElementor\Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Circle_Text extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-circle-text';
	}

	public function get_title() {
		return esc_html__( 'Circle Text', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'circle_text_styles', [
				'label' => __( 'Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'label_block' => true,
				'options' => [
					'plain_text' => esc_html__( 'Plain Text', 'deskly-elementor-core' ),
					'text_with_video_link' => esc_html__( 'Text With Video Link', 'deskly-elementor-core' ),
					'text_with_simple_link' => esc_html__( 'Text With Simple Link', 'deskly-elementor-core' ),
				],
				'default' => 'plain_text'
			]
		);

		$this->add_control(
			'circle_text',
			[
				'label' => __( 'Circle Text', 'deskly-elementor-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __('Place Circle Text', 'deskly-elementor-core'),
				'default'	=> esc_html__('Creative Digital - Agency Portfolio -', 'deskly-elementor-core')
			]
		);
		$this->add_control(
			'circle_text_icon',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'deskly-flaticon',
				],
			]
		);

		$this->add_control(
			'video_url',
			[
				'label' 		=> esc_html__( 'Video URL', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'deskly-elementor-core' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> 'https://www.youtube.com/watch?v=a1hEY3Ii70I',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
				'condition' => [
					'circle_text_styles' => 'text_with_video_link'
				],
			]
		);
		$this->add_control(
			'icon_link',
			[
				'label' => __('Icon Link', 'deskly-elementor-core'),
				'type' => Controls_Manager::URL,
				'placeholder' => __('https://your-link.com', 'deskly-elementor-core'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [
					'circle_text_styles' => 'text_with_simple_link'
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/


		/*===================================
		Start Content Style
		=====================================*/
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content Style', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'funfact_item_content_border',
				'selector' => '{{WRAPPER}} .circle-text-box',
			]
		);
		$this->add_responsive_control(
			'border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .circle-text-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'content_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .circle-text-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'content_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .circle-text-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 	=> esc_html__( 'Backgroudn Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .circle-text-box' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'content_box_size',
			[
				'label' => esc_html__( 'Box Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 1020,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .circle-text-box' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'animated_object_duration',
			[
				'label' => esc_html__( 'Animation Duration', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 's' ],
				'range' => [
					's' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .circle-text-box .circle-text-inner-box svg' => 'animation-duration: {{SIZE}}s;',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Style
		=====================================*/


		/*===================================
		Start Text Style
		=====================================*/
		$this->start_controls_section(
			'section_text_style',
			[
				'label' 	=> esc_html__( 'Text Style', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'text_typography',
				'selector' 	=> '{{WRAPPER}} .circle-text-box .circle-text-inner-box text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .circle-text-box .circle-text-inner-box text' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Text Style
		=====================================*/


		/*===================================
		Start Arrow Style
		=====================================*/
		$this->start_controls_section(
			'section_arrow_style',
			[
				'label' 	=> esc_html__( 'Arrow Style', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'arrow_typography',
				'selector' 	=> '{{WRAPPER}} .circle-text-box .circle-text-icon, .circle-text-box .circle-text-svg',
			]
		);

		$this->add_control(
			'arrow_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .circle-text-box .circle-text-icon, .circle-text-box .circle-text-svg' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'arrow_rotating',
			[
				'label' => esc_html__( 'Rotate', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'deg', 'px'],
        'range' => [
					'deg' => [
						'min' => -360,
						'max' => 360,
					],
        ],
        'default' => [
					'unit' => 'deg',
					'size' => 0,
        ],
				'selectors' => [
					'{{WRAPPER}} .circle-text-box .circle-text-icon, .circle-text-box .circle-text-svg' => 'transform: translate(-50%, -50%) rotate({{SIZE}}{{UNIT}});',
				],
			]
		);
		$this->add_responsive_control(
			'arrow_area_size',
			[
				'label'      => esc_html__( 'Arrow Area Size', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .circle-text-box .circle-text-icon, .circle-text-box .circle-text-svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_area_border',
				'selector' => '{{WRAPPER}} .circle-text-box .circle-text-icon, .circle-text-box .circle-text-svg',
			]
		);
		$this->add_responsive_control(
			'arrow_area_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .circle-text-box .circle-text-icon, .circle-text-box .circle-text-svg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Sub Title Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( $settings['circle_text_styles'] == 'plain_text' ) {
			include deskly_get_template('/circle-text/style1.php');
		}
		if ( $settings['circle_text_styles'] == 'text_with_video_link' ) {
			include deskly_get_template('/circle-text/style2.php');
		}
		if ( $settings['circle_text_styles'] == 'text_with_simple_link' ) {
			include deskly_get_template('/circle-text/style3.php');
		}

	}
}
