<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Animated_Objects extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-animated-objects';
	}

	public function get_title() {
		return esc_html__( 'Animated Objects', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'style', [
				'label' => __( 'Choose Object Type', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'label_block' => true,
				'options' => [
					'object_icon' => esc_html__( 'Icon', 'deskly-elementor-core' ),
					'object_image' => esc_html__( 'Image', 'deskly-elementor-core' ),
				],
				'default' => 'object_image'
			]
		);
		$this->add_control(
			'animate_icon',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'base-icon-avatar',
					'library' 	=> 'deskly-flaticon',
				],
				'condition' => [
					 'style' => 'object_icon'
				],
			]
		);
		$this->add_control(
			'photo',
			[
				'label'   => __( 'Photo', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					 'style' => 'object_image'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'photo_image_size',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
				'condition' => [
					 'style' => 'object_image'
				],
			]
		);
		$this->add_responsive_control(
			'animated_object_width',
			[
				'label' => esc_html__( 'Image Width', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 1200,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .object-item' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					 'style' => 'object_image'
				],
				'separator' => 'after'
			]
		);
		$this->add_responsive_control(
			'animated_object_left_right',
			[
				'label' => esc_html__( 'Image Left/Right Movement', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -1500,
						'max' => 1650,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .object-item' => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .animate-icon' => 'left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					 'style' => 'object_image'
				],
			]
		);
		$this->add_responsive_control(
			'animated_object_top_bottom',
			[
				'label' => esc_html__( 'Image Top/Bottom Movement', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -1500,
						'max' => 1650,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .object-item' => 'top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .animate-icon' => 'top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					 'style' => 'object_image'
				],
			]
		);
		$this->add_responsive_control(
			'animated_object_opacity',
			[
				'label' 		=> esc_html__( 'Opacity', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .object-item' => 'opacity: {{SIZE}};',
					'{{WRAPPER}} .animate-icon' => 'opacity: {{SIZE}};',
				],
			]
		);
		$this->add_control(
			'effect_style',
			[
				'label' 		=> esc_html__( 'Animation Styles', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::SELECT,
				'options' 		=> [
					'pulse-animation'  			=> esc_html__( 'Pulse Animation', 'deskly-elementor-core' ),
					'half-spin'  			=> esc_html__( 'Half Spin Animation', 'deskly-elementor-core' ),
					'full-spin'  			=> esc_html__( 'Full Spin Animation', 'deskly-elementor-core' ),
					'float-obj-y'  			=> esc_html__( 'Float Vertical Animation', 'deskly-elementor-core' ),
					'float-obj-x'  			=> esc_html__( 'Float Horizontal Animation', 'deskly-elementor-core' ),
					''			=> esc_html__( 'No Effect', 'deskly-elementor-core' ),
				],
				'default' => [ 'pulse-animation'],
			]
		);
		$this->add_responsive_control(
			'animated_object_duration',
			[
				'label' => esc_html__( 'Animation Timing', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 's' ],
				'range' => [
					's' => [
						'min' => 0,
						'max' => 100,
						'step' => .1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .object-item' => 'animation-duration: {{SIZE}}s;',
					'{{WRAPPER}} .animate-icon' => 'animation-duration: {{SIZE}}s;',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/




		/*===================================
		Start Animate Object Style
		=====================================*/
		$this->start_controls_section(
			'animated_object_icon_style',
			[
				'label' 	=> esc_html__( 'Object Icon Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'icon_typography',
				'selector' 	=> '{{WRAPPER}} .animate-icon',
				'condition' => [
					 'style' => 'object_icon'
				],
			]
		);
		$this->add_control(
			'object_icon_color',
			[
				'label' 	=> esc_html__( 'Backgroudn Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .animate-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'animated_object_image_style',
			[
				'label' 	=> esc_html__( 'Object Image Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'animated_object_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .object-item' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'animated_object_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .object-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'animated_object_shadow',
			'selector' => '{{WRAPPER}} .object-item',
			]
		);
		$this->end_controls_section();
		/*===================================
		End Icon Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute('wrapper','class','object-item');
		$this->add_render_attribute('wrapper','class', $settings['effect_style']);
		?>

			<?php if ( $settings['style'] == 'object_image' ) : ?>
			<div class="deskly-animated-objects">
				<?php
				if ( empty( $settings['photo']['id'] && ! empty( $settings['photo']['url'] ) ) ) {
					$photo_url = $settings['photo']['url'];
				} else {
					$photo_url = Group_Control_Image_Size::get_attachment_image_src( $settings['photo']['id'], 'photo_image_size', $settings );
				}
				?>
				<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
					<img class="img-full" src="<?php echo esc_url( $photo_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
				</div>
			</div>
			<?php endif;?>

			<?php if ( $settings['style'] == 'object_icon' ) : ?>
			<div class="nextech-animated-objects">
				<?php if ( !empty($settings['animate_icon']['value']) ): ?>
				<div class="animate-icon <?php echo esc_attr($settings['effect_style']);?>">
					<i class="<?php echo esc_attr( $settings['animate_icon']['value'] ); ?>"></i>
				</div>
				<?php endif; ?>
			</div>
			<?php endif;?>
			<?php
		}
	}
