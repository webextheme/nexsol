<div class="about-author-block about-author-<?php echo esc_attr( $settings['about_author_styles'] ) ?>">
	<?php if( 'yes' == $settings['author_image_show_hide'] ) : ?>
	<div class="author-thumb">
		<img src="<?php echo esc_url( $about_author_s1_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
	</div>
	<?php endif; ?>
	<div class="author-content">
		<h5 class="author-name"><?php echo wp_kses($author_name , $allowed_tags) ?></h5>
		<p class="author-designation"><?php echo wp_kses($author_designation , $allowed_tags) ?></p>
	</div>
</div>