<?php
global $post;
$author_id = get_post_field('post_author' , get_the_ID());
$author_thumb = get_avatar_url($author_id);
$photo = $settings['author_photo'];
$note = $settings['author_note'];
?>
<div class="news-item-style1 wx_hover_item">
  <?php if('yes' === $settings['news_thumb_show_hide']): ?>
  <div class="news-thumb tp--hover-img" data-displacement="<?php echo esc_url( DESKLY_CORE_ASSETS . '/img/bg/line.png' ); ?>" data-intensity="0.2" data-speedin="1" data-speedout="1">
    <?php echo get_the_post_thumbnail( $idd, $settings['news_image'] ) ?>
    <?php if (!empty( $categories_list ) && ( 'yes' === $settings['news_category_show_hide'] )): ?>
      <div class="news-thumb-meta">
        <span class="post-categories"><?php echo $categories_list ?></span>
      </div>
    <?php endif;?>
    <?php if (( 'yes' === $settings['news_thumb_date_show_hide'] )): ?>
      <div class="news-thumb-meta">
        <div class="news-top-meta-thumb-date">
          <span class="thumb-date"><?php echo get_the_date('d F, Y') ?></span>
        </div>
      </div>
    <?php endif;?>
  </div>
  <?php endif;?>
  <div class="news-description">
    <div class="news-top-meta">
      <?php if( 'yes' == $settings['hide_author'] && in_array( 'author', (array) $choose_meta, true ) ): ?>
      <div class="post_meta post-author">
        <div class="author-thumb">
          <?php if ( ! empty( $photo ) ) : ?>
            <span class="author-avatar">
              <a href="<?php echo esc_url( get_permalink() ); ?>">
                <img
                  src="<?php echo esc_url( $author_thumb ); ?>"
                  class="rounded-circle"
                  alt="<?php echo esc_attr( get_the_author_meta( 'display_name', $author_id ) ); ?>"
                />
              </a>
            </span>
          <?php endif; ?>

          <i class="post-author-icon far fa-user" aria-hidden="true"></i>

          <?php if ( ! empty( $note ) ) : ?>
            <span class="note"><?php echo esc_html( $note ); ?></span>
          <?php endif; ?>

          <a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>" class="name">
            <?php echo esc_html( get_the_author_meta( 'display_name', $author_id ) ); ?>
          </a>
        </div>
      </div>
      <?php endif; ?>

      <?php if( 'yes' == $settings['hide_date'] && in_array( 'date', (array) $choose_meta, true ) ): ?>
      <div class="post_meta post-date">
        <span class="entry-date">
          <a href="<?php echo esc_url(get_permalink());?>">
            <i class="far fa-calendar-alt"></i>
            <?php echo esc_html( get_the_date() ) ?>
          </a>
        </span>
      </div>
      <?php endif; ?>

      <?php if ( 'yes' == $settings['hide_comments'] && in_array( 'comments', $choose_meta ) && ( !post_password_required() && ( comments_open() || get_comments_number() ) ) ): ?>
      <div class="post_meta post-comments">
        <span class="entry-comments">
          <i class="far fa-comments" aria-hidden="true"></i>
          <a href="<?php echo esc_url( get_comments_link() ); ?>">
            <?php
              $comments_number = get_comments_number();

              /* translators: %s = number of comments */
              printf(
                esc_html( _n( 'Comment (%s)', 'Comments (%s)', $comments_number, 'deskly-core' ) ),
                esc_html( number_format_i18n( $comments_number ) )
              );
            ?>
          </a>
        </span>
      </div>
      <?php endif;?>
    </div>

    <h4 class="the-title"><a href="<?php echo get_the_permalink() ?>"><?php echo $the_title; ?></a></h4>
    <?php if ( 'yes' === $settings['excerpt_show_hide'] ) : ?>
      <?php if( has_excerpt() ): ?>
      <div class="post-excerpt"><?php echo wpautop( wp_trim_words( get_the_excerpt(), $excerpt_count, '...' ) );?></div>
      <?php else: ?>
      <div class="post-excerpt"><?php echo wpautop( wp_trim_words( get_the_content(), $excerpt_count, '...' ) );?></div>
      <?php endif;?>
    <?php endif;?>
    <?php if( 'yes' == $settings['news_button'] ): ?>
    <div class="news-button">
      <?php if ( !empty( $settings['news_button_text'] )): ?>
      <a href="<?php echo get_the_permalink() ?>" class="deskly_btn"><?php echo esc_html($settings['news_button_text']);?></a>
      <?php endif;?>
    </div>
    <?php endif;?>
  </div>
</div>