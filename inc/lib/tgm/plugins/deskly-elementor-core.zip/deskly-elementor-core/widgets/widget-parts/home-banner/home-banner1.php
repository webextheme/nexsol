<div class="home_banner_03 shape-position" style="background-image: url(<?php echo esc_url($settings['home_banner1_bg_image']['url']);  ?>);">
	<div class="home-style-03-shpe1"></div>
	<div class="home-style-03-shpe2"></div>
	<div class="home-style-03-shpe3"></div>
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-lg-10 col-xl-7">
				<div class="content-box mrb-lg-60 text-lg-start text-center">
					<?php if( !empty( $settings['banner1_title'] )) : ?>
					<h1 class="static-home-banner-title mrb-30"><?php echo wp_kses_post($settings['banner1_title'], 'deskly_allowed_tags'); ?></h1>
					<?php endif; ?>
					<?php if( !empty( $settings['banner1_text'] )) : ?>
					<p class="static-home-banner-desc mrb-50">
					<?php echo wp_kses_post($settings['banner1_text'], 'deskly_allowed_tags'); ?>
					</p>
					<?php endif; ?>
					<?php if(!empty($settings['banner1_button_text'] || $settings['banner1_button_url']['url'] )): ?>
					<div class="btn-box">
						<a href="<?php echo esc_url($settings['banner1_button_url']['url']);?>" class="animate-btn-style3"><?php echo esc_html($settings['banner1_button_text']);?></a>
					</div>
					<?php endif; ?>
				</div>
			</div>
		  <?php if(!empty($settings['home_banner1_form_title'] || $settings['home_banner1_form_sc'] )): ?>
			<div class="col-md-12 col-lg-10 col-xl-5">
				<div class="request-a-call-back-form-style2">
					<h3 class="mrt-0 mrb-30"><?php echo esc_html( $settings['home_banner1_form_title'] ); ?></h3>
					<?php echo do_shortcode( $settings['home_banner1_form_sc'] );?>
				</div>
			</div>
			<?php endif; ?>
		</div>
	</div>
</div>