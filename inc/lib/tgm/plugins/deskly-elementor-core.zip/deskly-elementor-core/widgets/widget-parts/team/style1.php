<?php
  $custom_link = $member['title_link'];
	$target = ( $custom_link && $custom_link['is_external'] ) ? ' target="_blank"' : '';
	$url = ( $custom_link && $custom_link['url'] ) ? $custom_link['url'] : '';
?>

<div class="team-block team-block-<?php echo esc_attr( $settings['team_styles'] ) ?> <?php echo esc_attr( $settings['team_gradient_styles'] ) ?>">
  <div class="team-upper-part">
    <img src="<?php echo esc_url( $image_url ) ?>" alt="<?php echo esc_html( $member['name'] ) ?>">
    <?php if ( 'yes' === $member['show_social_links'] ) : ?>
    <div class="team-social">
      <i class="social-share-icon webexbase-icon-plus"></i>
      <ul class="social-list">
        <?php
          if ( !empty( $member['facebook'] ) ) {
            printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-facebook-f"></i></a></li>',
              esc_url( $member['facebook'] ),
            );
          }
          if ( !empty( $member['x'] ) ) {
            printf('<li><a href="%1$s" aria-label="Social"><i class="webexbase-icon-twitter-2"></i></a></li>',
              esc_url( $member['x'] ),
            );
          }
          if ( !empty( $member['linkedin'] ) ) {
            printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-linkedin-in"></i></a></li>',
              esc_url( $member['linkedin'] ),
            );
          }
          if ( !empty( $member['instagram'] ) ) {
            printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-instagram"></i></a></li>',
              esc_url( $member['instagram'] ),
            );
          }
          if ( !empty( $member['website'] ) ) {
            printf('<li><a href="%1$s" aria-label="Social"><i class="fas fa-globe"></i></a></li>',
              esc_url( $member['website'] ),
            );
          }
          if ( !empty( $member['email'] ) ) {
            printf('<li><a href="%1$s" aria-label="Social"><i class="fas fa-envelope"></i></a></li>',
              esc_url( $member['email'] ),
            );
          }
          if ( !empty( $member['github'] ) ) {
            printf('<li><a href="%1$s" aria-label="Social"><i class="fab fa-github"></i></a></li>',
              esc_url( $member['github'] ),
            );
          }
        ?>
      </ul>
    </div>
    <?php endif; ?>
    <div class="team-bottom-part">
      <?php echo '<'. esc_html( $member['title_tag'] ) .' class="team-title">'; ?>
        <?php if( !empty( $url ) ): ?>
        <a
          <?php echo $target;?>
          href="<?php echo esc_url( $url );?>">
          <?php echo esc_html( $member['name'] ) ?>
        </a>
        <?php else: ?>
          <?php echo esc_html( $member['name'] ) ?>
        <?php endif ?>
      <?php echo '</'. esc_html( $member['title_tag'] ) .'>' ?>

      <?php echo '<'. esc_html( $member['designation_tag'] ) .' class="team-designation">'; ?>
        <?php echo esc_html( $member['designation'] ) ?>
      <?php echo '</'. esc_html( $member['designation_tag'] ) .'>' ?>
    </div>
  </div>
</div>