<div class="services-block services-block-<?php echo esc_attr( $settings['services_styles'] ) ?>">
  <div class="services-box-outer">
    <div class="services-inner">
      <div class="title-area">
        <!-- counting -->
        <?php if( !empty( $counting ) ) : ?>
          <span class="counting"><?php echo esc_html( $counting ) ?></span>
        <?php endif; ?>
        <!-- Title -->
        <?php if( !empty( $title ) ) : ?>
        <?php echo '<'. esc_attr( $title_tag ) .' class="services-title">'; ?>
          <?php if( !empty( $url ) ): ?>
          <a
            <?php echo $target;?>
            href="<?php echo esc_url( $url );?>">
            <?php echo wp_kses($title , $allowed_tags) ?>
          </a>
          <?php else: ?>
            <?php echo wp_kses($title , $allowed_tags) ?>
          <?php endif ?>
        <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
        <?php endif; ?>
      </div>
      <!-- List Content -->
      <?php if( !empty( $list_content ) ) : ?>
      <div class="list_content">
        <?php echo wp_kses($list_content , $allowed_tags) ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <!-- Icon -->
  <?php if ( !empty($deskly_icons) ): ?>
    <i class="services-icon <?php echo esc_attr( $deskly_icons ); ?>"></i>
  <?php endif; ?>
</div>