<div class="video-popup-item image-video-block <?php echo esc_attr( $settings['video_popup_rotate_image'] ) ?>">
	<img class="img-full" src="<?php echo esc_url( $video_bg_image ); ?>" loading="eager" alt="<?php echo get_bloginfo( 'name' ); ?>">
	<?php if(!empty($video_url)):?>
		<div class="video-link">
			<a class="video-popup" href="<?php echo esc_url($video_url); ?>" aria-label="Video Popup">
				<i class="fas fa-play"></i>
			</a>
		</div>
	<?php endif;?>
</div>