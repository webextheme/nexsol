<div class="video-popup-item image-video-block-style2">
	<div class="video-link">
		<a class="video-popup" href="<?php echo esc_url($video_url); ?>" aria-label="Video Popup">
			<i class="fas fa-play"></i>
		</a>
		<?php if ( !empty($video_bg_image) ): ?>
			<img class="video-thumb img-full" src="<?php echo esc_url( $video_bg_image ); ?>" loading="eager" alt="<?php echo get_bloginfo( 'name' ); ?>">
		<?php endif; ?>
	</div>
	<?php if ( !empty($video_title) ): ?>
		<?php echo '<'. esc_html( $settings['video_title_tag'] ) .' class="video-title">'; ?><?php echo wp_kses($video_title , $allowed_tags) ?><?php echo '</'. esc_html( $settings['video_title_tag'] ) .'>' ?>
	<?php endif; ?>
</div>