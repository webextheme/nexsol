<div class="webex-form request-a-call-back-form-style2">
	<?php if(!empty($settings['subtitle']) && ( 'yes' === $settings['sideline_show_hide'] )): ?>
		<h5 class="side-line-left form-subtitle"><?php echo esc_html($settings['subtitle']); ?></h5>
		<?php elseif(!empty($settings['subtitle'])): ?>
		<h5 class="form-subtitle"><?php echo esc_html($settings['subtitle']); ?></h5>
	<?php endif; ?>
	<?php if(!empty($settings['title'])): ?>
		<h3 class="form-title"><?php echo esc_html($settings['title']); ?></h3>
	<?php endif; ?>
	<?php
		if( !empty($settings['deskly_select_contact_form']) ){
			echo do_shortcode( '[contact-form-7  id="'.$settings['deskly_select_contact_form'].'"]' );
		}else{
			echo '<div class="alert alert-danger"><p class="m-0">' . __('Please Select contact form.', 'deskly-elementor-core' ). '</p></div>';
		}
	?>
</div>