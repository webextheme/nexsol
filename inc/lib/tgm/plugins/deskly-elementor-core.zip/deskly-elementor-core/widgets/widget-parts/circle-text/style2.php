<div class="circle-text-box">
	<?php if(!empty($settings['video_url']['url'])):?>
	<a class="video-popup circle-text-link" href="<?php echo esc_url($settings['video_url']['url']); ?>" aria-label="Video Popup">
		<div class="circle-text-inner-box">

			<?php if ( !empty($settings['circle_text_icon']['value']) ): ?>
			<div class="circle-text-icon">
				<i class="<?php echo esc_attr( $settings['circle_text_icon']['value'] ); ?>"></i>
			</div>
			<?php endif; ?>

			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" viewBox="0 0 120 120">
			<defs>
				<path id="textPath" d="M110,59.5c0,27.6-22.4,50-50,50s-50-22.4-50-50s22.4-50,50-50S110,31.9,110,59.5z"></path>
			</defs>
			<text>
				<textPath xlink:href="#textPath"><?php echo esc_html( $settings['circle_text'] ); ?></textPath>
			</text>
		</svg>
		</div>
	</a>
	<?php endif;?>
</div>