<div class="feature-box-block feature-box-block-<?php echo esc_attr( $settings['feature_box_styles'] ) ?>">
  <div class="feature-box-inner">
    <!-- counting -->
    <?php if( !empty( $counting ) ) : ?>
      <h4 class="counting"><?php echo esc_html( $counting ) ?></h4>
    <?php endif; ?>

    <!-- Icon -->
    <?php if ( !empty($deskly_icons) ): ?>
      <i class="feature-box-icon <?php echo esc_attr( $deskly_icons ); ?>"></i>
    <?php endif; ?>

    <!-- Title -->
    <?php if( !empty( $title ) ) : ?>
    <?php echo '<'. esc_attr( $title_tag ) .' class="feature-box-title">'; ?>
      <?php if( !empty( $url ) ): ?>
      <a
        <?php echo $target;?>
        href="<?php echo esc_url( $url );?>">
        <?php echo wp_kses($title , $allowed_tags) ?>
      </a>
      <?php else: ?>
        <?php echo wp_kses($title , $allowed_tags) ?>
      <?php endif ?>
    <?php echo '</'. esc_attr( $title_tag ) .'>' ?>
    <?php endif; ?>

    <!-- Description -->
    <?php if( !empty( $description ) ) : ?>
      <p class="feature-box-description"><?php echo esc_html( $description ) ?></p>
    <?php endif; ?>
  </div>
</div>