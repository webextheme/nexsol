<div class="workspace-block workspace-block-<?php echo esc_attr( $settings['workspace_styles'] ) ?> <?php echo esc_attr( $settings['workspace_gradient_styles'] ) ?>">
  <div class="workspace-thumb">
    <?php echo get_the_post_thumbnail( $get_id, $settings['workspace_image'] ); ?>
    <?php if( 'yes' == $settings['link_btn_show_hide'] ): ?>
    <div class="workspace-link-icon">
      <a href="<?php echo esc_url( get_the_permalink() ) ?>"><i class="webexbase-icon-up-right-arrow"></i></a>
    </div>
    <?php endif;?>
    <div class="workspace-details">
      <?php if( !empty( $categories_list ) && ( 'yes' == $settings['workspace_category_show_hide'] ) ) : ?>
      <div class="workspace-category"><?php echo $categories_list ?></div>
      <?php endif;?>
      <h4 class="workspace-title"><a href="<?php echo esc_url( get_the_permalink() ) ?>"><?php echo esc_html( $the_title ) ?></a></h4>
    </div>
  </div>
</div>