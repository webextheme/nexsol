<div class="gallery-block gallery-block-<?php echo esc_attr( $settings['gallery_styles'] ); ?>">
  <div class="gallery-thumb">
    <div class="gallery-card">
      <a href="<?php echo esc_url( $image_url ); ?>" data-fancybox="gallery" data-caption="Caption Images 1">
        <img src="<?php echo esc_url( $image_url ); ?>" alt="Image Gallery">
        <div class="view_icon"><i class="webexbase-icon-zoom-in"></i></div>
      </a>
    </div>
  </div>
</div>
