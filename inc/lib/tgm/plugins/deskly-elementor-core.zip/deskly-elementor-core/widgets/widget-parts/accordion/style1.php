<div class="faq-block faq-block-style1">
	<div class="accordion <?php echo esc_attr( $settings['accordion_gradient_styles'] ) ?>">
		<?php foreach ($settings['acordion_items'] as $keys => $item) : ?>
		<div class="accordion-item<?php if( '0' == $keys ) : ?> active<?php endif; ?>">
			<div class="accordion-header">
				<!-- Counting -->
				<?php if( !empty( $item['counting'] ) ) : ?>
					<h4 class="counting"><?php echo esc_html( $item['counting'] ) ?></h4>
				<?php endif; ?>
			</div>

			<div class="accordion-body">
				<!-- Title -->
				<?php if( !empty( $item['title'] ) ) : ?>
					<?php echo '<'. esc_attr( $item['title_tag'] ) .' class="title">'; ?>
						<?php echo esc_html( $item['title'] ) ?>
					<?php echo '</'. esc_attr( $item['title_tag'] ) .'>' ?>
				<?php endif; ?>
				<!-- Description -->
				<?php if( !empty( $item['description'] ) ) : ?>
				<p class="description"><?php echo esc_html( $item['description'] ) ?></p>
				<?php endif; ?>
			</div>

		</div>
		<?php endforeach; ?>
	</div>
</div>