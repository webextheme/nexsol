<div class="deskly_btn_block">
  <a href="<?php echo esc_url($settings['button_link']['url']);?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> class="cs-btn-one deskly_btn <?php echo esc_attr($settings['button_size']); ?> <?php echo esc_attr($settings['button_shape_styles']); ?> <?php if($settings['button_fullwidth'] == 'yes'): ?>btn-block<?php endif; ?>"><?php echo esc_html($settings['button_text']);?></a>
</div>
