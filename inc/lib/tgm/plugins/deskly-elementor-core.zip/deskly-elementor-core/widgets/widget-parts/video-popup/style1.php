<div class="video-popup-item video-block-wrapper">
	<div class="video-block">
		<div class="video-link">
		<?php if(!empty($video_url)):?>
			<a class="video-popup" href="<?php echo esc_url($video_url); ?>" aria-label="Video Popup">
				<i class="fas fa-play"></i>
			</a>
		<?php endif;?>
		</div>
	</div>
</div>