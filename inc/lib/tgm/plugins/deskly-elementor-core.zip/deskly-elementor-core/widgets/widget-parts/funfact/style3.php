<div class="funfact-block funfact-block-style3">
	<!-- Icon -->
	<?php if ( !empty($deskly_icons) ): ?>
	<div class="funfact-icon">
		<i class="<?php echo esc_attr( $deskly_icons ); ?>"></i>
	</div>
	<?php endif; ?>
	<?php if ( $settings['ending_number'] ): ?>
	<div class="count-box">
		<span data-stop="<?php echo esc_html( $settings['ending_number'] ); ?>" data-speed="<?php echo esc_html( $settings['duration'] ); ?>" class="counting-number">0</span><span class="post-symbol"><?php echo esc_html( $settings['post_symbol'] ); ?></span>
	</div>
	<?php endif;?>
	<?php if ( $settings['title'] ): ?>
	<?php echo '<'. esc_attr( $title_tag ) .' class="funfact-title">';?>
	<?php echo wp_kses($title , $allowed_tags) ?>
	<?php echo '</'. esc_attr( $title_tag ) .'>' ?>
	<?php endif;?>
</div>