<!-- Home Slider Start -->
<div class="home_banner_01">
	<div class="home-carousel owl-theme owl-carousel" data-options="<?php echo esc_attr(json_encode($data_options)); ?>">
		<?php foreach($slider_style1 as $item):?>
		<div class="slide-item">
			<div class="image-layer" style="background-image: url(<?php echo esc_url($item['image_slider']['url']); ?>);"></div>
			<div class="auto-container">
				<div class="row clearfix">
					<div class="col-lg-12 content-column">
						<div class="content-box">
							<?php if( !empty( $item['slider_title'] )) : ?>
							<h1 class="home-carousel-title"><?php echo wp_kses_post($item['slider_title']); ?></h1>
							<?php endif; ?>
							<?php if( !empty( $item['slider_subtitle'] )) : ?>
							<p class="home-carousel-text"><?php echo wp_kses_post($item['slider_subtitle']); ?></p>
							<?php endif; ?>
							<div class="btn-box">
								<?php if(!empty($item['slider_button_text'] || $item['slider_button_url']['url'] )): ?>
								<a href="<?php echo esc_url($item['slider_button_url']['url']);?>" class="animate-btn-style5 deskly_btn btn-md">
									<div class="btn-inner">
										<i class="base-icon-arrow-up-right2"></i>
										<span class="d-block"><?php echo esc_html($item['slider_button_text']);?></span>
									</div>
								</a>
								<?php endif;?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="shape2"></div>
		</div>
		<?php endforeach;?>
	</div>
</div>
<!-- Home Slider End -->