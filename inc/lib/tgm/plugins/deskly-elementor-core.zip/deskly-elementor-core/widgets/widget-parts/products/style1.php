<div class="product-block product-block-<?php echo esc_attr( $settings['product_styles'] ) ?>">

  <!-- Product Thumbnail -->
  <div class="product-thumb">
    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
      <?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) ); ?>
    </a>
  </div>

  <div class="product-content">
    <!-- Product Title -->
    <h4 class="product-title">
      <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </h4>

    <?php if( 'yes' == $settings['product_short_text_show_hide'] ): ?>
    <!-- Short Description -->
    <div class="product-short-description">
      <?php
        if ( empty( $product ) ) {
          $product = wc_get_product( get_the_ID() );
        }
        $short_description = $product->get_short_description();
        if ( ! empty( $short_description ) ) {
          echo wp_kses_post( wp_trim_words( $short_description, $excerpt_count, '...' ) );
        }
      ?>
    </div>
    <?php endif;?>

    <?php if( 'yes' == $settings['product_ratings_show_hide'] ): ?>
    <!-- Product Rating -->
    <?php if ( wc_review_ratings_enabled() ) : ?>
      <?php $average = $product->get_average_rating(); ?>
      <?php if ( $average > 0 ) : ?>
        <div class="product-rating" title="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'woocommerce' ), $average ) ); ?>">
          <div class="star-rating" role="img" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'woocommerce' ), $average ) ); ?>">
            <span style="width:<?php echo esc_attr( ( (float) $average / 5 ) * 100 ); ?>%"></span>
          </div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    <?php endif;?>

    <!-- Product Price -->
    <div class="product-price">
      <?php echo wp_kses_post( $product->get_price_html() ); ?>
    </div>
  </div>

</div>
