<div class="client-block client-item-<?php echo esc_attr( $settings['client_styles'] ) ?> <?php echo esc_attr( $settings['dark_light_styles'] ) ?>">
	<div class="client-item-thumb">
		<img class="client-item-item-img" src="<?php echo esc_url( $client_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
		<img class="client-item-item-hover" src="<?php echo esc_url( $client_image_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" />
	</div>
</div>