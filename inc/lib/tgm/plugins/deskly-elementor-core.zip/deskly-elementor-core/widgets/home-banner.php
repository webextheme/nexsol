<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class DESKLY_Home_Banner extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-home-banner';
	}

	public function get_title() {
		return esc_html__( 'Home Banner', 'deskly-elementor-core' );
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_script_depends() {
		return array('home1-slider-js');
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {
		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'slider_content',
			[
				'label' => __( 'Home Banner Content', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'style', [
				'label' 	=> esc_html__( 'Choose Home Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT2,
				'label_block' => true,
				'options' => [
					'home_slide1' => esc_html__( 'Home Slider 01', 'deskly-elementor-core' ),
				],
				'default' => 'home_slide1'
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'slider_title', [
				'label' 		=> esc_html__( 'Slider Title', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
			]
		);
		$repeater->add_control(
			'slider_subtitle', [
				'label' 		=> esc_html__( 'Slider Sub Title', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
				'default' => wp_kses_post('We have almost 20+ years of experience for providing interior & Architectural services solutions', 'deskly-elementor-core'),
			]
		);
		$repeater->add_control(
			'image_slider',
			[
				'label'			=> esc_html__( 'Add Image','deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::MEDIA,
				'default' => [],
			]
		);
		$repeater->add_control(
			'slider_button_text',
			[
				'label' 		=> esc_html__( 'Button Text', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
				'default' => esc_html__('Read More', 'deskly-elementor-core'),
			]
		);
		$repeater->add_control(
			'slider_button_url',
			[
				'label' 		=> esc_html__( 'Button URL', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'deskly-elementor-core' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);
		$this->add_control(
			'slider_style1',
			[
				'label' 	=> esc_html__( 'Slider', 'deskly-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::REPEATER,
				'fields' 	=> $repeater->get_controls(),
				'default' => [
					[
						'slider_title' => esc_html__('Providing Best Home Decore', 'deskly-elementor-core'),
					],
				],
				'title_field' => '{{{ slider_title }}}',
				'condition' 	=> ['style' => ['home_slide1']],
			]
		);

		// Home Banner1 Content
		$this->add_control(
			'banner1_title', [
				'label' 		=> esc_html__( 'Banner Title', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
				'default' => esc_html__('Build Your Kitchen Interior With Us', 'deskly-elementor-core'),
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->add_control(
			'banner1_text', [
				'label' 		=> esc_html__( 'Banner Text', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
				'default' => esc_html__('We have almost 35+ years of experience for providing Kitchen Interior services solutions', 'deskly-elementor-core'),
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->add_responsive_control(
			'home_banner1_bg_image',
			[
				'label' 		=> esc_html__( 'Background Image', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::MEDIA,
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->add_control(
			'banner1_button_text',
			[
				'label' 		=> esc_html__( 'Button Text', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
				'default' => esc_html__('Get a Quote', 'deskly-elementor-core'),
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->add_control(
			'banner1_button_url',
			[
				'label' 		=> esc_html__( 'Button URL', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'deskly-elementor-core' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/


		// ============================
		// Begin Carousel Options
		// ============================
		$this->start_controls_section(
			'section_additional_options',
			[
				'label'     => esc_html__( 'Carousel Options', 'deskly-elementor-core' ),
				'condition' 	=> ['style' => ['home_slide1']],
			]
		);
		$this->add_control(
			'loop',
			[
				'label'   => esc_html__( 'Infinite Loop', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$this->add_control(
			'autoplay',
			[
				'label'   => esc_html__( 'Autoplay', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$this->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__( 'Autoplay Speed', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 8000,
				'condition' => [
					'autoplay' => 'yes',
				],
				'frontend_available' => true,
			]
		);
		$this->add_control(
			'nav_control',
			[
				'label'   => esc_html__( 'Show Nav', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'deskly-elementor-core' ),
					'no'  => esc_html__( 'No', 'deskly-elementor-core' ),
				],
				'frontend_available' => true,
			]
		);
		$this->end_controls_section();
		// ============================
		// End Carousel Options
		// ============================


		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'home_banner1_form_content',
			[
				'label' => __( 'Home Form Content', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->add_control(
			'home_banner1_form_sc', [
				'label' 		=> esc_html__( 'Contact Form Shortcode', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->add_control(
			'home_banner1_form_title', [
				'label' 		=> esc_html__( 'Title', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/

		/*===================================
		Start Home Slider Styles
		=====================================*/
		$this->start_controls_section(
			'home_banner_styles',
			[
				'label' 	=> esc_html__( 'Home Banner Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'home_slider_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .home_banner_01 .home-carousel .slide-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> ['style' => ['home_slide1']],
			]
		);
		$this->add_responsive_control(
			'home_banner1_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .home_banner_03' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> ['style' => ['home_banner1']],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Home Slider Styles
		=====================================*/



		/*===================================
		Start Button Style
		=====================================*/
		$this->start_controls_section(
			'button_style',
			[
				'label' 	=> esc_html__( 'Button Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'theme-button-tabs' );
		$this->start_controls_tab(
			'button_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_responsive_control(
			'button_normal_size',
			[
				'label' => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 800,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .home_banner_01 .home-carousel .slide-item .rounded-btn' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .home_banner_01 .home-carousel .slide-item .rounded-btn',
			]
		);
		$this->add_responsive_control(
			'button_normal_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}}  .home_banner_01 .home-carousel .slide-item .rounded-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .home_banner_01 .home-carousel .slide-item .rounded-btn',
			]
		);
		$this->add_control(
			'button_normal_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .home_banner_01 .home-carousel .slide-item .rounded-btn' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .home_banner_01 .home-carousel .slide-item .rounded-btn',
			]
		);
		$this->end_controls_tab();

		//======== Hover Tabs ==========//
		$this->start_controls_tab(
			'button_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'button_hover_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .home_banner_01 .home-carousel .slide-item .rounded-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'button_hover_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .home_banner_01 .home-carousel .slide-item .rounded-btn:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Button Style
		=====================================*/


		/* ===== Begin Nav Style ===== */
		$this->start_controls_section('nav_style', [
			'label' => esc_html__('Carousel Nav Style', 'deskly-elementor-core'),
			'tab' => Controls_Manager::TAB_STYLE,
			'condition' => [
				'nav_control' => 'yes',
			],
		]);
		$this->start_controls_tabs('tabs_nav_style');
		$this->start_controls_tab('tab_nav_normal', [
			'label' => esc_html__('Normal', 'deskly-elementor-core'),
		]);
		$this->add_responsive_control('nav_normal_icon_size', [
			'label' => esc_html__('Icon Size', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button i' =>
					'font-size: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button i' =>
					'font-size: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_responsive_control('nav_normal_width', [
			'label' => esc_html__('Width', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .slide-apartment .owl-nav .owl-dot span' =>
					'width: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav .owl-dot span' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_responsive_control('nav_normal_height', [
			'label' => esc_html__('Height', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .slide-apartment .owl-nav .owl-dot span' =>
					'height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav .owl-dot span' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_control('nav_color_normal', [
			'label' => esc_html__('Color', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button i' =>
					'color: {{VALUE}}',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button i' =>
					'color: {{VALUE}}',
			],
		]);
		$this->add_control('nav_bgcolor_normal', [
			'label' => esc_html__('Background Color', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button.owl-next, {{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button.owl-prev' =>
					'background-color: {{VALUE}}',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button.owl-next, {{WRAPPER}} .home-carousel.owl-carousel .owl-nav button.owl-prev' =>
					'background-color: {{VALUE}}',
			],
		]);
		$this->end_controls_tab();

		$this->start_controls_tab('tab_nav_hover', [
			'label' => esc_html__('Hover', 'deskly-elementor-core'),
		]);
		$this->add_responsive_control('nav_hover_icon_size', [
			'label' => esc_html__('Icon Size', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button i' =>
					'font-size: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button i' =>
					'font-size: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_responsive_control('nav_hover_width', [
			'label' => esc_html__('Width', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .slide-apartment .owl-nav .owl-dot span' =>
					'width: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .home-carousel.owl-carousel .slide-apartment .owl-nav .owl-dot span' =>
					'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_responsive_control('nav_hover_height', [
			'label' => esc_html__('Height', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 500,
				],
			],
			'size_units' => ['px'],
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .slide-apartment .owl-nav .owl-dot span' =>
					'height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .home-carousel.owl-carousel .slide-apartment .owl-nav .owl-dot span' =>
					'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_control('nav_color_hover', [
			'label' => esc_html__('Color', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .owl-nav button:hover i' =>
					'color: {{VALUE}}',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button:hover i' =>
					'color: {{VALUE}}',
			],
		]);
		$this->add_control('nav_bgcolor_hover', [
			'label' => esc_html__('Background Color', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button.owl-next:hover, {{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button.owl-prev:hover' =>
					'background-color: {{VALUE}}',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button.owl-next:hover, {{WRAPPER}} .home-carousel.owl-carousel .owl-nav button.owl-prev:hover' =>
					'background-color: {{VALUE}}',
			],
		]);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_control('nav_border_radius', [
			'label' => esc_html__('Border Radius', 'deskly-elementor-core'),
			'type' => Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%'],
			'selectors' => [
				'{{WRAPPER}} .deskly-elementor-core-slider .owl-carousel .owl-nav button' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button' =>
					'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'owl_nav_border',
				'selector' => '{{WRAPPER}} .home-carousel.owl-carousel .owl-nav button'
			]
		);
		$this->end_controls_section();
		/* ===== End Nav Style ===== */
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$data_options['loop']               = $settings['loop'] === 'yes' ? true : false;
		$data_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$data_options['nav']               = $settings['nav_control'] === 'yes' ? true : false;
		$data_options['rtl']				= is_rtl() ? true: false;


		$slider_style1 	= 	 $settings['slider_style1'];

		if ( $settings['style'] == 'home_slide1' ) {
			include deskly_get_template('/home-banner/home-slider1.php');
		}
		if ( $settings['style'] == 'home_banner1' ) {
			include deskly_get_template('/home-banner/home-banner1.php');
		}
	}
}
