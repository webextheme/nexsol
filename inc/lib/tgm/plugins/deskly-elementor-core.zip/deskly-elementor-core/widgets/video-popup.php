<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;

class DESKLY_Video_Popup extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-video-popup';
	}

	public function get_title() {
		return esc_html__( 'Video Popup', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'video_popup_styles',
			[
				'label' => __( 'Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'deskly-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'video_title',
			[
				'label'       => __( 'Place Title Here', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Title', 'deskly-elementor-core' ),
				'default'	=> esc_html__('Watch Video', 'deskly-elementor-core')
			]
		);
		$this->add_control(
			'video_title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h5',
				'options' 	=> [
					'h1' 	=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 	=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 	=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'	=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 	=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 	=> esc_html__('h6', 'deskly-elementor-core'),
					'div' 	=> esc_html__('div', 'deskly-elementor-core'),
					'span' 	=> esc_html__('span', 'deskly-elementor-core'),
				]
			]
		);
		$this->add_control(
			'video_popup_rotate_image',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Rotate Image?', 'deskly-elementor-core' ),
				'label_on' => esc_html__( 'Yes', 'deskly-elementor-core' ),
				'label_off' => esc_html__( 'No', 'deskly-elementor-core' ),
				'return_value' => 'rotateme',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'video_bg_image',
			[
				'label' 	=> esc_html__( 'Video Image', 'deskly-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'video_bg_image_size',
				'default'   => 'full',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_control(
			'video_url',
			[
				'label' 		=> esc_html__( 'Video URL', 'deskly-elementor-core' ),
				'type' 			=> \Elementor\Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'deskly-elementor-core' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> 'https://www.youtube.com/watch?v=a1hEY3Ii70I',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/


		/*===================================
		Start Content Style
		=====================================*/
		$this->start_controls_section(
			'video_popup_content_style',
			[
				'label' => esc_html__( 'Content Style', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'video_popup_content_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-popup-item' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'video_popup_content_border_normal',
				'selector' => '{{WRAPPER}} .video-popup-item',
			]
		);
		$this->add_responsive_control(
			'video_image_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .image-video-block img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .video-block .video-link a i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .video-block .video-link a i:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .video-popup-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'content_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .video-popup-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Style
		=====================================*/




		/*===================================
		Start Video Icon Style
		=====================================*/
		$this->start_controls_section(
			'icon_style',
			[
				'label' 	=> esc_html__( 'Icon Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'video_popup_size',
			[
				'label' => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .video-block .video-link a i' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .image-video-block .video-link a i' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .video-popup-item .video-link a i' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'video_popup_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-block .video-link a i, {{WRAPPER}} .video-block .video-link a i::after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .image-video-block .video-link a i, {{WRAPPER}} .image-video-block .video-link a i::after' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_normal_border',
				'selector' => '{{WRAPPER}} .video-block .video-link a i, {{WRAPPER}} .video-block .video-link a i::after, {{WRAPPER}} .video-popup-item .video-link',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_normal_border2',
				'selector' => '{{WRAPPER}} .image-video-block .video-link a i',
				'condition'   => [
					'video_popup_styles' => 'style_2',
				],
			]
		);
		$this->add_responsive_control(
			'item_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .video-block .video-link a i, {{WRAPPER}} .video-block .video-link a i::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

					'{{WRAPPER}} .image-video-block .video-link a i, {{WRAPPER}} .image-video-block .video-link a i::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

					'{{WRAPPER}} .video-popup-item .video-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .video-popup-item .video-link img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'video_popup_typography',
				'selector' 	=> '{{WRAPPER}} .video-block .video-link a i::before, {{WRAPPER}} .video-popup-item .video-link a i',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'video_popup_typography2',
				'condition'   => [
					'video_popup_styles' => 'style_2',
				],
				'selector' 	=> '{{WRAPPER}} .image-video-block .video-link a i::before',
			]
		);
		$this->add_responsive_control(
			'video_popup_icon_color',
			[
				'label' 	=> esc_html__( 'Icon Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-block .video-link a i::before' => 'color: {{VALUE}}',
					'{{WRAPPER}} .image-video-block .video-link a i::before' => 'color: {{VALUE}}',
					'{{WRAPPER}} .video-popup-item .video-link a i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'video_alignments',
			[
				'label' => __('Alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .video-block-wrapper ' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Experience Text Style
		=====================================*/





		/*===================================
		Start Video Title Style
		=====================================*/
		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> esc_html__( 'Title Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'text_typography',
				'selector' 	=> '{{WRAPPER}} .video-popup-item .video-title',
			]
		);
		$this->add_control(
			'text_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-popup-item .video-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'text_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .video-popup-item .video-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'text_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .video-popup-item .video-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Experience Text Style
		=====================================*/

	}

	protected function render() {
		$settings   = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html( 'post' );
		$video_title 			= $settings['video_title'];
		$video_url  = ! empty( $settings['video_url']['url'] ) ? esc_url( $settings['video_url']['url'] ) : '';

		$video_bg_image = '';
		if ( ! empty( $settings['video_bg_image']['url'] ) ) {
			if ( ! empty( $settings['video_bg_image']['id'] ) ) {
				$video_bg_image = Group_Control_Image_Size::get_attachment_image_src(
					$settings['video_bg_image']['id'],
					'video_bg_image_size',
					$settings
				);
			} else {
				$video_bg_image = esc_url( $settings['video_bg_image']['url'] );
			}
		}

		switch ( $settings['video_popup_styles'] ) {
			case 'style_1':
				include deskly_get_template( '/video-popup/style1.php' );
				break;

			case 'style_2':
				include deskly_get_template( '/video-popup/style2.php' );
				break;

			case 'style_3':
				include deskly_get_template( '/video-popup/style3.php' );
				break;
		}
	}

}
