<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Mobile_Menu extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-mobile-menu';
	}

	public function get_title() {
		return esc_html__( 'Mobile Menu', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_responsive_control(
			'mobile_menu_normal_margin',
			[
				'label'      => esc_html__( 'Search Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .mobile-nav-toggler-ele' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'mobile_menu_normal_padding',
			[
				'label'      => esc_html__( 'Search Padding', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .mobile-nav-toggler-ele' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .mobile-nav-toggler-ele',
			]
		);
		$this->add_responsive_control(
			'line_gap',
		[
			'label' => esc_html__('Line Gap', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'default' => [
				'unit' => 'px',
			],
			'size_units' => ['px'],
			'range' => [
				'%' => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				'vw' => [
					'min' => 1,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .mobile-nav-toggler-ele' => 'gap: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_responsive_control(
			'line_height',
		[
			'label' => esc_html__('Line Height', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'default' => [
				'unit' => 'px',
			],
			'size_units' => ['px'],
			'range' => [
				'%' => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				'vw' => [
					'min' => 1,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .mobile-nav-toggler-ele span' => 'height: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_responsive_control(
			'line_width',
		[
			'label' => esc_html__('Line Width', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'default' => [
				'unit' => 'px',
			],
			'size_units' => ['px'],
			'range' => [
				'%' => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				'vw' => [
					'min' => 1,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .mobile-nav-toggler-ele span' => 'width: {{SIZE}}{{UNIT}};',
			],
		]);
		$this->add_control(
			'mobile_menu_normal_bg_color',
			[
				'label'     => esc_html__( 'Bg Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .mobile-nav-toggler-ele span' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/


	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$top_header_one_left = deskly_options('top_header_one_left');
		$top_header_one_left2 = deskly_options('top_header_one_left2');
		$deskly_enable_mobile_menu_sidebar_social = deskly_options('deskly_enable_mobile_menu_sidebar_social');
		$deskly_social_icons = deskly_options('deskly_social_icons');
		$mobile_menu_sidebar_logo = deskly_options('mobile_menu_sidebar_logo');
		?>

		<div class="mobile-nav-wrapper">
			<div class="mobile-nav-overlay mobile-nav-toggler"></div>
			<div class="mobile-nav-content">
				<a href="#" aria-label="Mobile Nav" class="mobile-nav-close mobile-nav-toggler">
					<span></span>
					<span></span>
				</a>
				<div class="mobile-menu-sidebar-logo logo-box">
					<a href="<?php echo esc_url(home_url('/')); ?>">
						<?php if(isset($mobile_menu_sidebar_logo['url']) && $mobile_menu_sidebar_logo['url'] != ''){?>
							<img id="side-logo-image" class="img-center" src="<?php echo esc_url($mobile_menu_sidebar_logo['url']); ?>" alt="<?php echo esc_attr(get_bloginfo());?>">
						<?php }else{ ?>
							<img src="<?php echo esc_url(get_template_directory_uri()) . '/assets/images/logo-light.png' ?>" width="165" height="72" alt="<?php echo esc_attr(get_bloginfo());?>">
						<?php } ?>
					</a>
				</div>
				<div class="mobile-nav-container"></div>
					<ul class="list-items mobile-sidebar-contact">
						<?php if (is_array($top_header_one_left)): ?>
							<?php foreach ($top_header_one_left as $top_header_left): ?>
								<li><span class="<?php echo esc_attr($top_header_left['header_one_left_icon']);?> mrr-10 text-webex-primary-color"></span><a href="<?php echo esc_url($top_header_left['header_one_left_url']); ?>"><?php echo esc_html($top_header_left['header_one_left_text']); ?></a></li>
							<?php endforeach; ?>
						<?php endif; ?>
					</ul>

				<?php if($deskly_enable_mobile_menu_sidebar_social == true) : ?>
					<?php if(!empty($top_header_one_left2)):?>
					<ul class="social-list list-webex-primary-color">
						<?php if (is_array($top_header_one_left2)): ?>
							<?php foreach ($top_header_one_left2 as $top_header_left2): ?>
								<li><a class="<?php echo esc_attr($top_header_left2['header_one_left_icon2']);?>" href="<?php echo esc_url($top_header_left2['header_one_left_url2']); ?>"></a></li>
							<?php endforeach; ?>
						<?php endif; ?>
					</ul>
					<?php endif;?>
				<?php endif; ?>

			</div>
		</div>

		<a href="#" aria-label="Mobile Nav" class="mobile-nav-toggler-ele">
			<span></span>
			<span></span>
			<span></span>
		</a>
		<?php
	}
}
