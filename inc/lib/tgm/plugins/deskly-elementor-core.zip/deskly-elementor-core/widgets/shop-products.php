<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;
use WP_Query;

class DESKLY_Products extends \Elementor\Widget_Base {

	public function get_name() {
		return  'products-block';
	}

	public function get_title() {
		return esc_html__( 'Products', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return array('allslider-js');
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Product Content ===== */
		$this->start_controls_section(
			'section_content_item',
			[
				'label' => esc_html__( 'Products', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_styles',
			[
				'label' => __( 'Product Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'product_gradient_styles',
			[
				'label' => __( 'Color Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'color_style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
					'color_style_2' => esc_html__( 'Style 02', 'deskly-elementor-core' ),
				],
				'default' => 'color_style_1'
			]
		);
		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Layout', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid'   => esc_html__( 'Grid', 'deskly-elementor-core' ),
					'slider' => esc_html__( 'Slider', 'deskly-elementor-core' ),
				],
			]
		);
		$this->add_responsive_control(
			'column',
			[
				'label'                => esc_html__( 'Grid Column', 'deskly-elementor-core' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					''  => esc_html__( 'Default', 'deskly-elementor-core' ),
					'1' => esc_html__( '1 column', 'deskly-elementor-core' ),
					'2' => esc_html__( '2 column', 'deskly-elementor-core' ),
					'3' => esc_html__( '3 column', 'deskly-elementor-core' ),
					'4' => esc_html__( '4 column', 'deskly-elementor-core' ),
					'5' => esc_html__( '5 column', 'deskly-elementor-core' ),
					'6' => esc_html__( '6 column', 'deskly-elementor-core' ),
				],
				'default'              => 4,
				'tablet_extra_default' => '',
				'tablet_default'       => '',
				'mobile_default'       => '',
				'condition'            => [
					'layout' => 'grid',
				],
				'selectors'            => [
					'{{WRAPPER}} .product-block-wrapper' => 'grid-template-columns: repeat( {{VALUE}}, 1fr );',
				],
			]
		);
		$this->add_control(
			'item_number',
			[
				'label'       => esc_html__( 'Item Number', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'description' => esc_html__( 'Number Item', 'deskly-elementor-core' ),
				'default'     => 4,
				'options'   => array(1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6),
				'condition'            => [
					'layout' => 'slider',
				],
			]
		);
		$this->add_control(
			'product_image',
			[
				 'label'     => __('Image Size', 'deskly-elementor-core'),
				 'type'      => \Elementor\Controls_Manager::SELECT,
				 'options'   => get_thumbnail_size(),
				 'default'   => 'deskly-image(315x375)'
			]
		);
    $this->add_control(
			'product_ratings_show_hide',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => esc_html__( 'Show Ratings?', 'deskly-elementor-core' ),
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'deskly-elementor-core' ),
				'label_on'  => esc_html__( 'Show', 'deskly-elementor-core' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'product_short_text_show_hide',
			[
				'label'        => esc_html__( 'Show Excerpt?', 'deskly-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'deskly-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'deskly-elementor-core' ),
				'default'      => 'yes',
				'separator' => 'before',
			]
		);
		$this->add_control(
			'excerpt_count',
			[
				'label'     => esc_html__( 'Excerpt Word', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 12,
				'condition' => [
					'product_short_text_show_hide' => 'yes',
				],
			]
		);
		$this->end_controls_section();





		$this->start_controls_section('query_content', [
			'label' => esc_html__('Products Query', 'deskly-elementor-core'),
		]);
		$this->add_control('post_from', [
			'label' => esc_html__('Product From', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'all' => esc_html__('All Product', 'deskly-elementor-core'),
				'categories' => esc_html__('Categories', 'deskly-elementor-core'),
				'specific-post' => esc_html__('Specific Product', 'deskly-elementor-core'),
			],
			'default' => 'all',
		]);
		$this->add_control('post_ids', [
			'label' => esc_html__('Select Product', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT2,
			'options' => deskly_select_posts('product'),
			'multiple' => true,
			'label_block' => true,
			'condition' => [
				'post_from' => 'specific-post',
			],
		]);
		$this->add_control('cat_slugs', [
			'label' => esc_html__('Select Categories', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT2,
			'options' => deskly_select_category('product_cat'),
			'multiple' => true,
			'label_block' => true,
			'condition' => [
				'post_from' => 'categories',
			],
		]);
		$this->add_control('post_limit', [
			'label' => esc_html__('Item Show Per Page', 'deskly-elementor-core'),
			'type' => Controls_Manager::NUMBER,
			'default' => 4,
			'min' => 1,
		]);
		$this->add_control('order_by', [
			'label' => esc_html__('Order By', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'ID' => esc_html__('ID', 'deskly-elementor-core'),
				'author' => esc_html__('Author', 'deskly-elementor-core'),
				'title' => esc_html__('Title', 'deskly-elementor-core'),
				'date' => esc_html__('Date', 'deskly-elementor-core'),
				'rand' => esc_html__('Random', 'deskly-elementor-core'),
			],
			'default' => 'date',
		]);
		$this->add_control('sort_order', [
			'label' => esc_html__('Sort Order', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'ASC' => esc_html__('Ascending', 'deskly-elementor-core'),
				'DESC' => esc_html__('Descending', 'deskly-elementor-core'),
			],
			'default' => 'DESC',
		]);
		$this->end_controls_section();
		/* ===== End Product Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'product_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .product-block-wrapper' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .product-block-wrapper' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'grid',
				],
			]
		);
		$this->start_controls_tabs( 'product_item_tab' );
		$this->start_controls_tab(
			'product_item_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'item_box_shadow',
			'selector' => '{{WRAPPER}} .product-block, {{WRAPPER}} .product-block .product-item-thumb',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_normal_border',
				'selector' => '{{WRAPPER}} .product-block, {{WRAPPER}} .product-block .product-item-thumb',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'product_item_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_hover_shadow',
				'selectors' => [
					'{{WRAPPER}} .product-block:hover, {{WRAPPER}} .product-block:hover .product-item-thumb' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_box_hover_border',
				'selector' => '{{WRAPPER}} .product-block:hover, {{WRAPPER}} .product-block:hover .product-item-thumb',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'item_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-block:hover, {{WRAPPER}} .product-block .product-item-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */






		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'product_title_style',
			[
				'label' => esc_html__( 'Title Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'product_title_tabs' );
		$this->start_controls_tab(
			'product_title_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .product-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'product_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .product-title',
			]
		);
		$this->add_responsive_control(
			'product_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'product_title_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-title:hover' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .product-title a:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'product_title_hover_typography',
				'selector' 	=> '{{WRAPPER}} .product-title:hover',
			]
		);
		$this->add_responsive_control(
			'product_title_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_title_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'product_block_hover',
			[
				'label' => esc_html__( 'Block Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_title_block_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-block:hover .product-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .product-block:hover .product-title a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Category Style ===== */
		$this->start_controls_section(
			'product_category_style',
			[
				'label' => esc_html__( 'Category Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'product_category_tabs' );
		$this->start_controls_tab(
			'product_category_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_category_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-category a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'product_category_normal_typography',
				'selector' 	=> '{{WRAPPER}} .product-category a',
			]
		);
		$this->add_responsive_control(
			'product_category_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-category a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_category_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-category a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'product_category_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_category_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-category a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'product_category_hover_typography',
				'selector' 	=> '{{WRAPPER}} .product-category a:hover',
			]
		);
		$this->add_responsive_control(
			'product_category_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-category a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_category_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-category a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Category Style ===== */






		/* ===== Begin Button Style ===== */
		$this->start_controls_section(
			'product_button_style',
			[
				'label' => esc_html__( 'Button Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'product_button_top_bottom',
			[
				'label' => esc_html__( 'Button Top/Bottom Movement', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -800,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .product-link-icon a' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_button_left_right',
			[
				'label' => esc_html__( 'Button Left/Right Movement', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -800,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .product-link-icon a' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_button_size',
			[
				'label'      => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => .1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .product-link-icon a' => 'transform: scale({{SIZE}});',
				],
			]
		);
		$this->add_responsive_control(
			'product_button_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .product-link-icon a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'product_button_tabs' );
		$this->start_controls_tab(
			'product_button_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-link-icon a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'product_button_normal_typography',
				'selector' 	=> '{{WRAPPER}} .product-link-icon a',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'product_button_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'product_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-link-icon a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'product_button_hover_typography',
				'selector' 	=> '{{WRAPPER}} .product-link-icon a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Button Style ===== */






		/* ===== Begin Carousel Options ===== */
		webex_get_elementor_carousel_options($this);
		/* ===== End Carousel Options ===== */

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$data_options['items'] 				= $settings['item_number'];
		$data_options['items_lg'] 				= $settings['items_lg'];
		$data_options['items_md'] 				= $settings['items_md'];
		$data_options['items_sm'] 				= $settings['items_sm'];
		$data_options['items_xs'] 				= $settings['items_xs'];


		$data_options['margin']             = $settings['margin_items'];
		$data_options['loop']               = $settings['infinite'] === 'yes' ? true : false;
		$data_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$data_options['nav']               = $settings['nav_control'] === 'yes' ? true : false;
		$data_options['dots']               = $settings['dot_control'] === 'yes' ? true : false;
		$data_options['center']				= $settings['center_mode'] === 'yes' ? true : false;
		$data_options['rtl']				= is_rtl() ? true: false;


		$this->add_render_attribute( 'wrapper', 'class', 'product-block-wrapper' );
		if( 'slider' == $settings['layout'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'deskly-slider-wrapper' );
		}

		?>
		<div id="product-block-<?php echo esc_attr( $settings['product_styles'] ) ?>" <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >
			<?php if( 'grid' == $settings['layout'] ) : ?>
				<?php $this->render_loop( $settings );?>
				<?php elseif( 'slider' == $settings['layout'] ) : ?>
				<div class="webex-slider">
					<div class="owl-carousel webex-carousel" data-options="<?php echo esc_attr(json_encode($data_options)); ?>">
							<?php $this->render_loop( $settings );?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function render_loop( $settings ) {
		$args = [
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'posts_per_page'      => $settings['post_limit'],
			'orderby'             => $settings['order_by'],
			'order'               => $settings['sort_order'],
			'thumbnail_size'  		=> $settings['product_image'],
			'ignore_sticky_posts' => 1,
		];

		if ( 'categories' == $settings['post_from'] && $settings['cat_slugs'] ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => $settings['cat_slugs'],
          'include_children' => true,
				],
			];
		}

		if ( 'specific-post' == $settings['post_from'] && $settings['post_ids'] ) {
			$args['post__in'] = $settings['post_ids'];
		}

		$wp_query = new WP_Query( $args );
		while ( $wp_query->have_posts() ): $wp_query->the_post();
			if ( 'grid' == $settings['layout'] ) :
				self::render_product_item( $settings );
			elseif( 'slider' == $settings['layout'] ) : ?>

			<div class="deskly-slider-item">
				<?php self::render_product_item( $settings ); ?>

			</div>
			<?php endif;
		endwhile;
		wp_reset_postdata();
	}

	public static function render_product_item( $settings ) {
    global $product;
		$get_id             = get_the_ID();
		$categories_list = get_the_term_list( $get_id, 'cat_slugs', '', '', '' );
		$the_title = get_the_title();
		$excerpt_count = $settings['excerpt_count'];

		if ( $settings['product_styles'] == 'style_1' ) {
			include deskly_get_template('/products/style1.php');
		}
	}
}
