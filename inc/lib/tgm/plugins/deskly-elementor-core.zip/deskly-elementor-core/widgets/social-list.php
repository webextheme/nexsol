<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
use Elementor\Utils;

class DESKLY_Social_List extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-social-list';
	}

	public function get_title() {
		return esc_html__( 'Social List', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Acordion Content ===== */
		$this->start_controls_section(
			'section_content_acordions',
			[
				'label' => esc_html__( 'Social List', 'deskly-elementor-core' ),
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'deskly_icons',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'base-icon-avatar',
					'library' => 'deskly-flaticon',
				],
			]
		);

		$repeater->add_control(
			'title_link',
			[
				'label' => esc_html__( 'Title Link URL', 'deskly-elementor-core' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
				],
			]
		);

		$this->add_control(
			'social_list_items',
			[
				'label'   => esc_html__( 'Social Items', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'deskly_icons' => [
							'value' => 'webexbase-icon-facebook-f',
							'library' => 'fa-brands',
						],
						'title_link' => [
							'url' => '#',
						],
					],
					[
						'deskly_icons' => [
							'value' => 'webexbase-icon-twitter-2',
							'library' => 'fa-brands',
						],
						'title_link' => [
							'url' => '#',
						],
					],
					[
						'deskly_icons' => [
							'value' => 'webexbase-icon-linkedin2',
							'library' => 'fa-brands',
						],
						'title_link' => [
							'url' => '#',
						],
					],
				],
				'title_field' => '<i class="{{ deskly_icons.value }}"></i> {{ deskly_icons.value }}', // <-- Add this line
			]
		);
		$this->end_controls_section();
		/* ===== End Team Items Content ===== */


		/*===================================
		Start Icon  Style
		=====================================*/
		$this->start_controls_section(
			'contact_info_icon_style',
			[
				'label' => esc_html__( 'Icon Styling', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'icon_display',
			[
				'label'     => esc_html__( 'Icon Display', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'row'   => [
						'title' => esc_html__( 'Row', 'deskly-elementor-core' ),
						'icon'  => 'eicon-ellipsis-h',
					],
					'column' => [
						'title' => esc_html__( 'Column', 'deskly-elementor-core' ),
						'icon'  => 'eicon-ellipsis-v',
					],
				],
				'default' => 'row',
				'selectors' => [
					'{{WRAPPER}} .widget-social-list' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_alignment_row',
			[
				'label'     => esc_html__( 'Icon Alignment (Row)', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'deskly-elementor-core' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'deskly-elementor-core' ),
						'icon'  => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'deskly-elementor-core' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .widget-social-list' => 'justify-content: {{VALUE}};',
				],
				'condition' => [
					'icon_display' => 'row',
				],
			]
		);

		$this->add_control(
			'icon_alignment_column',
			[
				'label'     => esc_html__( 'Icon Alignment (Column)', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'deskly-elementor-core' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'deskly-elementor-core' ),
						'icon'  => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Bottom', 'deskly-elementor-core' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .widget-social-list' => 'align-items: {{VALUE}};',
				],
				'condition' => [
					'icon_display' => 'column',
				],
			]
		);
		$this->add_control(
			'icon_gap',
			[
				'label' => esc_html__( 'Spacing', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .widget-social-list' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'selector' => '{{WRAPPER}} .widget-social-list li a',
			]
		);
		$this->add_control(
			'icon_bg_size',
			[
				'label' => esc_html__( 'Background Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 300,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .widget-social-list li a' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'icon-tabs' );
		$this->start_controls_tab(
			'icon_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .widget-social-list li a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .widget-social-list li a' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'social_icon_border',
				'selector' => '{{WRAPPER}} .widget-social-list li a',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_hover_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .widget-social-list li a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .widget-social-list li a:hover' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'social_icon_border_hover',
				'selector' => '{{WRAPPER}} .widget-social-list li a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'icon_margin',
			[
				'label' => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .widget-social-list li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'contact_info_icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .widget-social-list li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Icon  Style
		=====================================*/




}

protected function render() {
	$settings = $this->get_settings_for_display();
	?>

	<div class="social-list-block">
		<?php if ( ! empty( $settings['social_list_items'] ) ) : ?>
		<ul class="widget-social-list">
			<?php foreach ( $settings['social_list_items'] as $item ) :
				$link = ! empty( $item['title_link']['url'] ) ? $item['title_link']['url'] : '#';
				$is_external = ! empty( $item['title_link']['is_external'] ) ? ' target="_blank" rel="noopener"' : '';
			?>
				<li>
					<a href="<?php echo esc_url( $link ); ?>"<?php echo $is_external; ?>>
						<?php if ( ! empty( $item['deskly_icons']['value'] ) ) : ?>
							<i class="<?php echo esc_attr( $item['deskly_icons']['value'] ); ?>"></i>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	</div>

	<?php
	}
}
