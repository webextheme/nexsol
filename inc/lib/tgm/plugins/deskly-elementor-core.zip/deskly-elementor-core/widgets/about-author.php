<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;

class DESKLY_About_Author extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-about-author';
	}

	public function get_title() {
		return esc_html__( 'About Author', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'about_author_styles',
			[
				'label' => __( 'Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'author_image_show_hide',
			[
				'label'        => esc_html__( 'Show Author Image?', 'deskly-elementor-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Hide', 'deskly-elementor-core' ),
				'label_on'     => esc_html__( 'Show', 'deskly-elementor-core' ),
				'default'      => 'yes',
			]
		);
		$this->add_control(
			'about_author_s1_image',
			[
				'label' 	=> esc_html__( 'Author Image', 'deskly-elementor-core' ),
				'type' 		=> \Elementor\Controls_Manager::MEDIA,
				'default' 	=> [
					'url' 		=> \Elementor\Utils::get_placeholder_image_src(),
				],
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'about_author_s1_image',
				'default'   => 'deskly-image(72x72)',
				'separator' => 'none',
				'exclude'   => [
					'custom',
				],
			]
		);
		$this->add_responsive_control(
			'about_author_s1_image_width',
			[
				'label' => esc_html__( 'Image Width', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 170,
						'max' => 800,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-author-block .author-thumb img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'about_author_s1_image_spacing',
			[
				'label' => esc_html__( 'Image Spacing', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .about-author-block .author-content' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'author_name',
			[
				'label'       => __( 'Author Name', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter Author Name', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'author_designation',
			[
				'label'       => __( 'Author Designation', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter Author Designation', 'deskly-elementor-core' ),
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/





		/*===================================
		Start Title Style
		=====================================*/
		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> esc_html__( 'Author Name Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'selector' 	=> '{{WRAPPER}} .about-author-block .author-name',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about-author-block .author-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-author-block .author-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-author-block .author-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Title Style
		=====================================*/






		/*===================================
		Start Designation Style
		=====================================*/
		$this->start_controls_section(
			'designation_style',
			[
				'label' 	=> esc_html__( 'Author Designation Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'designation_typography',
				'selector' 	=> '{{WRAPPER}} .about-author-block .author-designation',
			]
		);
		$this->add_control(
			'designation_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about-author-block .author-designation' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'designation_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-author-block .author-designation' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'designation_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .about-author-block .author-designation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Title Style
		=====================================*/




	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$author_name 			= $settings['author_name'];
		$author_designation 		= $settings['author_designation'];

		if ( $settings['about_author_styles'] == 'style_1' ) {
			// About Author Style1 Images
			if ( empty( $settings['about_author_s1_image']['id'] && !empty( $settings['about_author_s1_image']['url'] ) ) ) {
				$about_author_s1_image_url = $settings['about_author_s1_image']['url'];
			} else {
				$about_author_s1_image_url = Group_Control_Image_Size::get_attachment_image_src( $settings['about_author_s1_image']['id'], 'about_author_s1_image', $settings );
			}
			include deskly_get_template('/about-author/style1.php');
		}

	}
}
