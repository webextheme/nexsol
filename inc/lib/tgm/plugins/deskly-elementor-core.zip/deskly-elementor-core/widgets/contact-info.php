<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Contact_Info extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-contact-info';
	}

	public function get_title() {
		return esc_html__( 'Contact Info', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Choose Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'contact_info_title',
			[
				'label' => esc_html__( 'Title', 'deskly-elementor-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Title Here', 'deskly-elementor-core'),
			]
		);
		$this->add_responsive_control(
			'contact_info_align',
			[
				'label' => __('Box alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info  ' => 'justify-content: {{VALUE}}!important;',
				],
			]
		);
		$this->add_responsive_control(
			'contact_info_text_alignments',
			[
				'label' => __('Text alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'deskly-elementor-core' ),
						'icon' 	=> 'eicon-text-align-justify',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'type',
			[
				'label' => esc_html__( 'Type', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'email',
				'options' => [
					'email' => esc_html__('Email', 'deskly-elementor-core'),
					'phone' => esc_html__('Phone', 'deskly-elementor-core'),
					'link' => esc_html__('Link', 'deskly-elementor-core'),
					'text' => esc_html__('Text', 'deskly-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'email_label',
			[
				'label'   => esc_html__( 'Email Label', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'description' => esc_html__( 'email@company.com', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'email',
				]

			]
		);
		$repeater->add_control(
			'email_address',
			[
				'label'   => esc_html__( 'Email Adress', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'description' => esc_html__( 'email@company.com', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'email',
				]

			]
		);
		$repeater->add_control(
			'phone_label',
			[
				'label'   => esc_html__( 'Phone Label', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'description' => esc_html__( '+012 (345) 678', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'phone',
				]

			]
		);
		$repeater->add_control(
			'phone_address',
			[
				'label'   => esc_html__( 'Phone Adress', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'description' => esc_html__( '+012345678', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'phone',
				]

			]
		);
		$repeater->add_control(
			'link_label',
			[
				'label'   => esc_html__( 'Link Label', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'description' => esc_html__( 'https://your-domain.com', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'link',
				]

			]
		);
		$repeater->add_control(
			'link_address',
			[
				'label'   => esc_html__( 'Link Adress', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::URL,
				'description' => esc_html__( 'https://your-domain.com', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'link',
				],
				'show_external' => false,
				'default' => [
					'url' => '#',
					'is_external' => false,
					'nofollow' => false,
				],

			]
		);
		$repeater->add_control(
			'text',
			[
				'label'   => esc_html__( 'Text', 'deskly-elementor-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'description' => esc_html__( 'Your text', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'text',
				]

			]
		);
		$this->add_control(
			'items_info',
			[
				'label'       => esc_html__( 'Items Info', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default' => [
					[
						'type' => 'email',
						'email_label' => esc_html__('email@company.com', 'deskly-elementor-core'),
						'email_address' => esc_html__('email@company.com', 'deskly-elementor-core'),
					],

				],
				'title_field' => '{{{ type }}}',
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/

		/*===================================
		Start Icon  Style
		=====================================*/
		$this->start_controls_section(
			'contact_info_icon_style',
			[
				'label' => esc_html__( 'Icon Styling', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'icon_font_size',
			[
				'label' => esc_html__( 'Font Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'icon_bg_size',
			[
				'label' => esc_html__( 'Background Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 300,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'icon-tabs' );
		$this->start_controls_tab(
			'icon_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .icon' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .icon' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_hover_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info:hover .icon' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info:hover .icon' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'icon_margin',
			[
				'label' => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .icon, {{WRAPPER}} .deskly-contact-info .circle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'contact_info_icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .deskly-contact-info .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Icon  Style
		=====================================*/




		/*===================================
		Start Title  Style
		=====================================*/

		$this->start_controls_section(
			'contact_info_title_style',
			[
				'label' => esc_html__( 'Title Styling', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .contact .label' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .deskly-contact-info .contact .label',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .contact .label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Title  Style
		=====================================*/



		/*===================================
		Start Content  Style
		=====================================*/
		$this->start_controls_section(
			'contact_info_content_style',
			[
				'label' => esc_html__( 'Content Styling', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .contact .info .item' => 'color : {{VALUE}};',
					'{{WRAPPER}} .deskly-contact-info .contact .info .item a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_color_hover',
			[
				'label' => esc_html__( 'Link Color hover', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .contact .info .item a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .deskly-contact-info .contact .info .item, {{WRAPPER}} .deskly-contact-info .contact .info .item a',
			]
		);

		$this->add_responsive_control(
			'content_margin',
			[
				'label' => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .deskly-contact-info .contact .info .item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content  Style
		=====================================*/
	}

	private function style_tab() {
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$label      = $settings['contact_info_title'] ? $settings['contact_info_title'] : '';
		$icon       = $settings['icon']['value'];
		$items_info = $settings['items_info'];
	?>

	<div class="deskly-contact-info">
	<?php if ( !empty($icon) ): ?>
		<div class="icon">
			<i class="<?php echo esc_attr( $icon ); ?>"></i>
		</div>
	<?php endif; ?>

	<div class="contact">
		<?php if( $label ){ ?>
			<div class="label">
				<?php echo esc_html( $label ); ?>
			</div>
		<?php } ?>

		<ul class="info">
			<?php foreach( $items_info as $item ):
				$type 	= $item['type'];
				?>
				<li class="item">
					<?php switch ( $type ) {
						case 'email':
							$email_address = $item['email_address'];
							$email_label = $item['email_label'];
							if( $email_address && $email_label ){
							?>
								<a href="mailto:<?php echo esc_attr( $email_address ) ?> " title="<?php esc_attr_e( 'address', 'deskly-elementor-core' ); ?>">
									<?php echo esc_html( $email_label ); ?>
								</a>
							<?php
						}
						break;
						case 'phone':
							$phone_address = $item['phone_address'];
							$phone_label = $item['phone_label'];
							if( $phone_address && $phone_label ){
							?>
								<a href="tel:<?php echo esc_attr( $phone_address ) ?> " title="<?php esc_attr_e( 'address', 'deskly-elementor-core' ); ?>">
									<?php echo esc_html( $phone_label ); ?>
								</a>
							<?php
							}
						break;
						case 'link':
							$this->add_render_attribute( 'title' );

							$link_address = $item['link_address']['url'];
							$link_label = $item['link_label'];
							$title = $item['link_label'] ? $item['link_label'] : '';
							if ( ! empty( $item['link_address']['url'] ) ) {
								$this->add_link_attributes( 'url', $item['link_address'] );
								echo sprintf( '<a %1$s title="%2$s">%3$s</a>', $this->get_render_attribute_string( 'url' ), esc_attr( $title ), esc_html( $title ) );

							}
							else{
								echo esc_html( $title );
							}
						break;
						case 'text':
							$text = $item['text'];
							?>
								<?php echo esc_html( $text ); ?>
							<?php
						break;
						default:
						break;
					} ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	</div>
	<?php
	}

}
