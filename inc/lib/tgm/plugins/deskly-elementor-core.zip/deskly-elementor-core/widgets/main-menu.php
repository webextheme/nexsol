<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class DESKLY_Main_Menu extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-main-menu';
	}

	public function get_title() {
		return esc_html__( 'Main Menu', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {
		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'section_menu_type',
			[
				'label' => esc_html__( 'Custom Menu', 'deskly-elementor-core' ),
			]
		);

		$this->add_control(
			'menu_type',
			[
				'label'   => esc_html__( 'Menu', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'theme-default' => esc_html__( 'Theme Default', 'deskly-elementor-core' ),
					'custom'        => esc_html__( 'Custom Menu', 'deskly-elementor-core' ),
				],
				'default' => 'theme-default',
			]
		);

		$this->add_control(
			'selected_menu',
			[
				'label'     => esc_html__( 'Select Menu', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_menus_list(),
				'condition' => [
					'menu_type' => 'custom',
				],
			]
		);

		$this->add_control(
			'menu_alignment',
			[
				'label'       => esc_html__( 'Menu Alignment', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'deskly-elementor-core' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'deskly-elementor-core' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'deskly-elementor-core' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'     => 'center',
				'toggle'      => false,
				'separator'   => 'before',
			]
		);
		$this->add_responsive_control(
			'menu_height',
			[
				'label'       => esc_html__( 'Menu Height', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'label_block' => false,
				'selectors'   => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li' => 'height: {{VALUE}}px;'
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/

		/*===================================
		Start Content Styling
		=====================================*/
		$this->start_controls_section(
			'menu_styles',
			[
				'label' => esc_html__( 'Menu Items', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'menu_item_margin',
			[
				'label'      => esc_html__( 'Menu Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'menu_item_padding',
			[
				'label'      => esc_html__( 'Menu Padding', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'main-menu-tabs' );
		$this->start_controls_tab(
			'main_menu_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'main_menu_normal_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'main_menu_typography',
				'selector' => '{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > a',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'main_menu_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'main_menu_hover_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li:hover > a' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'main_menu_hover_typography',
				'selector' => '{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li:hover > a',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'main_menu_current',
			[
				'label' => esc_html__( 'Current', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'main_menu_current_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li.current_page_item > a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > ul > li.current-menu-item > a' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'main_menu_current_typography',
				'selector' => '{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li.current_page_item > a',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Content Styling
		=====================================*/

		/*===================================
		Start Content Styling
		=====================================*/
		$this->start_controls_section(
			'submenu_styles',
			[
				'label' => esc_html__( 'Sub Menu Items', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'submenu-tabs' );
		$this->start_controls_tab(
			'submenu_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'submenu_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > ul' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'submenu_normal_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > ul > li > a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'submenu_normal_typography',
				'selector' => '{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > ul > li > a',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'submenu_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'submenu_hover_item_bg_color',
			[
				'label'     => esc_html__( 'Item Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > ul > li > a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'submenu_hover_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > ul > li > a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'submenu_hover_typography',
				'selector' => '{{WRAPPER}} .webex_main-menu .main-menu-inner .main-nav-menu > li > ul > li > a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Content Styling
		=====================================*/
	}

	protected function render() {
		$settings = $this->get_settings_for_display();?>
		<nav class="webex_main-menu">
			<?php
			$args = [
				'container'       => 'div',
				'container_class' => 'main-menu-inner menu-' . $settings['menu_alignment'],
				'menu_class'      => 'main-nav-menu',
				'after'           => '',
				'link_before'     => '<span class="link-text">',
				'link_after'      => '</span>',
				'fallback_cb'     => false,
			];
			if ( 'custom' == $settings['menu_type'] && ! empty( $settings['selected_menu'] ) ) {
				$args['menu'] = $settings['selected_menu'];
			} elseif ( has_nav_menu( 'primary' ) ) {
				$args['theme_location'] = 'primary';
			}
			?>
			<?php wp_nav_menu( $args );?>
		</nav>
	<?php
	}
	protected function get_menus_list() {
		$nav_menus = [];
		$terms     = get_terms( 'nav_menu' );
		foreach ( $terms as $term ) {
			$nav_menus[$term->name] = $term->name;
		}
		return $nav_menus;
	}
}

