<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class DESKLY_Section_Title extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-section-title';
	}

	public function get_title() {
		return esc_html__( 'Section Title', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'heading_styles',
			[
				'label' => __( 'Heading Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'deskly-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'deskly-elementor-core' ),
					'style_4' => esc_html__( 'Style 04', 'deskly-elementor-core' ),
					'style_5' => esc_html__( 'Style 05', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'heading_gradient_styles',
			[
				'label' => __( 'Color Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'color_style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
					'color_style_2' => esc_html__( 'Style 02', 'deskly-elementor-core' ),
				],
				'default' => 'color_style_1'
			]
		);
		$this->add_control(
			'heading_title_anim_styles',
			[
				'label' => __( 'Title Animations', 'nedril-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'no-animation' => esc_html__( 'No Animation', 'nedril-elementor-core' ),
					'animation-style1' => esc_html__( 'Style 01', 'nedril-elementor-core' ),
					'animation-style2' => esc_html__( 'Style 02', 'nedril-elementor-core' ),
					'animation-style3' => esc_html__( 'Style 03', 'nedril-elementor-core' ),
					'animation-style4' => esc_html__( 'Style 04', 'nedril-elementor-core' ),
					'animation-style5' => esc_html__( 'Style 05', 'nedril-elementor-core' ),
					'animation-style6' => esc_html__( 'Style 06', 'nedril-elementor-core' ),
				],
				'default' => 'animation-style1'
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label' => __('Sub Title', 'deskly-elementor-core'),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __('Place Sub Title', 'deskly-elementor-core'),
				'default'	=> esc_html__('Default Sub Title', 'deskly-elementor-core')
			]
		);
		$this->add_control(
			'subtitle_tag',
			[
				'label' 	=> esc_html__( 'Sub Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h6',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 		=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 		=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'		=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 		=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 		=> esc_html__('h6', 'deskly-elementor-core'),
					'span' 	=> esc_html__('span', 'deskly-elementor-core'),
					'p' 		=> esc_html__('p', 'deskly-elementor-core'),
				]
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Place Title', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter title here', 'deskly-elementor-core' ),
				'default'	=> esc_html__('Default Title', 'deskly-elementor-core')
			]
		);
		$this->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h2',
				'options' 	=> [
					'h1' 	=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 	=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 	=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'	=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 	=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 	=> esc_html__('h6', 'deskly-elementor-core'),
				]
			]
		);
		$this->add_control(
			'title_link',
			[
				'label' 		=> esc_html__( 'Link', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'deskly-elementor-core' ),
				'show_external' => true,
			]
		);
		$this->add_responsive_control(
			'title_alignments',
			[
				'label' => __('Heading alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'deskly-elementor-core' ),
						'icon' 	=> 'eicon-text-align-justify',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .section_title ' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$this->add_control(
			'big_text',
			[
				'label'       => __( 'Big Text', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter big text here', 'deskly-elementor-core' ),
				'default'	=> esc_html__('Text', 'deskly-elementor-core'),
				'condition' => [
					'heading_styles' => 'style_2'
			 	],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/



		/*===================================
		Start Sub Title Style
		=====================================*/
		$this->start_controls_section(
			'section_sub_title_style',
			[
				'label' 	=> esc_html__( 'Sub Title', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'sub_title_typography',
				'selector' 	=> '{{WRAPPER}} .section_title .subtitle',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'sub_title_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'sub_title_border',
				'selector' => '{{WRAPPER}} .section_title .subtitle',
			]
		);

		$this->add_responsive_control(
			'sub_title_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .section_title .subtitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sub_title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .section_title .subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sub_title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .section_title .subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Sub Title Style
		=====================================*/

		/*===================================
		Start Title Style
		=====================================*/
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'selector' 	=> '{{WRAPPER}} .section_title .title',
			]
		);
		$this->start_controls_tabs(
			'style_title_tabs'
		);

		$this->start_controls_tab(
			'style_title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'title_color_link_normal',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section_title .title a, {{WRAPPER}} .section_title .title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'title_color_link_hover',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section_title .title a:hover, {{WRAPPER}} .section_title .title:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .section_title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .section_title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Title Style
		=====================================*/

		/*===================================
		Start Sideline Style
		=====================================*/
		$this->start_controls_section(
			'section_sideline_style',
			[
				'label' 	=> esc_html__( 'Side line', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'heading_styles' => 'style_1'
				]
			]
		);
		$this->add_control(
			'sideline_background',
			[
				'label' 	=> esc_html__( 'Background', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}
					.section_title .subtitle .side-line-left:before,
					.section_title .subtitle .side-line-left:after' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_width_top',
			[
				'label' 		=> esc_html__( 'Top Line Width', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%', 'vw' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_width_bottom',
			[
				'label' 		=> esc_html__( 'Bottom Line Width', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%', 'vw' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:after' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_height_top',
			[
				'label' 		=> esc_html__( 'Top Line Height', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%', 'vh' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:before' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_height_bottom',
			[
				'label' 		=> esc_html__( 'Bottom Line Height', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%', 'vh' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_left_top',
			[
				'label' 		=> esc_html__( 'Top Line Left', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:before' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_left_bottom',
			[
				'label' 		=> esc_html__( 'Bottom Line Left', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:after' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_top_bottom',
			[
				'label' 		=> esc_html__( 'Top Line Bottom', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:after' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'sideline_bottom_bottom',
			[
				'label' 		=> esc_html__( 'Bottom Line Bottom', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section_title .subtitle .side-line-left:before' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'side_line_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .side-line-left' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'side_line_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .side-line-left' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Sideline Style
		=====================================*/

		/*===================================
		Start Big Text Style
		=====================================*/
		$this->start_controls_section(
			'section_big_text_style',
			[
				'label' 	=> esc_html__( 'Big Text', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'heading_styles' => 'style_2'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'big_text_typography',
				'selector' 	=> '{{WRAPPER}} .section_title.style2 .big-text',
			]
		);
		$this->add_control(
			'big_text_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section_title.style2 .big-text' => '-webkit-text-stroke-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'big_text_opacity',
			[
				'label' 		=> esc_html__( 'Opacity', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section_title.style2 .big-text' => 'opacity: {{SIZE}};',
				]
			]
		);

		$this->end_controls_section();
		/*===================================
		End Big Text Style
		=====================================*/


		/*===================================
		Start Bottom Style
		=====================================*/
		$this->start_controls_section(
			'section_bottom_line_style',
			[
				'label' 	=> esc_html__( 'Bottom Line', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'heading_styles' => 'style_3'
				]
			]
		);
		$this->add_control(
			'bottom_line_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section_title.style3 .sub-title-line-bottom:before' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'bottom_line_opacity',
			[
				'label' 		=> esc_html__( 'Opacity', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section_title.style3 .sub-title-line-bottom:before' => 'opacity: {{SIZE}};',
				]
			]
		);

		$this->end_controls_section();
		/*===================================
		End Big Text Style
		=====================================*/

	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');

		$subtitle 		= $settings['subtitle'];
		$title 			= $settings['title'];
		$big_text 			= $settings['big_text'];
		$title_link 	= $settings['title_link']['url'];
		$target 		= $settings['title_link']['is_external'] ? ' target="_blank"' : '';

		if ( $settings['heading_styles'] == 'style_1' ) {
			include deskly_get_template('/section-title/style1.php');
		}
		if ( $settings['heading_styles'] == 'style_2' ) {
			include deskly_get_template('/section-title/style2.php');
		}
		if ( $settings['heading_styles'] == 'style_3' ) {
			include deskly_get_template('/section-title/style3.php');
		}
		if ( $settings['heading_styles'] == 'style_4' ) {
			include deskly_get_template('/section-title/style4.php');
		}
		if ( $settings['heading_styles'] == 'style_5' ) {
			include deskly_get_template('/section-title/style5.php');
		}

	}
}
