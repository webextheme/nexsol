<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Show_More extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-show-more';
	}

	public function get_title() {
		return esc_html__( 'Show More Posts', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'show_more_styles',
			[
				'label' => __( 'Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_responsive_control(
			'content_align',
			[
				'label' => __('alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .show-more-block  ' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$this->add_control(
			'deskly_icons',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' => 'webexbase-icon-phone-call',
					'library' => 'deskly_base_icon',
				],
			]
		);
		$this->add_control(
			'title',
			[
				'label' => __('Title', 'deskly-elementor-core'),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __('Place Title', 'deskly-elementor-core'),
				'default'	=> esc_html__('Default Title', 'deskly-elementor-core')
			]
		);
		$this->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'span',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 		=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 		=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'		=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 		=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 		=> esc_html__('h6', 'deskly-elementor-core'),
					'p' 		=> esc_html__('p', 'deskly-elementor-core'),
					'span' 	=> esc_html__('span', 'deskly-elementor-core'),
					'div' 		=> esc_html__('div', 'deskly-elementor-core'),
				]
			]
		);
		$this->add_control(
			'button_link',
			[
				'label' => __('Button Link', 'deskly-elementor-core'),
				'type' => Controls_Manager::URL,
				'placeholder' => __('https://your-link.com', 'deskly-elementor-core'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default' 		=>  esc_html__( 'Contact us' , 'deskly-elementor-core'),
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/



		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'show_more_title_style',
			[
				'label' => esc_html__( 'Title Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'show_more_tabs' );
		$this->start_controls_tab(
			'show_more_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'show_more_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block .title' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'show_more_normal_typography',
				'selector' 	=> '{{WRAPPER}} .show-more-block .title',
			]
		);
		$this->add_responsive_control(
			'show_more_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'show_more_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'show_more_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'show_more_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block .title:hover' => 'color: {{VALUE}} !important;'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'show_more_hover_typography',
				'selector' 	=> '{{WRAPPER}} .show-more-block .title:hover',
			]
		);
		$this->add_responsive_control(
			'show_more_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .title:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'show_more_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .title:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */


		/* ===== Begin Link Style ===== */
		$this->start_controls_section(
			'show_more_link_style',
			[
				'label' => esc_html__( 'Link Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'show_more_link_tabs' );
		$this->start_controls_tab(
			'show_more_link_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'show_more_link_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block .btn-link' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'show_more_link_normal_typography',
				'selector' 	=> '{{WRAPPER}} .show-more-block .btn-link',
			]
		);
		$this->add_responsive_control(
			'show_more_link_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .btn-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'show_more_link_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .btn-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'show_more_link_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'show_more_link_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block .btn-link:hover' => 'color: {{VALUE}} !important;'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'show_more_link_hover_typography',
				'selector' 	=> '{{WRAPPER}} .show-more-block .btn-link:hover',
			]
		);
		$this->add_responsive_control(
			'show_more_link_hover_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .btn-link:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'show_more_link_hover_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .btn-link:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Link Style ===== */



		/* ===== Begin Icons Style ===== */
		$this->start_controls_section(
			'icon_styling',
			[
				'label' => esc_html__( 'Icons Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'label' => esc_html__( 'Typography', 'deskly-elementor-core' ),
				'selector' => '{{WRAPPER}} .show-more-block .show-more-icon',
			]
		);
		$this->add_responsive_control(
			'icon_margin',
			[
				'label'      => esc_html__( 'Icon Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .show-more-block .show-more-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_padding',
			[
				'label'      => esc_html__( 'Icon Padding', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .show-more-block .show-more-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_border',
				'selector' => '{{WRAPPER}} .show-more-block .show-more-icon',
			]
		);
		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .show-more-block .show-more-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'icon_tab' );

		$this->start_controls_tab(
			'icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block .show-more-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block .show-more-icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_item_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block:hover .show-more-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .show-more-block:hover .show-more-icon' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Social Icons Style ===== */


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$deskly_icons = $settings['deskly_icons']['value'];
		$title 			= $settings['title'];
		$title_tag 	= $settings['title_tag'];
		$target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
	 	$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : '';

		switch ( $settings['show_more_styles'] ) {
			case 'style_1':
				include deskly_get_template( '/show-more/style1.php' );
				break;
		}
	}
}



