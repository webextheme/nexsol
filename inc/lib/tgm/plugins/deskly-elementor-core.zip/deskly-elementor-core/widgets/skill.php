<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Skill extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-skill';
	}

	public function get_title() {
		return esc_html__( 'Skill Bar', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'skill_title',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Title', 'deskly-elementor-core' ),
				'default' => esc_html__( 'Design', 'deskly-elementor-core' ),
				'placeholder' => esc_html__( 'Type a skill name', 'deskly-elementor-core' ),
			]
		);
		$repeater->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h6',
				'options' 	=> [
					'h1' 	=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 	=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 	=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'	=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 	=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 	=> esc_html__('h6', 'deskly-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'count',
			[
				'label' => __('Skill Count', 'deskly-elementor-core'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['count'],
				'range' => [
					'count' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'count',
					'size' => 80,
				],
			]
		);
		$repeater->add_control(
			'data_speed',
			[
				'label' => esc_html__( 'Data Speed', 'deskly-elementor-core' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 5000,
				'step' => 1,
				'default' => 2000,
			]
		);
		$this->add_control(
			'skill',
			[
				'label' => __('Skill', 'deskly-elementor-core'),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'prevent_empty' => false,
				'default'     => [
					[
						'skill_title'      => esc_html__( 'Design', 'deskly-elementor-core' ),
					],
				],
				'title_field' => '{{{ skill_title }}}',
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/




		/*===================================
		Start Wrapper Style
		=====================================*/
		$this->start_controls_section(
			'wrapper_style',
			[
				'label' 	=> esc_html__( 'Wrapper Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'item_gap',
			[
				'label'      => esc_html__( 'Item Gap', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .skill-item:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Percentage Style
		=====================================*/






		/*===================================
		Start Title Style
		=====================================*/
		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> esc_html__( 'Title Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'selector' 	=> '{{WRAPPER}} .skill-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-item .skill-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .skill-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .skill-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Title Style
		=====================================*/







		/*===================================
		Start Percentage Style
		=====================================*/
		$this->start_controls_section(
			'percentage_style',
			[
				'label' 	=> esc_html__( 'Percentage Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'percentage_typography',
				'selector' 	=> '{{WRAPPER}} .skill-percentage',
			]
		);
		$this->add_control(
			'percentage_color',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skill-percentage' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Percentage Style
		=====================================*/






		/*===================================
		Start Skill Bar Style
		=====================================*/
		$this->start_controls_section(
			'skill_bar_style',
			[
				'label' 	=> esc_html__( 'Skill Bar Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'skill_bar_tabs'
		);
		$this->start_controls_tab(
			'skill_bar_tab',
			[
				'label' => esc_html__( 'Skill Bar', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'skill_bar_bg_color',
			[
				'label' 	=> esc_html__( 'Bar Backgound Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bar-inner' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'skill_bar_height',
			[
				'label' => esc_html__( 'Bar Height', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 300,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .bar-inner' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'skill_bar_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .bar-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'skill_line_tab',
			[
				'label' => esc_html__( 'Skill Bar Line', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'skill_bar_line_color',
			[
				'label' 	=> esc_html__( 'Bar Line Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bar-inner .bar' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'skill_bar_line_height',
			[
				'label' => esc_html__( 'Bar Line Height', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 300,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .bar-inner .bar' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'skill_bar_line_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .bar-inner .bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Skill Bar Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="skill-style1">

			<?php
			if ( $settings['skill'] ) {
				foreach (  $settings['skill'] as $item ) {
					?>
					<div class="skill-item">
						<div class="skill-header">
							<?php if ( !empty($item['skill_title']) ): ?>
								<?php echo '<'. esc_html( $item['title_tag'] ) .' class="skill-title">'; ?><?php echo esc_html( $item['skill_title'] ); ?><?php echo '</'. esc_html( $item['title_tag'] ) .'>' ?>
							<?php endif; ?>
							<div class="skill-percentage">
								<div class="count-box2"><span class="count-text counting-number" data-speed="<?php echo esc_html($item['data_speed']); ?>" data-stop="<?php echo esc_html($item['count']['size']); ?>">0</span>%</div>
							</div>
						</div>
						<div class="skill-bar">
							<div class="bar-inner">
								<div class="bar progress-line" data-width="<?php echo esc_html($item['count']['size']); ?>"></div>
							</div>
						</div>
					</div>
				<?php } } ?>

			</div>
			<?php
		}
	}
