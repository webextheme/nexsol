<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class DESKLY_Sit_Logo extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-site-logo';
	}

	public function get_title() {
		return esc_html__( 'Site Logo', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'General', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control('logo_form',
		[
			'label' => esc_html__('Logo', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'default' => esc_html__('Default', 'deskly-elementor-core'),
				'custom' => esc_html__('Custom', 'deskly-elementor-core'),
			],
			'default' => 'default',
		]);

		$this->add_control('logo_type',
		[
			'label' => esc_html__('Type', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'text' => esc_html__('Text', 'deskly-elementor-core'),
				'image' => esc_html__('Image', 'deskly-elementor-core'),
			],
			'default' => 'text',
			'condition' => [
				'logo_form' => 'custom',
			],
		]);

		$this->add_control('text_logo',
		[
			'label' => esc_html__('Text logo', 'deskly-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => 'Deskly',
			'conditions' => [
				'relation' => 'and',
				'terms' => [
					[
						'name' => 'logo_form',
						'operator' => '==',
						'value' => 'custom',
					],
					[
						'name' => 'logo_type',
						'operator' => '==',
						'value' => 'text',
					],
				],
			],
		]);

		$this->add_control('main_logo',
		[
			'label' => esc_html__('Image Logo', 'deskly-elementor-core'),
			'type' => Controls_Manager::MEDIA,
			'default' => [
				'url' => DESKLY_THEME_ASSETS . '/images/logo-light.svg',
			],
			'conditions' => [
				'relation' => 'and',
				'terms' => [
					[
						'name' => 'logo_form',
						'operator' => '==',
						'value' => 'custom',
					],
					[
						'name' => 'logo_type',
						'operator' => '==',
						'value' => 'image',
					],
				],
			],
		]);

		$this->add_responsive_control('logo_alignment',
		[
			'label' => esc_html__('Logo Alignment', 'deskly-elementor-core'),
			'type' => Controls_Manager::CHOOSE,
			'label_block' => false,
			'options' => [
				'left' => [
					'title' => esc_html__('Left', 'deskly-elementor-core'),
					'icon' => 'eicon-h-align-left',
				],
				'center' => [
					'title' => esc_html__('Center', 'deskly-elementor-core'),
					'icon' => 'eicon-h-align-center',
				],
				'right' => [
					'title' => esc_html__('Right', 'deskly-elementor-core'),
					'icon' => 'eicon-h-align-right',
				],
			],
			'default' => 'left',
			'toggle' => false,
			'selectors' => [
				'{{WRAPPER}} .deskly-site-logo' => 'text-align: {{VALUE}};',
			],
			'separator' => 'before',
		]);

		$this->add_control('url_type',
		[
			'label' => esc_html__('URL Type', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'default' => esc_html__('Default', 'deskly-elementor-core'),
				'custom' => esc_html__('Custom', 'deskly-elementor-core'),
			],
			'default' => 'default',
		]);

		$this->add_control('custom_url',
		[
			'label' => esc_html__('Custom URL', 'deskly-elementor-core'),
			'type' => Controls_Manager::URL,
			'placeholder' => home_url(),
			'condition' => [
				'url_type' => 'custom',
			],
		]);

		$this->end_controls_section();

		$this->start_controls_section('section_style_image',
		[
			'label' => esc_html__('Style', 'deskly-elementor-core'),
			'tab' => Controls_Manager::TAB_STYLE,
		]);

		$this->add_group_control(Group_Control_Typography::get_type(),
		[
			'name' => 'logo_typography',
			'selector' => '{{WRAPPER}} .deskly-site-logo',
		]);

		$this->add_control('logo_color',
		[
			'label' => esc_html__('Color', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-site-logo a' => 'color: {{VALUE}};',
			],
		]);

		$this->add_control('logo_hover_color',
		[
			'label' => esc_html__('Color(Hover)', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .deskly-site-logo a:hover' => 'color: {{VALUE}};',
			],
		]);

		$this->add_responsive_control('width',
		[
			'label' => esc_html__('Width', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'default' => [
				'unit' => '%',
			],
			'tablet_default' => [
				'unit' => '%',
			],
			'mobile_default' => [
				'unit' => '%',
			],
			'size_units' => ['%', 'px', 'vw'],
			'range' => [
				'%' => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				'vw' => [
					'min' => 1,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .deskly-site-logo img' => 'width: {{SIZE}}{{UNIT}};',
			],
		]);

		$this->add_responsive_control('max_width',
		[
			'label' => esc_html__('Max Width', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'default' => [
				'unit' => '%',
			],
			'tablet_default' => [
				'unit' => '%',
			],
			'mobile_default' => [
				'unit' => '%',
			],
			'size_units' => ['%', 'px', 'vw'],
			'range' => [
				'%' => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				'vw' => [
					'min' => 1,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .deskly-site-logo a' => 'max-width: {{SIZE}}{{UNIT}};',
			],
		]);


		$this->end_controls_section();
		/*===================================
		End Editor Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$site_logo_type = deskly_options('site_logo_type', 'text');
		$site_text_logo = deskly_options('site_text_logo', 'deskly');
		$main_logo = deskly_options('main_logo', ['url' => '']);

		if ( 'custom' === $settings['url_type'] && ! empty( $settings['custom_url']['url'] ) ) {
			$url = $settings['custom_url']['url'];
		} else {
				$url = home_url();
		}

		?>

		<div class="deskly-site-logo">
			<a href="<?php echo esc_url( $url ) ?>">
				<?php if ( 'custom' === $settings['logo_form'] ): ?>
					<?php if ( 'text' === $settings['logo_type'] ): ?>
						<?php echo esc_html( $settings['text_logo'] ) ?>
					<?php elseif ( $settings['main_logo']['url'] ): ?>
						<img src="<?php echo esc_url( $settings['main_logo']['url'] ) ?>" alt="<?php echo get_bloginfo() ?>">
					<?php endif;?>
				<?php else: ?>
					<?php if ( 'text' === $site_logo_type && ! empty( $site_text_logo ) ): ?>
						<?php echo esc_html( $site_text_logo ) ?>
					<?php elseif ( 'image' === $site_logo_type && ! empty( $main_logo['url'] ) ): ?>
						<img src="<?php echo esc_url( $main_logo['url'] ) ?>" alt="<?php echo get_bloginfo() ?>">
					<?php endif;?>
				<?php endif;?>
			</a>
		</div>

		<?php
	}
}
