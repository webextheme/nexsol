<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class DESKLY_Footer_Menu extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-footer-menu';
	}

	public function get_title() {
		return esc_html__( 'Footer Menu', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {
		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'section_menu_type',
			[
				'label' => esc_html__( 'Footer Menu', 'deskly-elementor-core' ),
			]
		);

		$this->add_control(
			'menu_type',
			[
				'label'   => esc_html__( 'Menu', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'theme-default' => esc_html__( 'Theme Default', 'deskly-elementor-core' ),
					'custom'        => esc_html__( 'Custom Menu', 'deskly-elementor-core' ),
				],
				'default' => 'theme-default',
			]
		);

		$this->add_control(
			'selected_menu',
			[
				'label'     => esc_html__( 'Select Menu', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_menus_list(),
				'condition' => [
					'menu_type' => 'custom',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/

		/*===================================
		Start Content Styling
		=====================================*/
		$this->start_controls_section(
			'menu_styles',
			[
				'label' => esc_html__( 'Menu Items', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'menu_item_margin',
			[
				'label'      => esc_html__( 'Menu Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .webex_footer-menu .footer-menu-inner .footer-nav-menu > li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'menu_item_padding',
			[
				'label'      => esc_html__( 'Menu Padding', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .webex_footer-menu .footer-menu-inner .footer-nav-menu > li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'footer-menu-tabs' );
		$this->start_controls_tab(
			'footer_menu_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'footer_menu_normal_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_footer-menu .footer-menu-inner .footer-nav-menu > li > a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'footer_menu_typography',
				'selector' => '{{WRAPPER}} .webex_footer-menu .footer-menu-inner .footer-nav-menu > li > a',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'footer_menu_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'footer_menu_hover_color',
			[
				'label'     => esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_footer-menu .footer-menu-inner .footer-nav-menu > li:hover > a' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'footer_menu_hover_typography',
				'selector' => '{{WRAPPER}} .webex_footer-menu .footer-menu-inner .footer-nav-menu > li:hover > a',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/*===================================
		End Content Styling
		=====================================*/

		/*===================================
		Start Content Styling
		=====================================*/
		$this->start_controls_section(
			'sideline_styles',
			[
				'label' => esc_html__( 'Side Line Styles', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'sideline_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .webex_footer-menu .footer-nav-menu li:after' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Styling
		=====================================*/
	}

	protected function render() {
		$settings = $this->get_settings_for_display();?>

		<div class="webex_footer-menu">
			<?php
			$args = [
				'container'       => 'div',
				'container_class' => 'footer-menu-inner',
				'menu_class'      => 'footer-nav-menu',
				'after'           => '',
				'link_before'     => '<span class="link-text">',
				'link_after'      => '</span>',
				'fallback_cb'     => false,
			];
			if ( 'custom' == $settings['menu_type'] && ! empty( $settings['selected_menu'] ) ) {
				$args['menu'] = $settings['selected_menu'];
			} elseif ( has_nav_menu( 'footer_menu' ) ) {
				$args['theme_location'] = 'footer_menu';
			}
			?>
			<?php wp_nav_menu( $args );?>
		</div>
	<?php
	}
	protected function get_menus_list() {
		$nav_menus = [];
		$terms     = get_terms( 'nav_menu' );
		foreach ( $terms as $term ) {
			$nav_menus[$term->name] = $term->name;
		}
		return $nav_menus;
	}
}

