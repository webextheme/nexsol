<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class DESKLY_Accordion extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-accordion';
	}

	public function get_title() {
		return esc_html__( 'Accordion', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	protected function register_controls() {
		/* ===== Begin Acordion Content ===== */
		$this->start_controls_section(
			'section_content_acordions',
			[
				'label' => esc_html__( 'Acordion', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'style', [
				'label' => __( 'Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style One', 'deskly-elementor-core' ),
					'style_2' => esc_html__( 'Style Two', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'accordion_gradient_styles',
			[
				'label' => __( 'Color Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'color_style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
					'color_style_2' => esc_html__( 'Style 02', 'deskly-elementor-core' ),
				],
				'default' => 'color_style_1'
			]
		);
		$repeater = new Repeater();
		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Title', 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'counting',
			[
				'label'       => esc_html__( 'Counter', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( '01', 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 		=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 		=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 		=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'		=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 		=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 		=> esc_html__('h6', 'deskly-elementor-core'),
					'span' 	=> esc_html__('span', 'deskly-elementor-core'),
					'p' 		=> esc_html__('p', 'deskly-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Description', 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'acordion_items',
			[
				'label'       => esc_html__( 'Items', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'      => esc_html__( 'Q: Why should I attend community college?', 'deskly-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'deskly-elementor-core' ),
					],
					[
						'title'      => esc_html__( 'Q: Why should I attend community college?', 'deskly-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'deskly-elementor-core' ),
					],
					[
						'title'      => esc_html__( 'Q: Why should I attend community college?', 'deskly-elementor-core' ),
						'description' => esc_html__( 'Lorem ipsum dolor sit amet consect adicing aliquam', 'deskly-elementor-core' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		$this->add_control(
			'deskly_inactive_icon',
			[
				'label' => esc_html__( 'Inactive Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fas fa-arrow-right',
					'library' 	=> 'deskly-flaticon',
				],
			]
		);
		$this->add_control(
			'deskly_active_icon',
			[
				'label' => esc_html__( 'Active Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fas fa-arrow-down',
					'library' 	=> 'deskly-flaticon',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Team Items Content ===== */





		/* ===== Begin Content Style ===== */
		$this->start_controls_section(
			'accordion_item_content_style',
			[
				'label' => esc_html__( 'Content Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'accordion_item_item_margin',
			[
				'label'      => esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .accordion-item',
			]
		);
		$this->add_responsive_control(
			'item_box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/* ===== End Content Style ===== */





		/* ===== Begin Title Style ===== */
		$this->start_controls_section(
			'accordion_item_title_style',
			[
				'label' => esc_html__( 'Title Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'accordion_item_title_tab' );
		$this->start_controls_tab(
			'accordion_item_title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_title_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .title' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_title_normal_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_normal_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_title_normal_border',
				'selector' => '{{WRAPPER}} .accordion-item .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_normal_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'accordion_item_title_item_active',
			[
				'label' => esc_html__( 'Active', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_title_active_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_title_active_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .title' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_title_active_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item.active .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_active_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_active_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_title_active_border',
				'selector' => '{{WRAPPER}} .accordion-item.active .title',
			]
		);
		$this->add_responsive_control(
			'accordion_item_title_active_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item.active .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */





		/* ===== Begin Description Style ===== */
		$this->start_controls_section(
			'accordion_item_description_style',
			[
				'label' => esc_html__( 'Description Style', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'accordion_item_description_tab' );
		$this->start_controls_tab(
			'accordion_item_description_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_description_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-body .description' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_description_normal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-body' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_description_normal_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item .accordion-body .description',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_normal_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .accordion-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_description_normal_border',
				'selector' => '{{WRAPPER}} .accordion-item .accordion-body',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_border_normal_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'accordion_item_description_item_active',
			[
				'label' => esc_html__( 'Active', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'accordion_item_description_active_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-body .description' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_description_active_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-body' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'accordion_item_description_active_typography',
				'selector' 	=> '{{WRAPPER}} .accordion-item.active .accordion-body .description',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_active_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .accordion-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_description_active_border',
				'selector' => '{{WRAPPER}} .accordion-item.active .accordion-body',
			]
		);
		$this->add_responsive_control(
			'accordion_item_description_border_active_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .accordion-item.active .title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Title Style ===== */



		/* ===== Begin Icons Style ===== */
		$this->start_controls_section(
			'accordion_item_icons_styling',
			[
				'label' => esc_html__( 'Icons Styling', 'deskly-elementor-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$this->start_controls_tabs( 'accordion_item_icons_tab' );
		$this->start_controls_tab(
			'accordion_item_icons_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'accordion_item_icons_normal_typography',
				'label' => esc_html__( 'Typography', 'deskly-elementor-core' ),
				'selector' => '{{WRAPPER}} .accordion-item .accordion-header span',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_icons_normal_border',
				'selector' => '{{WRAPPER}} .accordion-item .accordion-header span',
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_border_normal_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_normal_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_normal_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_normal_size',
			[
				'label' => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_normal_move_left_right',
			[
				'label' => esc_html__( 'Icon Move Left Right', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_normal_move_up_down',
			[
				'label' => esc_html__( 'Icon Move Up Down', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item .accordion-header span' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'accordion_item_icons_item_active',
			[
				'label' => esc_html__( 'Active', 'deskly-elementor-core' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'accordion_item_icons_active_typography',
				'label' => esc_html__( 'Typography', 'deskly-elementor-core' ),
				'selector' => '{{WRAPPER}} .accordion-item.active .accordion-header span',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'accordion_item_icons_active_border',
				'selector' => '{{WRAPPER}} .accordion-item.active .accordion-header span',
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_border_active_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_active_color',
			[
				'label'     => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'accordion_item_icons_active_bg',
			[
				'label'     => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_active_size',
			[
				'label' => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_active_move_left_right',
			[
				'label' => esc_html__( 'Icon Move Left Right', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'accordion_item_icons_active_move_up_down',
			[
				'label' => esc_html__( 'Icon Move Up Down', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .accordion-item.active .accordion-header span' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/* ===== End Icon Style ===== */

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( $settings['style'] == 'style_1' ) {
			include deskly_get_template('/accordion/style1.php');
		}
		if ( $settings['style'] == 'style_2' ) {
			include deskly_get_template('/accordion/style2.php');
		}

	}
}
