<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;

class DESKLY_Headers extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-header-styles';
	}

	public function get_title() {
		return esc_html__( 'Headers', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

		/*===================================
		Start Content Settings
		=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'header_styles',
			[
				'label' => __( 'Header Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__( 'Style 01', 'deskly-elementor-core' ),
					'style_2' => esc_html__( 'Style 02', 'deskly-elementor-core' ),
					'style_3' => esc_html__( 'Style 03', 'deskly-elementor-core' ),
					'style_4' => esc_html__( 'Style 04', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'header_top_content',
			[
				'label' => __( 'Header Top Content', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'header_styles' => [ 'style_1', 'style_3', 'style_4' ],
				],
			]
		);
		$this->add_control(
			'show_topbar',
			[
				'label' 		=> __( 'Show Topbar ?', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'deskly-elementor-core' ),
				'label_off' 	=> __( 'Hide', 'deskly-elementor-core' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'type',
			[
				'label' => esc_html__( 'Type', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'email',
				'options' => [
					'email' => esc_html__('Email', 'deskly-elementor-core'),
					'phone' => esc_html__('Phone', 'deskly-elementor-core'),
					'text' => esc_html__('Text', 'deskly-elementor-core'),
				]
			]
		);
		$repeater->add_control(
			'icon',
			[
				'label' 	=> __( 'Choose Icon', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fab fa-facebook-f',
					'library' 	=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'email_label',
			[
				'label'   => esc_html__( 'Email Label', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( 'email@company.com', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'email',
				]

			]
		);
		$repeater->add_control(
			'email_address',
			[
				'label'   => esc_html__( 'Email Adress', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( 'email@company.com', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'email',
				]

			]
		);
		$repeater->add_control(
			'phone_label',
			[
				'label'   => esc_html__( 'Phone Label', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( '+012 (345) 678', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'phone',
				]

			]
		);
		$repeater->add_control(
			'phone_address',
			[
				'label'   => esc_html__( 'Phone Adress', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( '+012345678', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'phone',
				]

			]
		);
		$repeater->add_control(
			'text',
			[
				'label'   => esc_html__( 'Text', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( 'Your text', 'deskly-elementor-core' ),
				'condition' => [
					'type' => 'text',
				]

			]
		);
		$this->add_control(
			'items_info',
			[
				'label'       => esc_html__( 'Contact Info', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default' => [
					[
						'type' => 'email',
						'email_label' => esc_html__('email@company.com', 'deskly-elementor-core'),
						'email_address' => esc_html__('email@company.com', 'deskly-elementor-core'),
					],

				],
				'title_field' => '{{{ type }}}',
				'condition'		=> [ 'show_topbar' => [ 'yes' ] ],
			]
		);
		$this->add_control(
			'show_social',
			[
				'label' 		=> __( 'Show Social ?', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'deskly-elementor-core' ),
				'label_off' 	=> __( 'Hide', 'deskly-elementor-core' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'condition'		=> [ 'show_topbar' => [ 'yes' ] ],
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'social_icon',
			[
				'label' 	=> __( 'Social Icon', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fab fa-facebook-f',
					'library' 	=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'icon_link',
			[
				'label' 		=> __( 'Link', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'deskly-elementor-core' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);

		$this->add_control(
			'social_icon_list',
			[
				'label' 		=> __( 'Social Icon', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'social_icon' => __( 'Add Social Icon','deskly-elementor-core' ),
					],
				],
				'condition' => [
					'show_topbar' => 'yes',
					'show_social' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_header_top_menu',
			[
				'label' 		=> __( 'Show Header Top Menu ?', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'deskly-elementor-core' ),
				'label_off' 	=> __( 'Hide', 'deskly-elementor-core' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'condition'		=> [ 'show_topbar' => [ 'yes' ] ],
			]
		);
		$this->add_control(
			'header_top_menu_type',
			[
				'label'   => esc_html__( 'Header Top Menu', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'theme-default' => esc_html__( 'Theme Default', 'deskly-elementor-core' ),
					'custom'        => esc_html__( 'Custom Menu', 'deskly-elementor-core' ),
				],
				'default' => 'theme-default',
				'condition' => [
					'show_header_top_menu' => 'yes',
					'show_topbar' => 'yes',
				],
			]
		);
		$this->add_control(
			'header_top_selected_menu',
			[
				'label'     => esc_html__( 'Select Menu', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_menus_list(),
				'condition' => [
					'header_top_menu_type' => 'custom',
					'show_topbar' => 'yes',
					'show_header_top_menu' => 'yes',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'header_main_menu_content',
			[
				'label' => __( 'Header Main Menu Content', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control('logo_form',
		[
			'label' => esc_html__('Logo', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'default' => esc_html__('Default', 'deskly-elementor-core'),
				'custom' => esc_html__('Custom', 'deskly-elementor-core'),
			],
			'default' => 'default',
		]);

		$this->add_control('logo_type',
		[
			'label' => esc_html__('Type', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'text' => esc_html__('Text', 'deskly-elementor-core'),
				'image' => esc_html__('Image', 'deskly-elementor-core'),
			],
			'default' => 'text',
			'condition' => [
				'logo_form' => 'custom',
			],
		]);

		$this->add_control('text_logo',
		[
			'label' => esc_html__('Text logo', 'deskly-elementor-core'),
			'type' => Controls_Manager::TEXT,
			'default' => 'Deskly',
			'conditions' => [
				'relation' => 'and',
				'terms' => [
					[
						'name' => 'logo_form',
						'operator' => '==',
						'value' => 'custom',
					],
					[
						'name' => 'logo_type',
						'operator' => '==',
						'value' => 'text',
					],
				],
			],
		]);

		$this->add_control('main_logo',
		[
			'label' => esc_html__('Image Logo', 'deskly-elementor-core'),
			'type' => Controls_Manager::MEDIA,
			'default' => [
				'url' => DESKLY_THEME_ASSETS . '/images/logo.png',
			],
			'conditions' => [
				'relation' => 'and',
				'terms' => [
					[
						'name' => 'logo_form',
						'operator' => '==',
						'value' => 'custom',
					],
					[
						'name' => 'logo_type',
						'operator' => '==',
						'value' => 'image',
					],
				],
			],
		]);

		$this->add_control('url_type',
		[
			'label' => esc_html__('URL Type', 'deskly-elementor-core'),
			'type' => Controls_Manager::SELECT,
			'options' => [
				'default' => esc_html__('Default', 'deskly-elementor-core'),
				'custom' => esc_html__('Custom', 'deskly-elementor-core'),
			],
			'default' => 'default',
		]);

		$this->add_control('custom_url',
		[
			'label' => esc_html__('Custom URL', 'deskly-elementor-core'),
			'type' => Controls_Manager::URL,
			'placeholder' => home_url(),
			'condition' => [
				'url_type' => 'custom',
			],
		]);
		$this->add_control(
			'header_primary_menu_type',
			[
				'label'   => esc_html__( 'Header Primary Menu', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'primary-theme-default' => esc_html__( 'Theme Default', 'deskly-elementor-core' ),
					'primary-custom'        => esc_html__( 'Custom Menu', 'deskly-elementor-core' ),
				],
				'default' => 'primary-theme-default',
			]
		);
		$this->add_control(
			'header_primary_selected_menu',
			[
				'label'     => esc_html__( 'Select Menu', 'deskly-elementor-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_menus_list(),
				'condition' => [
					'header_primary_menu_type' => 'primary-custom',
				],
			]
		);
		$this->add_control(
			'show_search_icon',
			[
				'label' 		=> __( 'Show Search?', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'deskly-elementor-core' ),
				'label_off' 	=> __( 'Hide', 'deskly-elementor-core' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'button_text',
			[
				'label' 		=> __( 'Button Text', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( 'Button Text' , 'deskly-elementor-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'button_url',
			[
				'label' 		=> esc_html__( 'Button Link', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'deskly-elementor-core' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'header_main_menu_contact_info',
			[
				'label' => __( 'Header Main Menu Contact Info', 'deskly-elementor-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'show_main_menu_contact_info',
			[
				'label' 		=> __( 'Show Main Menu Contact Info?', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'deskly-elementor-core' ),
				'label_off' 	=> __( 'Hide', 'deskly-elementor-core' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'main_menu_contact_info_icon',
			[
				'label' => esc_html__( 'Choose Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => [
					'show_main_menu_contact_info' => 'yes',
				],
			]
		);
		$this->add_control(
			'main_menu_contact_info_title',
			[
				'label' => esc_html__( 'Title', 'deskly-elementor-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Title Here', 'deskly-elementor-core'),
				'condition' => [
					'show_main_menu_contact_info' => 'yes',
				],
			]
		);
		$this->add_control(
			'main_menu_contact_info_type',
			[
				'label' => esc_html__( 'Type', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'email',
				'options' => [
					'email' => esc_html__('Email', 'deskly-elementor-core'),
					'phone' => esc_html__('Phone', 'deskly-elementor-core'),
					'text' => esc_html__('Text', 'deskly-elementor-core'),
				],
				'condition' => [
					'show_main_menu_contact_info' => 'yes',
				],
			]
		);
		$this->add_control(
			'main_menu_contact_info_email_label',
			[
				'label'   => esc_html__( 'Email Label', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( 'email@company.com', 'deskly-elementor-core' ),
				'condition' => [
					'main_menu_contact_info_type' => 'email',
				]

			]
		);
		$this->add_control(
			'main_menu_contact_info_email_address',
			[
				'label'   => esc_html__( 'Email Adress', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( 'email@company.com', 'deskly-elementor-core' ),
				'condition' => [
					'main_menu_contact_info_type' => 'email',
				]

			]
		);
		$this->add_control(
			'main_menu_contact_info_phone_label',
			[
				'label'   => esc_html__( 'Phone Label', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( '+012 (345) 678', 'deskly-elementor-core' ),
				'condition' => [
					'main_menu_contact_info_type' => 'phone',
					'show_main_menu_contact_info' => 'yes',
				]

			]
		);
		$this->add_control(
			'main_menu_contact_info_phone_address',
			[
				'label'   => esc_html__( 'Phone Adress', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( '+012345678', 'deskly-elementor-core' ),
				'condition' => [
					'main_menu_contact_info_type' => 'phone',
					'show_main_menu_contact_info' => 'yes',
				]

			]
		);
		$this->add_control(
			'main_menu_contact_info_text',
			[
				'label'   => esc_html__( 'Text', 'deskly-elementor-core' ),
				'type'    => Controls_Manager::TEXT,
				'description' => esc_html__( 'Your text', 'deskly-elementor-core' ),
				'condition' => [
					'main_menu_contact_info_type' => 'text',
				]

			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/




		/*===================================
		Start Top Bar Style
		=====================================*/
		$this->start_controls_section(
			'topbar_styling',
			[
				'label' => esc_html__( 'Topbar Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'Topbar_bg_color',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'topbar_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Top Bar Style
		=====================================*/



		/*===================================
		Start Top Bar Social Style
		=====================================*/
		$this->start_controls_section(
			'topbar_social_styling',
			[
				'label' => esc_html__( 'Topbar Social Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Social Typography', 'deskly-elementor-core' ),
				'name' 		=> 'topbar_social_typography',
				'selector' 	=> '{{WRAPPER}} .header-topbar .topbar-social li a',
			]
		);
		$this->start_controls_tabs(
			'topbar_social_tabs'
		);

		$this->start_controls_tab(
			'topbar_social_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'topbar_social_color_normal',
			[
				'label' 	=> esc_html__( 'Social Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-social li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'topbar_social_bg_color_normal',
			[
				'label' 	=> esc_html__( 'Social Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-social li a' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'topbar_social_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'topbar_social_color_hover',
			[
				'label' 	=> esc_html__( 'Social Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-social li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'topbar_social_bg_color_hover',
			[
				'label' 	=> esc_html__( 'Social Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-social li a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'topbar_social_size',
			[
				'label' => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 220,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-social li a' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'topbar_social_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar .topbar-social li, {{WRAPPER}} .header-topbar .topbar-social li + li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'topbar_social_border',
				'selector' => '{{WRAPPER}} .header-topbar .topbar-social li a',
			]
		);
		$this->add_responsive_control(
			'topbar_social_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar .topbar-social li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Top Bar Social Style
		=====================================*/




		/*===================================
		Start Top Bar Menu Style
		=====================================*/
		$this->start_controls_section(
			'topbar_menu_styling',
			[
				'label' => esc_html__( 'Topbar Menu Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'topbar_menu_text_color',
			[
				'label' 	=> esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-nav-area ul li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography', 'deskly-elementor-core' ),
				'name' 		=> 'topbar_menu_typography',
				'selector' 	=> '{{WRAPPER}} .header-topbar .topbar-nav-area ul li a',
			]
		);
		$this->add_responsive_control(
			'topbar_menu_padding',
			[
				'label' 		=> esc_html__( 'Topbar Menu Area Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar .topbar-nav-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'label' 		=> esc_html__( 'Topbar Menu Area Border', 'deskly-elementor-core' ),
				'name'     => 'topbar_menu_border',
				'selector' => '{{WRAPPER}} .header-topbar .topbar-nav-area',
			]
		);
		$this->add_responsive_control(
			'topbar_menu_list_padding',
			[
				'label' 		=> esc_html__( 'List Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar .topbar-nav-area ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'topbar_menu_margin',
			[
				'label' 		=> esc_html__( 'List Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar .topbar-nav-area ul li, {{WRAPPER}} .header-topbar .topbar-nav-area ul li + li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Top Bar Style
		=====================================*/




		/*===================================
		Start Top Bar Contact Info Style
		=====================================*/
		$this->start_controls_section(
			'topbar_contact_styling',
			[
				'label' => esc_html__( 'Topbar Contact Info Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Icon Typography', 'deskly-elementor-core' ),
				'name' 		=> 'topbar_contact_info_typography',
				'selector' 	=> '{{WRAPPER}} .header-topbar .topbar-info li i',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Text Typography', 'deskly-elementor-core' ),
				'name' 		=> 'topbar_contact_info_icon_typography',
				'selector' 	=> '{{WRAPPER}} .header-topbar .topbar-info li a',
			]
		);
		$this->start_controls_tabs(
			'topbar_contact_info_tabs'
		);

		$this->start_controls_tab(
			'topbar_contact_info_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'topbar_contact_info_color_text_normal',
			[
				'label' 	=> esc_html__( 'Contact Info Text Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-info li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'topbar_contact_info_icon_color_normal',
			[
				'label' 	=> esc_html__( 'Contact Info Icon Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-info li i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'topbar_contact_info_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'topbar_contact_info_color_text_hover',
			[
				'label' 	=> esc_html__( 'Contact Info Text Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-info li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'topbar_contact_info_icon_color_hover',
			[
				'label' 	=> esc_html__( 'Contact Info Icon Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-topbar .topbar-info li:hover i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'topbar_contact_info_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar .topbar-info li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'topbar_contact_info_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-topbar .topbar-info li, {{WRAPPER}} .header-topbar .topbar-info li + li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Top Bar Contact Info Style
		=====================================*/



		/*===================================
		Start Primary Menu Style
		=====================================*/
		$this->start_controls_section(
			'primary_menu_styling',
			[
				'label' => esc_html__( 'Primary Menu Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'primary_menu_area_bg_color',
			[
				'label' 	=> esc_html__( 'Menu Area Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'primary_menu_area_sticky_bg_color',
			[
				'label' 	=> esc_html__( 'Menu Area Sticky BG Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu.sticky-header--cloned.sticky-fixed' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'header_styles' => [ 'style_2' ],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'label' 		=> esc_html__( 'Primary Menu Area Border', 'deskly-elementor-core' ),
				'name'     => 'primary_menu_area_border',
				'selector' => '{{WRAPPER}} .main-menu, {{WRAPPER}} .main-menu .main-menu-wrapper',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Text Typography', 'deskly-elementor-core' ),
				'name' 		=> 'primary_menu_typography',
				'selector' 	=> '{{WRAPPER}} .main-nav-menu > li > a',
			]
		);
		$this->start_controls_tabs(
			'primary_menu_tabs'
		);

		$this->start_controls_tab(
			'primary_menu_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'primary_menu_text_color_normal',
			[
				'label' 	=> esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-nav-menu > li > a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'primary_menu_dropdown_text_color_normal',
			[
				'label' 	=> esc_html__( 'Dropdown Text Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-nav-menu > li > ul > li > a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'primary_menu_dropdown_bg_color_normal',
			[
				'label' 	=> esc_html__( 'Dropdown Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-nav-menu > li > ul > li > a' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'primary_menu_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'primary_menu_text_color_hover',
			[
				'label' 	=> esc_html__( 'Text Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-nav-menu > li:hover > a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'primary_menu_dropdown_text_color_hover',
			[
				'label' 	=> esc_html__( 'Dropdown Text Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-nav-menu > li > ul > li > a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'primary_menu_dropdown_bg_color_hover',
			[
				'label' 	=> esc_html__( 'Dropdown Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-nav-menu > li > ul > li > a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'primary_menu_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-nav-menu > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'primary_menu_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-nav-menu > li, {{WRAPPER}} .main-nav-menu > li + li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Primary Menu Style
		=====================================*/


		/*===================================
		Start Logo Style
		=====================================*/
		$this->start_controls_section(
			'logo_styling',
			[
				'label' => esc_html__( 'Logo Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(Group_Control_Typography::get_type(),
		[
			'name' => 'logo_typography',
			'selector' => '{{WRAPPER}} .main-menu-logo',
			'condition' => [
				'logo_type' => 'text',
			],
		]);

		$this->add_control('logo_color',
		[
			'label' => esc_html__('Color', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .main-menu-logo a' => 'color: {{VALUE}};',
			],
			'condition' => [
				'logo_type' => 'text',
			],
		]);

		$this->add_control('logo_hover_color',
		[
			'label' => esc_html__('Color(Hover)', 'deskly-elementor-core'),
			'type' => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .main-menu-logo a:hover' => 'color: {{VALUE}};',
			],
			'condition' => [
				'logo_type' => 'text',
			],
		]);

		$this->add_responsive_control('width',
		[
			'label' => esc_html__('Width', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'default' => [
				'unit' => '%',
			],
			'tablet_default' => [
				'unit' => '%',
			],
			'mobile_default' => [
				'unit' => '%',
			],
			'size_units' => ['%', 'px', 'vw'],
			'range' => [
				'%' => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				'vw' => [
					'min' => 1,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .main-menu-logo img' => 'width: {{SIZE}}{{UNIT}};',
			],
			'condition' => [
				'logo_type' => 'image',
			],
		]);

		$this->add_responsive_control('max_width',
		[
			'label' => esc_html__('Max Width', 'deskly-elementor-core'),
			'type' => Controls_Manager::SLIDER,
			'default' => [
				'unit' => '%',
			],
			'tablet_default' => [
				'unit' => '%',
			],
			'mobile_default' => [
				'unit' => '%',
			],
			'size_units' => ['%', 'px', 'vw'],
			'range' => [
				'%' => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				'vw' => [
					'min' => 1,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .main-menu-logo a' => 'max-width: {{SIZE}}{{UNIT}};',
			],
			'condition' => [
				'logo_type' => 'image',
			],
		]);

		$this->end_controls_section();
		/*===================================
		End Logo Style
		=====================================*/



		/*===================================
		Start Search Toggler Style
		=====================================*/
		$this->start_controls_section(
			'search_toggler_styling',
			[
				'label' => esc_html__( 'Search Toggler Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Search Toggler Typography', 'deskly-elementor-core' ),
				'name' 		=> 'search_toggler_typography',
				'selector' 	=> '{{WRAPPER}} .main-menu-right .search-toggler',
			]
		);
		$this->start_controls_tabs(
			'search_toggler_tabs'
		);

		$this->start_controls_tab(
			'search_toggler_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'search_toggler_color_normal',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu-right .search-toggler' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'search_toggler_bg_color_normal',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu-right .search-toggler' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'search_toggler_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'search_toggler_color_hover',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu-right .search-toggler:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'search_toggler_bg_color_hover',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu-right .search-toggler:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'search_toggler_size',
			[
				'label' => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .main-menu-right .search-toggler' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'search_toggler_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu-right .search-toggler' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'search_toggler_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu-right .search-toggler' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'search_toggler_border',
				'selector' => '{{WRAPPER}} .main-menu-right .search-toggler',
			]
		);
		$this->add_responsive_control(
			'search_toggler_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu-right .search-toggler' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Search Toggler Style
		=====================================*/




		/*===================================
		Start Button Style
		=====================================*/
		$this->start_controls_section(
			'header_button_styling',
			[
				'label' => esc_html__( 'Button Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'header_styles' => [ 'style_1' ],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Button Typography', 'deskly-elementor-core' ),
				'name' 		=> 'header_button_typography',
				'selector' 	=> '{{WRAPPER}} .header-contact-btn .cs-btn-one',
			]
		);
		$this->start_controls_tabs(
			'header_button_tabs'
		);

		$this->start_controls_tab(
			'header_button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'header_button_color_normal',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-contact-btn .cs-btn-one' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'header_button_bg_color_normal',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-contact-btn .cs-btn-one' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'header_button_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'header_button_color_hover',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-contact-btn .cs-btn-one:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'header_button_bg_color_hover',
			[
				'label' 	=> esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-contact-btn .cs-btn-one:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'header_button_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-contact-btn .cs-btn-one' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'header_button_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-contact-btn .cs-btn-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'header_button_border',
				'selector' => '{{WRAPPER}} .header-contact-btn .cs-btn-one',
			]
		);
		$this->add_responsive_control(
			'header_button_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .header-contact-btn .cs-btn-one.btn-circle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Button Style
		=====================================*/




		/*===================================
		Start Main Menu Contact Info Style
		=====================================*/
		$this->start_controls_section(
			'main_menu_contact_styling',
			[
				'label' => esc_html__( 'Main Menu Contact Info Styling', 'deskly-elementor-core' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_wrapper_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-wrapper .main-menu-right .header-contact-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_wrapper_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-wrapper .main-menu-right .header-contact-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'main_menu_contact_info_tabs'
		);

		// Icon Styling
		$this->start_controls_tab(
			'main_menu_contact_info_icon_style',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Icon Typography', 'deskly-elementor-core' ),
				'name' 		=> 'main_menu_contact_info_typography',
				'selector' 	=> '{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon',
			]
		);
		$this->add_control(
			'main_menu_contact_info_icon_bg_color_normal',
			[
				'label' 	=> esc_html__( 'BG Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'main_menu_contact_info_icon_bg_color_hover',
			[
				'label' 	=> esc_html__( 'BG Color Hover', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'main_menu_contact_info_icon_color_normal',
			[
				'label' 	=> esc_html__( 'Icon Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'main_menu_contact_info_icon_color_hover',
			[
				'label' 	=> esc_html__( 'Icon Color Hover', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_icon_size',
			[
				'label' => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_icon_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'main_menu_contact_info_icon_border',
				'selector' => '{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon',
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// Title Styling
		$this->start_controls_tab(
			'main_menu_contact_info_title_style',
			[
				'label' => esc_html__( 'Title', 'deskly-elementor-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Text Typography', 'deskly-elementor-core' ),
				'name' 		=> 'main_menu_contact_info_title_typography',
				'selector' 	=> '{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text .call-text',
			]
		);
		$this->add_control(
			'main_menu_contact_info_title_color_normal',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text .call-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text .call-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text .call-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// Content Styling
		$this->start_controls_tab(
			'main_menu_contact_info_content_style',
			[
				'label' => esc_html__( 'Content', 'deskly-elementor-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Text Typography', 'deskly-elementor-core' ),
				'name' 		=> 'main_menu_contact_info_content_typography',
				'selector' 	=> '{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text a',
			]
		);
		$this->add_control(
			'main_menu_contact_info_content_color_normal',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'main_menu_contact_info_content_color_hover',
			[
				'label' 	=> esc_html__( 'Color Hover', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_content_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'main_menu_contact_info_content_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu .main-menu-right .header-contact-info-text a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
		/*===================================
		End Top Bar Contact Info Style
		=====================================*/

	}

	private function style_tab() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');

		$items_info = $settings['items_info'];
		$label      = $settings['main_menu_contact_info_title'] ? $settings['main_menu_contact_info_title'] : '';
		$show_main_menu_contact_info 		      = $settings['show_main_menu_contact_info'];


		$show_topbar 			    = $settings['show_topbar'];
		$show_social 			    = $settings['show_social'];
		$show_header_top_menu = $settings['show_header_top_menu'];
		$show_search_icon 		= $settings['show_search_icon'];
		$button_text 		      = $settings['button_text'];
		$main_logo = deskly_options('main_logo', ['url' => '']);
		$site_logo_type = deskly_options('site_logo_type', 'text');
		$site_text_logo = deskly_options('site_text_logo', 'deskly');

		if ( 'custom' === $settings['url_type'] && ! empty( $settings['custom_url']['url'] ) ) {
			$url = $settings['custom_url']['url'];
		} else {
				$url = home_url();
		}

		if ( $settings['header_styles'] == 'style_1' ) {
			include deskly_get_template('/headers/style1.php');
		}
		if ( $settings['header_styles'] == 'style_2' ) {
			include deskly_get_template('/headers/style2.php');
		}
		if ( $settings['header_styles'] == 'style_3' ) {
			include deskly_get_template('/headers/style3.php');
		}
		if ( $settings['header_styles'] == 'style_4' ) {
			include deskly_get_template('/headers/style4.php');
		}

	}
	protected function get_menus_list() {
		$nav_menus = [];
		$terms     = get_terms( 'nav_menu' );
		foreach ( $terms as $term ) {
			$nav_menus[$term->name] = $term->name;
		}
		return $nav_menus;
	}
}
