<?php
// namespace Elementor;
namespace DesklyElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class DESKLY_Icon_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return  'webex-icon-box';
	}

	public function get_title() {
		return esc_html__( 'Icon Box', 'deskly-elementor-core' );
	}

	public function get_script_depends() {
		return [
			'deskly-elementor-script'
		];
	}

	public function get_icon() {
		return  'webex-widget-icon';
	}

	public function get_categories() {
		return [ '100' ];
	}

	public function _register_controls() {

	/*===================================
	Start Content Settings
	=====================================*/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content Settings', 'deskly-elementor-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'style', [
				'label' => __( 'Styles', 'deskly-elementor-core' ),
				'type' => Controls_Manager::SELECT,
				'label_block' => true,
				'options' => [
					'style_1' => esc_html__( 'Style One', 'deskly-elementor-core' ),
					'style_2' => esc_html__( 'Style Two', 'deskly-elementor-core' ),
				],
				'default' => 'style_1'
			]
		);
		$this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'deskly-elementor-core' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'webexbase-icon-diamond',
					'library' 	=> 'deskly_base_icon',
				],
			]
		);
		$this->add_control(
			'icon_box_title',
			[
				'label'       => __( 'Place Title', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter title here', 'deskly-elementor-core' ),
				'default'	=> esc_html__('Default Title', 'deskly-elementor-core')
			]
		);
		$this->add_control(
			'title_tag',
			[
				'label' 	=> esc_html__( 'Title Tag', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'h4',
				'options' 	=> [
					'h1' 	=> esc_html__('h1', 'deskly-elementor-core'),
					'h2' 	=> esc_html__('h2', 'deskly-elementor-core'),
					'h3' 	=> esc_html__('h3', 'deskly-elementor-core'),
					'h4'	=> esc_html__('h4', 'deskly-elementor-core'),
					'h5' 	=> esc_html__('h5', 'deskly-elementor-core'),
					'h6' 	=> esc_html__('h6', 'deskly-elementor-core'),
				]
			]
		);
		$this->add_control(
			'icon_box_content',
			[
				'label'       => __( 'Content', 'deskly-elementor-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter content here', 'deskly-elementor-core' ),
				'default'	=> esc_html__('Quickly productivate time strategic mirina magna', 'deskly-elementor-core')
			]
		);
		$this->end_controls_section();
		/*===================================
		End Content Settings
		=====================================*/



		/*===================================
		Start Icon Icon Box Style
		=====================================*/
		$this->start_controls_section(
			'icon_box_style',
			[
				'label' 	=> esc_html__( 'Icon Box Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'icon_position',
			[
				'label' => __('Icon Position', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'icon-pos-left' => [
						'title' => __( 'Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-h-align-left',
					],
					'icon-pos-center' => [
						'title' => __( 'Top', 'deskly-elementor-core' ),
						'icon' => 'eicon-v-align-top',
					],
					'icon-pos-right' => [
						'title' => __( 'Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'default' => 'icon-pos-center',
				'toggle' => true,
			]
		);
		$this->add_responsive_control(
			'icon_h_alignment',
			[
				'label' => __('Icon Horizontal Alignment', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'icon-h-pos-left' => [
						'title' => __( 'Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'icon-h-pos-center' => [
						'title' => __( 'Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'icon-h-pos-right' => [
						'title' => __( 'Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'toggle' => true,
				'default' => 'icon-h-pos-left',
				'condition' => [
					'icon_position' => [ 'icon-pos-center' ],
				],
			]
		);
		$this->add_responsive_control(
			'icon_v_alignment',
			[
				'label' => __('Icon Vertical Alignment', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'icon-v-pos-top' => [
						'title' => __( 'Top', 'deskly-elementor-core' ),
						'icon' => 'eicon-v-align-top',
					],
					'icon-v-pos-middle' => [
						'title' => __( 'Middle', 'deskly-elementor-core' ),
						'icon' => 'eicon-v-align-middle',
					],
					'icon-v-pos-bottom' => [
						'title' => __( 'Bottom', 'deskly-elementor-core' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'toggle' => true,
			]
		);
		$this->add_responsive_control(
			'icon_text_alignments',
			[
				'label' => __('Alignments', 'deskly-elementor-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Text Left', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Text Center', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Text Right', 'deskly-elementor-core' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'deskly-elementor-core' ),
						'icon' 	=> 'eicon-text-align-justify',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item ' => 'text-align: {{VALUE}}!important;',
					'{{WRAPPER}} .icon-box-item.icon-pos-center' => 'text-align: {{VALUE}}!important;',
					'{{WRAPPER}} .icon-box-item.icon-pos-center.left' => 'text-align: {{VALUE}}!important;',
					'{{WRAPPER}} .icon-box-item.icon-pos-center.center' => 'text-align: {{VALUE}}!important;',
					'{{WRAPPER}} .icon-box-item.icon-pos-center.right' => 'text-align: {{VALUE}}!important;',
				],
			]
		);
		$this->start_controls_tabs( 'icon-box-tabs' );
		$this->start_controls_tab(
			'icon_box_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_box_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_box_border_normal',
				'selector' => '{{WRAPPER}} .icon-box-item',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_box_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_box_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item:hover' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_box_border_hover',
				'selector' => '{{WRAPPER}} .icon-box-item:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'icon_box_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_box_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_box_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		/*===================================
		End Icon Icon Box Style
		=====================================*/




		/*===================================
		Start Icon Style
		=====================================*/
		$this->start_controls_section(
			'icon_style',
			[
				'label' 	=> esc_html__( 'Icon Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'icon_typography',
				'selector' 	=> '{{WRAPPER}} .icon-box-item .featured-icon i',
			]
		);
		$this->start_controls_tabs( 'icon-tabs' );
		$this->start_controls_tab(
			'icon_normal',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item .featured-icon i' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item .featured-icon' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_border',
				'selector' => '{{WRAPPER}} .icon-box-item .featured-icon',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'icon_shadow_normal',
			'selector' => '{{WRAPPER}} .icon-box-item .featured-icon',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_hover',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'icon_hover_color',
			[
				'label' => esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item:hover .featured-icon i' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'deskly-elementor-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item:hover .featured-icon' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_border_hover',
				'selector' => '{{WRAPPER}} .icon-box-item:hover .featured-icon',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			'name'     => 'icon_shadow_hover',
			'selector' => '{{WRAPPER}} .icon-box-item:hover .featured-icon',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'icon_box_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--icon-box-icon-margin: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .icon-box-item.icon-box-style2' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_box_size',
			[
				'label'      => esc_html__( 'Size', 'deskly-elementor-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .icon-box-item .featured-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item .featured-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item .featured-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item .featured-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .icon-box-item .featured-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Icon Style
		=====================================*/




		/*===================================
		Start Title Style
		=====================================*/
		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> esc_html__( 'Title Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'selector' 	=> '{{WRAPPER}} .icon-box-item .icon-box-title',
			]
		);
		$this->start_controls_tabs(
			'style_title_tabs'
		);
		$this->start_controls_tab(
			'style_title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'title_color_link_normal',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item .icon-box-title, {{WRAPPER}} .icon-box-item .icon-box-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'style_title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'title_color_link_hover',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item .icon-box-title:hover, {{WRAPPER}} .icon-box-item:hover .icon-box-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item .icon-box-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item .icon-box-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Title Style
		=====================================*/





		/*===================================
		Start Descripion Style
		=====================================*/
		$this->start_controls_section(
			'description_style',
			[
				'label' 	=> esc_html__( 'Description Styles', 'deskly-elementor-core' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'description_typography',
				'selector' 	=> '{{WRAPPER}} .icon-box-item .icon-box-desc',
			]
		);
		$this->start_controls_tabs(
			'style_description_tabs'
		);
		$this->start_controls_tab(
			'style_description_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'description_color_link_normal',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item .icon-box-desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'style_description_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'deskly-elementor-core' ),
			]
		);
		$this->add_control(
			'description_color_link_hover',
			[
				'label' 	=> esc_html__( 'Color', 'deskly-elementor-core' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .icon-box-item:hover .icon-box-desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_responsive_control(
			'description_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item .icon-box-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'description_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'deskly-elementor-core' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .icon-box-item .icon-box-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		/*===================================
		End Descripion Style
		=====================================*/


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$icon               = ! empty( $settings['icon']['value'] ) ? $settings['icon']['value'] : '';
		$icon_box_title     = ! empty( $settings['icon_box_title'] ) ? $settings['icon_box_title'] : '';
		$icon_box_content   = ! empty( $settings['icon_box_content'] ) ? $settings['icon_box_content'] : '';
		$title_tag          = ! empty( $settings['title_tag'] ) ? $settings['title_tag'] : 'h3';

		// Alignment / position fallbacks
		$icon_text_alignments = ! empty( $settings['icon_text_alignments'] ) ? $settings['icon_text_alignments'] : '';
		$icon_position        = ! empty( $settings['icon_position'] ) ? $settings['icon_position'] : '';
		$icon_v_alignment     = ! empty( $settings['icon_v_alignment'] ) ? $settings['icon_v_alignment'] : '';
		$icon_h_alignment     = ! empty( $settings['icon_h_alignment'] ) ? $settings['icon_h_alignment'] : '';

		if ( $settings['style'] == 'style_1' ) {
			include deskly_get_template('/icon-box/style1.php');
		}
		if ( $settings['style'] == 'style_2' ) {
			include deskly_get_template('/icon-box/style2.php');
		}

	}
}
