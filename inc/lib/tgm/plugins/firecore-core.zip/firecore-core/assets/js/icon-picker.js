jQuery(function ($) {
  let iconList = [];
  let activeInput = null;

  $.getJSON(FirecoreIconPicker.json_url, function (data) {
    iconList = data.icons ?? data;
  });

  // OPEN ICON PICKER
  $(document).on("click", ".firecore-icon-picker-btn", function () {
    activeInput = $(this).closest(".firecore-ws-feature-row").find(".firecore-icon-picker-input");

    $("#firecore-icon-popup").show();
    let list = $(".firecore-icon-list").html("");

    iconList.forEach((icon) => {
      list.append(`
        <div class="firecore-icon-item" data-icon="${icon}">
          <i class="${icon}"></i>
        </div>
      `);
    });
  });

  // SELECT ICON
  $(document).on("click", ".firecore-icon-item", function () {
    let iconClass = $(this).data("icon");

    if (activeInput) {
      activeInput.val(iconClass);

      // update preview span
      let preview = activeInput.closest(".firecore-icon-picker-input-wrapper").find(".firecore-icon-preview");

      preview.attr("class", "firecore-icon-preview " + iconClass);
    }

    $("#firecore-icon-popup").hide();
  });

  // SEARCH FILTER
  $(document).on("keyup", "#firecore-icon-search", function () {
    let k = $(this).val().toLowerCase();

    $(".firecore-icon-item").each(function () {
      $(this).toggle($(this).data("icon").toLowerCase().includes(k));
    });
  });

  // ADD ROW
  $(document).on("click", "#firecore-ws-add-row", function () {
    let newRow = `
      <div class="firecore-ws-feature-row">

        <div class="firecore-icon-picker-input-wrapper">
          <span class="firecore-icon-preview"></span>
          <input type="text" name="firecore_ws_icon[]" class="widefat firecore-icon-picker-input" />
        </div>

        <button type="button" class="button firecore-icon-picker-btn">Choose Icon</button>

        <input type="text" name="firecore_ws_text[]" class="widefat" placeholder="Feature text" />

        <button type="button" class="button button-secondary firecore-ws-remove-row">Remove</button>
      </div>
    `;

    $("#firecore-ws-features-wrapper").append(newRow);
  });

  // REMOVE ROW
  $(document).on("click", ".firecore-ws-remove-row", function () {
    $(this).closest(".firecore-ws-feature-row").remove();
  });
});
