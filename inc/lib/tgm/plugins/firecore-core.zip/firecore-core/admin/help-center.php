<?php
/**
 * Template Help center
 *
 * Help Center Template for admin panel
 *
 * @package Firecore
 */

defined( 'ABSPATH' ) || exit;
echo '<h1 class="panel-tab-title">Help Center</h1>';

$allowed_html = [
	'a' => [
			'href'   => true,
			'target' => true,
	],
];

?>
<div class="webex-dashboard-pages firecore-helper-center-page">
	<div class="webex-help-boxes">
		<div class="help-box doc-box">
			<a href="https://docs.webextheme.com/firecore-docs/" target="_blank" class="help-center-btn"><?php esc_html_e( 'Documentation', 'firecore' ) ?></a>
		</div>
		<div class="help-box support-box">
			<a href="https://themeforest.net/user/webextheme#contact" target="_blank" class="help-center-btn"><?php esc_html_e( 'Get Support', 'firecore' ) ?></a>
		</div>
	</div>
</div>