<?php
/**
 * Template Help center
 *
 * Help Center Template for admin panel
 *
 * @package Convis
 */

defined( 'ABSPATH' ) || exit;
?><h1 class="panel-tab-title"><?php echo esc_html__( 'Thanks For Purchasing', 'firecore' ) . ' ' . FIRECORE_NAME ?></h1><?php

$allowed_html = [
	'a' => [
		'href'   => true,
		'target' => true,
	],
];

?>

<div class="webex-dashboard-pages webex-welcome-page">
	<div class="webex-welcome-wrapper">
		<div class="wrapper-left">
			<div class="theme-screenshot">
				<img src="<?php echo esc_url( get_template_directory_uri() . "/screenshot.png" ); ?>">
			</div>
		</div>
		<div class="wrapper-right">
			<div class="webex-welcome-title">
				<h3>
					<?php esc_html_e( 'Welcome to', 'firecore' );?>
					<?php echo esc_html( wp_get_theme()->get( 'Name' ) ); ?>

					<span class="version-theme">
						<?php esc_html_e( 'Version - ', 'firecore' );?>
						<?php echo esc_html( wp_get_theme()->get( 'Version' ) ); ?>
					</span>
					<?php if ( is_child_theme() ) : ?>
					<span class="version-theme">
						<?php esc_html_e( 'Parent Theme Version - ', 'firecore' );?>
						<?php echo FIRECORE_NAME; ?>
					</span>
					<?php endif; ?>
				</h3>
				<p>
					<?php echo sprintf( __( '%s is already installed and ready to use! Let\'s build something impressive.', 'firecore' ), FIRECORE_NAME ); ?>
				</p>
			</div>
			<h6 class="webex-welcome-step-title"><?php echo __( 'Just complete the steps below:', 'firecore' ); ?></h6>
			<ul>
				<li>
					<span class="step-title">
						<?php esc_html_e( 'Step 1', 'firecore' ); ?>
					</span>
					<?php echo sprintf(
						wp_kses( __( 'Check <a href="%s">Server status</a> to avoid errors with your WordPress.', 'firecore' ), $allowed_html ),
						esc_url( admin_url( 'admin.php?page=inerar_server_status' ) )
					); ?>
				</li>
				<li>
					<span class="step-title">
						<?php esc_html_e( 'Step 2', 'firecore' ); ?>
					</span>
					<?php esc_html_e( 'Install Required and recommended plugins.', 'firecore' ); ?>
				</li>
				<li>
					<span class="step-title">
						<?php esc_html_e( 'Step 3', 'firecore' ); ?>
					</span>
					<?php esc_html_e( 'Import demo content', 'firecore' ); ?>
				</li>
			</ul>
		</div>
	</div>
</div>