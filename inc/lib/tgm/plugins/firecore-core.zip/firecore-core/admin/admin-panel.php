<?php

defined( 'ABSPATH' ) || exit;

/**
 * Admin Panel
 */

 function firecore_admin_bar_menu( $wp_admin_bar ) {
	// Add the top-level item
	$wp_admin_bar->add_node( array(
		'id'    => 'firecore_admin_bar_menu',
		'title' => '<span class="firecore-custom-admin-icon ab-icon dashicons-info-outline"></span> ' . FIRECORE_NAME . ' ' . __( 'Support', 'firecore' ),
		'href'  => admin_url( 'admin.php?page=firecore_menu_slug' ),
	) );

	// Add a submenu item 1
	$wp_admin_bar->add_node( array(
		'id'       => 'custom_admin_bar_welcome',
		'parent'   => 'firecore_admin_bar_menu',
		'title'    => 'Welcome',
		'href'     => admin_url( 'admin.php?page=firecore_menu_slug' ),
	) );

	// Add a submenu item 1
	$wp_admin_bar->add_node( array(
		'id'       => 'custom_admin_bar_server_status',
		'parent'   => 'firecore_admin_bar_menu',
		'title'    => __( 'Server Status', 'firecore' ),
		'href'     => admin_url( 'admin.php?page=inerar_server_status' ),
	) );

	// Add a submenu item 2
	$wp_admin_bar->add_node( array(
		'id'       => 'custom_admin_bar_help_center',
		'parent'   => 'firecore_admin_bar_menu',
		'title'    => __( 'Help Center', 'firecore' ),
		'href'     => admin_url( 'admin.php?page=inerar_help_center' ),
	) );
}

add_action( 'admin_bar_menu', 'firecore_admin_bar_menu', 100 );


function my_custom_menu() {
	add_menu_page(
		__( 'Welcome', 'firecore' ),
		FIRECORE_NAME,
		'manage_options',
		'firecore_menu_slug',
		'firecore_welcome_page',
		'dashicons-info-outline',
		6
	);
}
add_action('admin_menu', 'my_custom_menu');

function firecore_welcome_page() {
	require FIRECORE_ADDON_PATH . '/admin/welcome.php';
}

function firecore_custom_submenu() {
	// Add submenu pages under the custom menu
	add_submenu_page(
		'firecore_menu_slug',
		'Server Status',
			__( 'Server Status', 'firecore' ),
		'manage_options',
		'inerar_server_status',
		'inerar_server_status_page'
	);

	add_submenu_page(
		'firecore_menu_slug',
		'Help Center',
		__( 'Help Center', 'firecore' ),
		'manage_options',
		'inerar_help_center',
		'inerar_help_center_page'
	);
}
add_action('admin_menu', 'firecore_custom_submenu');

function inerar_server_status_page() {
	require FIRECORE_ADDON_PATH . '/admin/server-status.php';
}

function inerar_help_center_page() {
	require FIRECORE_ADDON_PATH . '/admin/help-center.php';
}