<?php

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

//
// Metabox of the PAGE
// Set a unique slug-like ID
//
$firecoremetabox = 'firecore_metabox';

/*
* ===========================
* ====  Create a metabox ====
* ===========================
*/
CSF::createMetabox( $firecoremetabox, array(
	'title'        => 'Firecore Page Meta Options',
	'post_type'    => array( 'page', 'post', 'webex_workspaces' ),
	'show_restore' => true,
	'theme'     => 'dark',
) );


/*
* ====================================
* =====  Dark/Ligh Moode metabox =====
* ====================================
*/
CSF::createSection( $firecoremetabox, array(
	'title'  => esc_html__( 'Dark Mood', 'firecore-core' ),
	'icon'   => 'far fa-file-alt',
	'fields' => array(
		array(
			'id'      => 'layout_mode',
			'type'    => 'button_set',
			'title'   => esc_html__( 'Layout Mode (This Page)', 'firecore' ),
			'options' => array(
				'default' => 'Default (use global setting)',
				'dark'    => 'Dark',
				'light'   => 'Light',
			),
			'default' => 'default',
		),
	),
) );

/*
* ================================
* ====  Create Header metabox ====
* ================================
*/
CSF::createSection( $firecoremetabox, array(
	'title'  => esc_html__( 'Header Options', 'firecore-core' ),
	'icon'   => 'far fa-window-maximize',
	'fields' => array(

		array(
			'id'          => 'custom_header_builder_solid',
			'type'        => 'select',
			'title'       => esc_html__( 'Solid Header (Override)', 'firecore-core' ),
			'options'     => 'posts',
			'query_args'  => array(
				'post_type'      => 'wbx_header_builder',
				'posts_per_page' => -1,
			),
			'placeholder' => esc_html__( 'Default (use Theme Option)', 'firecore-core' ),
		),

		array(
			'id'          => 'custom_header_builder_transparent',
			'type'        => 'select',
			'title'       => esc_html__( 'Transparent Header (Override)', 'firecore-core' ),
			'options'     => 'posts',
			'query_args'  => array(
				'post_type'      => 'wbx_header_builder',
				'posts_per_page' => -1,
			),
			'placeholder' => esc_html__( 'Default (use Theme Option)', 'firecore-core' ),
		),

		array(
			'id'          => 'custom_header_builder_sticky',
			'type'        => 'select',
			'title'       => esc_html__( 'Sticky Header (Override)', 'firecore-core' ),
			'options'     => 'posts',
			'query_args'  => array(
				'post_type'      => 'wbx_header_builder',
				'posts_per_page' => -1,
			),
			'placeholder' => esc_html__( 'Default (use Theme Option)', 'firecore-core' ),
		),

	),
) );

/*
* ================================
* ====  Create Footer metabox ====
* ================================
*/
CSF::createSection( $firecoremetabox, array(
	'title'  => esc_html__( 'Footer Options', 'firecore-core' ),
	'icon'   => 'fas fa-ruler-horizontal',
	'fields' => array(

		array(
			'id'      => 'meta_footer_layout',
			'type'    => 'button_set',
			'title'   => esc_html__('Custom Footer', 'firecore-core'),
			'options' => array(
				'yes'   => esc_html__('Yes', 'firecore-core'),
				'no'    => esc_html__('No', 'firecore-core'),
			),
			'default' => 'no',
		),

		array(
			'id'          => 'meta_footer_style',
			'type'        => 'select',
			'title'       => esc_html__( 'Select Footer Style', 'firecore-core' ),
			'options'     => array(
				'footer-one' => esc_html__('Footer Style1', 'firecore-core'),
				'footer-two' => esc_html__('Footer Style2', 'firecore-core'),
        'footer-custom'  => esc_html__('Elementor Footers', 'firecore-core'),
			),
			'dependency'  => array( 'meta_footer_layout', '==', 'yes' ),
		),

    // Footer Builder Options
		array(
      'id'             => 'firecore_builder_deta',
      'type'           => 'select',
      'title'          => esc_html__('Choose Elementor Footers', 'firecore-core'),
      'options'        => 'posts',
      'query_args'     => array(
        'post_type'      => 'wbx_footer_builder',
        'posts_per_page' => -1,
      ),
      'dependency'  => array(
        array('meta_footer_style', '==', 'footer-custom'),
        array('meta_footer_layout', '==', 'yes'),
      ),
    ),

	),
) );

/*
* ====================================
* ====  Create Breadcrumb metabox ====
* ====================================
*/
CSF::createSection( $firecoremetabox, array(
	'title'  => esc_html__( 'Page Title', 'firecore-core' ),
	'icon'   => 'far fa-file-alt',
	'fields' => array(
		array(
			'id'       => 'firecore_meta_enable_page_title',
			'type'     => 'switcher',
			'title'    => esc_html__( 'Enable Page Title', 'firecore-core' ),
			'text_on'  => esc_html__( 'Yes', 'firecore-core' ),
			'text_off' => esc_html__( 'No', 'firecore-core' ),
			'default'  => true,
			'desc'     => esc_html__( 'Enable or disable banner.', 'firecore-core' ),
		),
		array(
			'id'      => 'firecore_meta_page_title_solid_background_options',
			'type'    => 'color',
			'title'   => esc_html__('Page Title Solid Background Color', 'firecore-core'),
			'output'   => '.page-title-section',
			'output_mode' => 'background',
			'dependency'  => array( 'firecore_meta_enable_page_title', '==', 'true' ),
		),
		array(
			'id'      => 'firecore_meta_page_title_background_options',
			'type'    => 'background',
			'title'   => esc_html__('Page Title Background Image', 'firecore-core'),
			'output'   => '.page-title-section',
			'dependency'  => array( 'firecore_meta_enable_page_title', '==', 'true' ),
		),
		array(
			'id'      => 'firecore_meta_page_title_background_overlay',
			'type'    => 'color',
			'title'   => esc_html__('Page Title Background Overlay', 'firecore-core'),
			'output'   => '.page-title-section:after',
			'output_mode' => 'background',
			'dependency'  => array( 'firecore_meta_enable_page_title', '==', 'true' ),
		),
		array(
			'id'          => 'firecore_meta_page_title_spacing',
			'type'        => 'spacing',
			'title'       => esc_html__('Page Title Spacing', 'firecore-core'),
			'subtitle'       => esc_html__('Adjust Page Title Area Spacing', 'firecore-core'),
			'output'      => '.page-title-section',
			'output_mode' => 'padding',
			'dependency'  => array( 'firecore_meta_enable_page_title', '==', 'true' ),
		),
	),
) );