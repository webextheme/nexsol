<?php
/*
* ===============================
* ===== START Logo Settings =====
* ===============================
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
CSF::createSection( $firecoreThemeOption, array(
	'title'  => esc_html__( 'Mobile Menu Sidebar', 'firecore-core' ),
	'id'     => 'mobile-menu-sidebar-settings',
	'icon'   => 'fas fa-mobile-alt',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Logo Settings', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'mobile_menu_sidebar_logo',
			'type'     => 'media',
			'title'    => esc_html__( 'Mobile Menu Sidebar Logo', 'firecore-core' ),
			'subtitle' => esc_html__( 'Upload logo here.', 'firecore-core' ),
			'library'    => 'image',
			'url'        => false,
			'default'    => [
					'url'       => get_template_directory_uri() . '/assets/images/logo-light.svg',
					'thumbnail' => get_template_directory_uri() . '/assets/images/logo-light.svg',
			],
		),
		array(
			'id'      => 'firecore_mobile_menu_sidebar_logo_size',
			'type'    => 'slider',
			'title'   => esc_html__('Logo Size', 'firecore-core'),
			'output'   => '.mobile-menu-sidebar-logo img',
			'output_mode' => 'width',
			'min'     => 72,
			'max'     => 300,
			'step'    => 1,
			'unit'    => 'px',
		),
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Mobile Menu Sidebar Settings', 'firecore-core' ) . '</h3>',
		),
    array(
      'id'          => 'top_header_one_left',
      'type'        => 'group',
      'title'       => esc_html__('Contact Information', 'firecore-core'),
      'fields'      => array(
        array(
          'id'    => 'header_one_left_text',
          'type'  => 'text',
          'title' => esc_html__('Text', 'firecore-core'),
        ),
        array(
          'id'    => 'header_one_left_url',
          'type'  => 'text',
          'title' => esc_html__('Url', 'firecore-core'),
        ),
        array(
          'id'    => 'header_one_left_icon',
          'type'  => 'icon',
          'title' => esc_html__('Icon', 'firecore-core'),
        ),
      ),
			'default'   => array(
				array(
					'header_one_left_icon'  => 'fa fa-map-marker-alt',
					'header_one_left_text'  => esc_html__('121 King Street, Australia', 'firecore-core'),
				),
				array(
					'header_one_left_icon'  => 'fas fa-envelope',
					'header_one_left_text'  => esc_html__('example@gmail.com', 'firecore-core'),
					'header_one_left_url'     => esc_attr__('mailto:example@gmail.com', 'firecore-core'),
				),
				array(
					'header_one_left_icon'  => 'fas fa-phone-alt',
					'header_one_left_text'  => esc_html__('+12 345 666 789', 'firecore-core'),
					'header_one_left_url'     => esc_attr__('tel:123456789', 'firecore-core'),
				),
			),
    ),
		array(
			'id'       => 'firecore_enable_mobile_menu_sidebar_social',
			'type'     => 'switcher',
			'default'  => true,
			'title'    => esc_html__( 'Social Icons Show/Hide', 'firecore-core' ),
			'subtitle' => esc_html__( 'Enable or Disable Social Icons From here', 'firecore-core' ),
		),

		array(
      'id'          => 'top_header_one_left2',
      'type'        => 'group',
      'title'       => esc_html__('Social Icons', 'firecore-core'),
			'dependency'  => array( 'firecore_enable_mobile_menu_sidebar_social', '==', 'true' ),
      'fields'      => array(
        array(
          'id'    => 'header_one_left_url2',
          'type'  => 'text',
          'title' => esc_html__('Url', 'firecore-core'),
        ),
        array(
          'id'    => 'header_one_left_icon2',
          'type'  => 'icon',
          'title' => esc_html__('Icon', 'firecore-core'),
					'library' => 'firecore_base_icon',
        ),
      ),
			'default'   => array(
				array(
					'header_one_left_icon2'  => 'webexbase-icon-facebook-f',
					'header_one_left_url2'     => esc_attr__('facebook.com', 'firecore-core'),
				),
				array(
					'header_one_left_icon2'  => 'webexbase-icon-twitter-2',
					'header_one_left_url2'     => esc_attr__('x.com', 'firecore-core'),
				),
				array(
					'header_one_left_icon2'  => 'webexbase-icon-linkedin2',
					'header_one_left_url2'     => esc_attr__('linkedin.com', 'firecore-core'),
				),
			),
    ),

	),
) );

/*
* ===============================
* ====== End Logo Settings ======
* ===============================
*/