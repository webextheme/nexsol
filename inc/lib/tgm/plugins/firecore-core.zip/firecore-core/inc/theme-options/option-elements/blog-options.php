<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ===============================
* ====  Start Header Setings ====
* ===============================
*/
CSF::createSection( $firecoreThemeOption, array(
	'id'    => 'firecore_blog_page_options',
	'title' => esc_html__( 'Blog Page', 'firecore-core' ),
	'icon'  => 'fab fa-font-awesome-flag',
) );
/*
* =============================
* ====  End Header Setings ====
* =============================
*/

/*
* ====================================
* ====  Start Blog Page Settings =====
* ====================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'parent' => 'firecore_blog_page_options',
	'title'  => esc_html__( 'Blog Page', 'firecore-core' ),
	'id'     => 'firecore_blog_page',
	'icon'   => 'fas fa-bullhorn',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Blog Page', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'firecore_blog_banner_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Banner', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide / Show Banner.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_blog_title',
			'type'       => 'text',
			'title'      => esc_html__('Blog Page Title', 'firecore-core'),
			'dependency' => array( 'firecore_blog_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type blog Page title here.', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_post_date',
			'type'     => 'switcher',
			'title'    => esc_html__('Show Post Date', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide / Show post date.', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_show_excerpt',
			'type'     => 'switcher',
			'title'    => esc_html__('Show Excerpt', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide / Show Excerpt.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_excerpt_length',
			'type'       => 'number',
			'default' 	 => 36,
			'title'      => esc_html__('Excerpt Length Count', 'firecore-core'),
			'dependency' => array( 'firecore_blog_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type excerpt length count.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_show_comments',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Comments', 'firecore-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'firecore-core'),
			'text_off'   => esc_html__('No', 'firecore-core'),
			'desc'       => esc_html__('Hide / Show post comments.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_show_category',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Category Name', 'firecore-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'firecore-core'),
			'text_off'   => esc_html__('No', 'firecore-core'),
			'desc'       => esc_html__('Hide / Show post category name.', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_post_author',
			'type'     => 'switcher',
			'title'    => esc_html__('Show Author Name', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide / Show post author name.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_show_pagination',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Pagination', 'firecore-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'firecore-core'),
			'text_off'   => esc_html__('No', 'firecore-core'),
			'desc'       => esc_html__('Hide / Show post category name.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_show_readmore',
			'type'       => 'switcher',
			'title'      => esc_html__('Show Readmore Button', 'firecore-core'),
			'default'    => true,
			'text_on'    => esc_html__('Yes', 'firecore-core'),
			'text_off'   => esc_html__('No', 'firecore-core'),
			'desc'       => esc_html__('Hide / Show post category name.', 'firecore-core'),
		),
	),
) );
/*
* ==================================
* ====  End Blog Page Settings =====
* ==================================
*/

/*
* ===========================================
* ====  Start Single Blog Post Settings =====
* ===========================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'parent' => 'firecore_blog_page_options',
	'title'  => esc_html__( 'Single Blog Post', 'firecore-core' ),
	'id'     => 'firecore_single_blog_post',
	'icon'   => 'fas fa-edit',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Single Blog Post', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'firecore_single_post_author',
			'type'     => 'switcher',
			'title'    => esc_html__('Post Author Name', 'firecore-core'),
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide or show author name on post details page.', 'firecore-core'),
			'default'  => true
		),
		array(
			'id'       => 'firecore_single_post_date',
			'type'     => 'switcher',
			'title'    => esc_html__('Post Date', 'firecore-core'),
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide or show date on post details page.', 'firecore-core'),
			'default'  => true
		),
		array(
			'id'       => 'firecore_single_post_comments',
			'type'     => 'switcher',
			'title'    => esc_html__('Post Comments', 'firecore-core'),
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide or show post comments on post details page.', 'firecore-core'),
			'default'  => true
		),
		array(
			'id'       => 'firecore_single_next_prev_post',
			'type'     => 'switcher',
			'title'    => esc_html__('Next/Prev Posts', 'firecore-core'),
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide or show Next and Prev post option.', 'firecore-core'),
			'default'  => true
		),
	),
) );
/*
* ===========================================
* ====  End Single Blog Post Settings =======
* ===========================================
*/

/*
* ============================================
* ====  Start Blog Archive Page Settings =====
* ============================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'parent' => 'firecore_blog_page_options',
	'title'  => esc_html__( 'Blog Archive Page', 'firecore-core' ),
	'id'     => 'firecore_blog_archive_page',
	'icon'   => 'fas fa-archive',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Blog Archive Page', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'firecore_archive_banner',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Banner', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Enable or disable archive page banner.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_archive_banner_title',
			'type'       => 'text',
			'title'      => esc_html__('Archive Page Banner Title', 'firecore-core'),
			'dependency' => array( 'firecore_archive_banner', '==', 'true' ),
			'desc'       => esc_html__('Type Archive Page Banner title here.', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_archive_show_pagination',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Pagination', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Enable or disable archive Pagination.', 'firecore-core'),
		),
	),
) );
/*
* ============================================
* ====  End Blog Archive Page Settings =======
* ============================================
*/

/*
* ============================================
* ====  Start Search Page Settings =====
* ============================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'parent' => 'firecore_blog_page_options',
	'title'  => esc_html__( 'Search Page', 'firecore-core' ),
	'id'     => 'firecore_search_page',
	'icon'   => 'fas fa-search',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Search Page', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'firecore_search_banner',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Search Banner', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Enable or disable search page banner.', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_search_show_pagination',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Search Pagination', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Enable or disable search Pagination.', 'firecore-core'),
		),
	),
) );
/*
* ============================================
* ====  End Blog Search Page Settings =======
* ============================================
*/