<?php
/*
* ====================================
* ===== START Dark Mood Settings =====
* ====================================
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
CSF::createSection( $firecoreThemeOption, array(
	'title'  => esc_html__( 'Dark Mood', 'firecore-core' ),
	'id'     => 'dark_mood_settings',
	'icon'   => 'far fa-moon',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Dark Mood Settings', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'      => 'general-settings-enable-dark-mode',
			'type'    => 'switcher',
			'title'   => esc_html__( 'Enable Dark Mode (Global)', 'firecore' ),
			'label'   => esc_html__( 'Turn on to enable dark layout globally.', 'firecore' ),
			'default' => false,
		),
	),
) );

/*
* ====================================
* ====== End Dark Mood Settings ======
* ====================================
*/