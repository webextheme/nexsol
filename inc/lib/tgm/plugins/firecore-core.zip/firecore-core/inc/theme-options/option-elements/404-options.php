<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ====================================
* ====  Start Typography Settings ====
* ====================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'title'  => esc_html__( '404 Page Options', 'firecore-core' ),
	'id'     => 'firecore_404_page_options',
	'icon'   => 'fas fa-exclamation-triangle',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( '404 Page Options', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'firecore_enable_404_banner',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable 404 Banner', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Enable or disable 404 page banner.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_404_banner_title',
			'type'       => 'text',
			'title'      => esc_html__('404 Page Banner Title', 'firecore-core'),
			'dependency' => array( 'firecore_enable_404_banner', '==', 'true' ),
			'desc'       => esc_html__('Type 404 Page Banner title here.', 'firecore-core'),
			'default'     => esc_html__('Page Not Found', 'firecore-core'),
		),
		array(
			'id'          => 'firecore_404_background_options',
			'type'        => 'background',
			'title'       => esc_html__('404 Background', 'firecore-core'),
			'output'      => '.error-area',
			'subtitle'    => esc_html__('Change 404 Background', 'firecore-core'),
			'desc'        => esc_html__('You can change default 404 page background', 'firecore-core'),
			'output_mode' => 'background',
		),
		array(
			'id'      => 'firecore_404_background_background_overlay',
			'type'    => 'color',
			'title'   => esc_html__('Page 404 Background Overlay', 'firecore-core'),
			'output'   => '.error-area:after',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'firecore_404_error_text',
			'type'       => 'text',
			'title'      => esc_html__('404 Error Text', 'firecore-core'),
			'desc'       => esc_html__('Type 404 error text here.', 'firecore-core'),
			'default'     => esc_html__('404', 'firecore-core'),
		),
		array(
			'id'      => 'firecore_404_error_text_color',
			'type'    => 'color',
			'title'   => esc_html__('404 Error Text Color', 'firecore-core'),
			'output'   => '.error-title',
			'output_important' => 'color',
		),
		array(
			'id'         => 'firecore_404_title',
			'type'       => 'text',
			'title'      => esc_html__('404 Title', 'firecore-core'),
			'desc'       => esc_html__('Type 404 Title here.', 'firecore-core'),
			'default'     => esc_html__('Oops... something went wrong!', 'firecore-core'),
		),
		array(
			'id'      => 'firecore_404_title_color',
			'type'    => 'color',
			'title'   => esc_html__('404 Error Title Color', 'firecore-core'),
			'output'   => '.error-text',
			'output_important' => 'color',
		),
		array(
			'id'         => 'firecore_404_description',
			'type'       => 'text',
			'title'      => esc_html__('404 Description', 'firecore-core'),
			'desc'       => esc_html__('Type 404 description here.', 'firecore-core'),
			'default'     => esc_html__('This page is temporarily unavailable due to maintenance. We will back very soon thanks for your patien', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_enable_return_home_button',
			'type'     => 'switcher',
			'title'    => esc_html__( 'Enable Return Home Button', 'firecore-core' ),
			'text_on'  => esc_html__( 'Yes', 'firecore-core' ),
			'text_off' => esc_html__( 'No', 'firecore-core' ),
			'desc'     => esc_html__( 'Enable or disable Return Home button.', 'firecore-core' ),
			'default'  => true,
		),
		array(
			'id'         => 'firecore_404_return_home_button_text',
			'type'       => 'text',
			'title'      => esc_html__('404 Button Text', 'firecore-core'),
			'desc'       => esc_html__('Type 404 Button Text here.', 'firecore-core'),
			'default'     => esc_html__('Return Home', 'firecore-core'),
			'dependency' => array( 'firecore_enable_return_home_button', '==', 'true' ),
		),
	),
) );
/*
* ==================================
* ====  End Typography Settings ====
* ==================================
*/
