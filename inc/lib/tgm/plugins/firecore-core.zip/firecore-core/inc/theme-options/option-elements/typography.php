<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ====================================
* ====  Start Typography Settings ====
* ====================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'title'  => esc_html__( 'Typography', 'firecore-core' ),
	'id'     => 'firecore_typography_options',
	'icon'   => 'fa fa-font',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Body', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'     => 'firecore_body_typography',
			'type'   => 'typography',
			'output' => 'body',
		),
		array(
			'type'    => 'submessage',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'All Headings', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'     => 'firecore_all_headings_typography',
			'type'   => 'typography',
			'output' => array('h1,h2,h3,h4,h5,h6'),
		),
		array(
			'type'       => 'submessage',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Heading (H1 - H6)', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'           => 'firecore_h1_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H1', 'firecore-core' ),
			'output'       => 'h1',
			'subtitle'     => esc_html__( 'Set heading H1 typography.', 'firecore-core' ),
		),
		array(
			'id'           => 'firecore_h2_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H2', 'firecore-core' ),
			'output'       => 'h2',
			'subtitle'     => esc_html__( 'Set heading H2 typography.', 'firecore-core' ),
		),
		array(
			'id'           => 'firecore_h3_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H3', 'firecore-core' ),
			'output'       => 'h3',
			'subtitle'     => esc_html__( 'Set heading H3 typography.', 'firecore-core' ),
		),
		array(
			'id'           => 'firecore_h4_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H4', 'firecore-core' ),
			'output'       => 'h4',
			'subtitle'     => esc_html__( 'Set heading H4 typography.', 'firecore-core' ),
		),
		array(
			'id'           => 'firecore_h5_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H5', 'firecore-core' ),
			'output'       => 'h5',
			'subtitle'     => esc_html__( 'Set heading H5 typography.', 'firecore-core' ),
		),
		array(
			'id'           => 'firecore_h6_typography',
			'type'         => 'typography',
			'title'        => esc_html__( 'Heading H6', 'firecore-core' ),
			'output'       => 'h6',
			'subtitle'     => esc_html__( 'Set heading H6 typography.', 'firecore-core' ),
		),
	),
) );
/*
* ==================================
* ====  End Typography Settings ====
* ==================================
*/
