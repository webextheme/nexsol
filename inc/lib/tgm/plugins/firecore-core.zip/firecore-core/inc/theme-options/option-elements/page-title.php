<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ====================================
* ====  Start Typography Settings ====
* ====================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'title'  => esc_html__( 'Page Title', 'firecore-core' ),
	'id'     => 'firecore_page_title_options',
	'icon'   => 'far fa-file-alt',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Page Title Options', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'firecore_page_title_banner_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Banner', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide / Show Banner.', 'firecore-core'),
		),
		array(
			'id'      => 'firecore_page_title_background_options',
			'type'    => 'background',
			'title'   => esc_html__('Page Title Background Image', 'firecore-core'),
			'output'   => '.page-title-section',
			'output_mode' => 'background',
			'dependency' => array( 'firecore_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'      => 'firecore_page_title_background_overlay',
			'type'    => 'color',
			'title'   => esc_html__('Page Title Background Overlay', 'firecore-core'),
			'output'   => '.page-title-section:after',
			'output_mode' => 'background',
			'dependency' => array( 'firecore_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'      => 'firecore_page_title_background_overlay_opacity',
			'type'    => 'slider',
			'title'   => esc_html__('Page Title Background Overlay Opacity', 'firecore-core'),
			'output'   => '.page-title-section:after',
			'output_mode' => 'opacity',
			'min'     => 0,
			'max'     => 1,
			'step'    => .01,
			'default' => 0.75,
			'unit'    => ' ',
			'dependency' => array( 'firecore_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'       => 'firecore_page_title_color',
			'type'     => 'color',
			'title'    => esc_html__('Page Title Color', 'firecore-core'),
			'output'   => '.page-title-section .breadcrumb-area .page-title',
			'output_mode' => 'color',
			'desc'     => esc_html__('You can change default page title color.', 'firecore-core'),
			'dependency' => array( 'firecore_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'          => 'firecore_page_title_spacing',
			'type'        => 'spacing',
			'title'       => esc_html__('Page Title Spacing', 'firecore-core'),
			'subtitle'       => esc_html__('Adjust Page Title Area Spacing', 'firecore-core'),
			'output'      => '.page-title-section',
			'output_mode' => 'padding',
			'dependency' => array( 'firecore_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'       => 'firecore_page_title_breadcrumb_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Breadcrumb', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide / Show Breadcrumb.', 'firecore-core'),
			'dependency' => array( 'firecore_page_title_banner_enable', '==', 'true' ),
		),
		array(
			'id'       => 'firecore_breadcrumb_text_color',
			'type'     => 'color',
			'title'    => esc_html__('Breadcrumb Text Color', 'firecore-core'),
			'output'   => array('.page-title-section .breadcrumb-area .breadcrumbs-link li.active'),
			'output_mode' => 'color',
			'subtitle' => esc_html__('Breadcrumb text color', 'firecore-core'),
			'desc'     => esc_html__('You can change default breadcrumb Text color.', 'firecore-core'),
			'dependency' => array(
				array('firecore_page_title_banner_enable', '==', 'true'),
				array('firecore_page_title_breadcrumb_enable', '==', 'true'),
			),
		),
		array(
			'id'       => 'firecore_breadcrumb_link_text_color',
			'type'     => 'link_color',
			'title'    => esc_html__('Breadcrumb Link Text Color', 'firecore-core'),
			'output'   => array('.page-title-section .breadcrumb-area .breadcrumbs-link li a'),
			'output_mode' => 'color',
			'subtitle' => esc_html__('Breadcrumb Link color', 'firecore-core'),
			'desc'     => esc_html__('You can change default breadcrumb link Text normal and hover color.', 'firecore-core'),
			'dependency' => array(
				array('firecore_page_title_banner_enable', '==', 'true'),
				array('firecore_page_title_breadcrumb_enable', '==', 'true'),
			),
		),
		array(
			'id'       => 'firecore_breadcrumb_arrow_color',
			'type'     => 'color',
			'title'    => esc_html__('Breadcrumb Arrow Color', 'firecore-core'),
			'output'   => array('.page-title-section .breadcrumb-area .breadcrumbs-link li:after'),
			'output_mode' => 'color',
			'subtitle' => esc_html__('Breadcrumb arrow color', 'firecore-core'),
			'desc'     => esc_html__('You can change default breadcrumb arrow color.', 'firecore-core'),
			'dependency' => array(
				array('firecore_page_title_banner_enable', '==', 'true'),
				array('firecore_page_title_breadcrumb_enable', '==', 'true'),
			),
		),
	),
) );
/*
* ==================================
* ====  End Typography Settings ====
* ==================================
*/
