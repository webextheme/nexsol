<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ===============================
* ====  Start Header Setings ====
* ===============================
*/
CSF::createSection( $firecoreThemeOption, array(
	'id'    => 'firecore_header_settings',
	'title' => esc_html__( 'Header Settings', 'firecore-core' ),
	'icon'  => 'far fa-window-maximize',
) );
/*
* =============================
* ====  End Header Setings ====
* =============================
*/

/*
* ============================
* ====  Star Header Style ====
* ============================
*/
CSF::createSection( $firecoreThemeOption, array(
	'parent' => 'firecore_header_settings',
	'title'  => esc_html__( 'Header Styles', 'firecore-core' ),
	'icon'   => 'fas fa-arrow-right',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Elementor Header Styles', 'firecore-core' ) . '</h3>',
		),
    // Header Builder Solid
		array(
      'id'             => 'header_builder_solid',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor Solid Header Style', 'firecore-core'),
      'options'        => 'posts',
			'placeholder' 	 => 'Select an option',
      'query_args'     => array(
        'post_type'      => 'wbx_header_builder',
        'posts_per_page' => -1,
      ),
    ),
    // Header Builder Transparent
		array(
      'id'             => 'header_builder_transparent',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor Transparent Header Style', 'firecore-core'),
      'options'        => 'posts',
			'placeholder' 	 => 'Select an option',
      'query_args'     => array(
        'post_type'      => 'wbx_header_builder',
        'posts_per_page' => -1,
      ),
    ),
    // Header Builder Sticky
		array(
      'id'             => 'header_builder_sticky',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor sticky Header Style', 'firecore-core'),
      'options'        => 'posts',
			'placeholder' 	 => 'Select an option',
      'query_args'     => array(
        'post_type'      => 'wbx_header_builder',
        'posts_per_page' => -1,
      ),
    ),

	),
) );
/*
* ===========================
* ====  End Header Style ====
* ===========================
*/