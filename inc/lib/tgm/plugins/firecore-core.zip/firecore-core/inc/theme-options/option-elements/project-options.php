<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
/*
* ===============================
* ====  Start Header Setings ====
* ===============================
*/
CSF::createSection( $firecoreThemeOption, array(
	'id'    => 'firecore_project_page_options',
	'title' => esc_html__( 'Project Page', 'firecore-core' ),
	'icon'  => 'fab fa-font-awesome-flag',
) );
/*
* =============================
* ====  End Header Setings ====
* =============================
*/

/*
* ====================================
* ====  Start Project Page Settings =====
* ====================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'parent' => 'firecore_project_page_options',
	'title'  => esc_html__( 'Single Project', 'firecore-core' ),
	'id'     => 'firecore_project_page',
	'icon'   => 'fas fa-bullhorn',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Project Single Page', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'project_label',
			'type'     => 'text',
			'title'       => esc_html__( 'Project Label', 'firecore-core' ),
			'placeholder' => esc_html__( 'Projects', 'firecore-core' ),
			'desc'        => esc_html__( 'Rename the Custom Post Type.', 'firecore-core' ),
		),
		array(
			'id'       => 'project_slug',
			'type'     => 'text',
			'title'       => esc_html__( 'Project Slug', 'firecore-core' ),
			'placeholder' => esc_html__( 'project slug', 'firecore-core' ),
			'desc'        => esc_html__( 'You can customize the permalink structure (site_domain/post_type_slug/post_slug) by changing the post type slug (post_type_slug) from here. Don\'t forget to save the permalinks settings from Settings > Permalinks after changing the slug value.', 'firecore-core' ),
		),
		array(
			'id'       => 'project_cats_slug',
			'type'     => 'text',
			'title'       => esc_html__( 'Project Category Slug', 'firecore-core' ),
			'placeholder' => esc_html__( 'Project Category Slug', 'firecore-core' ),
			'desc'        => esc_html__( 'You can customize the permalink structure (site_domain/post_category_slug/) by changing from here. Don\'t forget to save the permalinks settings from Settings > Permalinks after changing the slug value.', 'firecore-core' ),
		),
		array(
			'id'       => 'firecore_project_banner_enable',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Banner', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide / Show Banner.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_project_title',
			'type'       => 'text',
			'title'      => esc_html__('Project Page Title', 'firecore-core'),
			'dependency' => array( 'firecore_project_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type project Page title here.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_project_home_title',
			'type'       => 'text',
			'title'      => esc_html__('Project Page Home Title', 'firecore-core'),
			'dependency' => array( 'firecore_project_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type project Page Home title here.', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_project_related_post_show_hide',
			'type'     => 'switcher',
			'title'    => esc_html__('Related Posts', 'firecore-core'),
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide or show Next and Prev post option.', 'firecore-core'),
			'default'  => true
		),
		array(
			'id'         => 'firecore_related_project_title',
			'type'       => 'text',
			'title'      => esc_html__('Related Project Title', 'firecore-core'),
			'dependency' => array( 'firecore_project_banner_enable', '==', 'true' ),
			'desc'       => esc_html__('Type related project title here.', 'firecore-core'),
			'dependency' => array( 'firecore_project_related_post_show_hide', '==', 'true' ),
		),
		array(
			'id'       => 'firecore_project_single_next_prev_post',
			'type'     => 'switcher',
			'title'    => esc_html__('Next/Prev Posts', 'firecore-core'),
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Hide or show Next and Prev post option.', 'firecore-core'),
			'default'  => false
		),
	),
) );
/*
* ==================================
* ====  End Project Page Settings =====
* ==================================
*/


/*
* ===========================================
* ====  Start Archive Project Post Settings =====
* ===========================================
*/
CSF::createSection( $firecoreThemeOption, array(
	'parent' => 'firecore_project_page_options',
	'title'  => esc_html__( 'Archive Project', 'firecore-core' ),
	'id'     => 'firecore_archive_project_post',
	'icon'   => 'fas fa-edit',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'style'      => 'info',
			'content' => '<h3>' . esc_html__( 'Project Archive Page', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'       => 'firecore_archive_project_banner',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Banner', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Enable or disable archive page banner.', 'firecore-core'),
		),
		array(
			'id'         => 'firecore_archive_project_banner_title',
			'type'       => 'text',
			'title'      => esc_html__('Archive Page Banner Title', 'firecore-core'),
			'dependency' => array( 'firecore_archive_project_banner', '==', 'true' ),
			'desc'       => esc_html__('Type Archive Page Banner title here.', 'firecore-core'),
		),
		array(
			'id'       => 'firecore_archive_project_show_pagination',
			'type'     => 'switcher',
			'title'    => esc_html__('Enable Archive Pagination', 'firecore-core'),
			'default'  => true,
			'text_on'  => esc_html__('Yes', 'firecore-core'),
			'text_off' => esc_html__('No', 'firecore-core'),
			'desc'     => esc_html__('Enable or disable archive Pagination.', 'firecore-core'),
		),
	),
) );
/*
* ===========================================
* ====  End Archive Project Post Settings =======
* ===========================================
*/