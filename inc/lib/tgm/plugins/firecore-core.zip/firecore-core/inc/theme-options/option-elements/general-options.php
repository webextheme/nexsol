<?php

/*
* ================================
* ==== START General Settings ====
* ================================
*/
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
CSF::createSection( $firecoreThemeOption, array(
	'title'  => esc_html__( 'General Settings', 'firecore-core' ),
	'id'     => 'general-settings',
	'icon'   => 'fas fa-tools',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'General Settings', 'firecore-core' ) . '</h3>',
		),
		array(
			'id'         => 'firecore_container_width',
			'type'       => 'radio',
			'title'    => esc_html__( 'Container Width', 'firecore-core' ),
			'inline'       => true,
			'options'    => array(
				'default' => 'Default',
				'1140' 		=> '1140px',
				'1200' 		=> '1200px',
				'1260' 		=> '1260px',
				'1320' 		=> '1320px',
				'1420' 		=> '1420px',
				'1540' 		=> '1540px',
			),
			'default'    => '1320',
			'subtitle' => esc_html__( 'If you want to use elementor layout container then choose default option', 'firecore-core' ),
		),
		array(
			'id'       => 'firecore_enable_preloader',
			'type'     => 'switcher',
			'default'  => true,
			'title'    => esc_html__( 'Preloader', 'firecore-core' ),
			'subtitle' => esc_html__( 'Enable or Disable preloader From here', 'firecore-core' ),
		),
		array(
			'id'       => 'firecore_enable_scroll_to_top',
			'type'     => 'switcher',
			'default'  => true,
			'title'    => esc_html__( 'Scroll To Top', 'firecore-core' ),
			'subtitle' => esc_html__( 'Enable or Disable scroll to top option From here', 'firecore-core' ),
		),
	),
) );
/*
* ================================
* ===== End General Settings =====
* ================================
*/