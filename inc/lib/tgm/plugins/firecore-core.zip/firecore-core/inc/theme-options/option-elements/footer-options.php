<?php
if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/*
* ============================
* ====  Star Footer Styles ====
* ============================
*/
	CSF::createSection( $firecoreThemeOption, array(
	'id' => 'firecore_footer_settings',
	'title'  => esc_html__( 'Footer Settings', 'firecore-core' ),
	'icon'   => 'fas fa-ruler-horizontal',
	'fields' => array(
		array(
			'type'    => 'subheading',
			'content' => '<h3>' . esc_html__( 'Choose Footer Styles', 'firecore-core' ) . '</h3>',
		),

		array(
			'id'       => 'footer_layout_style',
			'type'        => 'select',
			'title'    => esc_html__( 'Select Style', 'firecore-core' ),
			'options'     => array(
        'footer-default' => esc_html__('Default Footer', 'firecore-core'),
        'footer-custom'  => esc_html__('Elementor Footers', 'firecore-core'),
				'footer-one' => esc_html__('Footer Style1', 'firecore-core'),
				'footer-two' => esc_html__('Footer Style2', 'firecore-core'),
			),
			'default'  => 'footer-default',
			'subtitle' => esc_html__( 'Choose Your Footer Style For Global', 'firecore-core' ),
		),

    // Footer Builder Options
		array(
      'id'             => 'firecore_builder_deta',
      'type'           => 'select',
      'title'          => esc_html__('Select Elementor Footer Style', 'firecore-core'),
      'options'        => 'posts',
      'query_args'     => array(
        'post_type'      => 'wbx_footer_builder',
        'posts_per_page' => -1,
      ),
      'dependency' => array('footer_layout_style', '==', 'footer-custom'),
    ),

		array(
			'id'         => 'firecore_footer_text_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Text Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change footer text color here', 'firecore-core' ),
			'output'     => '.footer, .footer a',
			'output_mode' => 'color',
		),
		array(
			'id'         => 'firecore_footer_background_settings',
			'type'       => 'background',
			'title'      => esc_html__( 'Footer Background Options', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Add Background color or Image for footer ', 'firecore-core' ),
			'output'     => '.footer .footer-main-area',
		),
		array(
			'id'      => 'firecore_footer_background_overlay',
			'type'    => 'color',
			'title'   => esc_html__('Footer Background Overlay', 'firecore-core'),
			'output'   => '.footer .footer-main-area:after',
			'output_mode' => 'background',
		),
		array(
			'id'            => 'firecore_copyright_text',
			'type'          => 'wp_editor',
			'title'         => esc_html__( 'Copyright Text', 'firecore-core' ),
			'subtitle'      => esc_html__( 'Site copyright text', 'firecore-core' ),
			'default'       => esc_html__( 'Copyright by WebexTheme © 2025. All rights reserved', 'firecore-core' ),
			'desc'          => esc_html__( 'Place copyright text here.', 'firecore-core' ),
			'tinymce'       => true,
			'quicktags'     => true,
			'media_buttons' => false,
			'height'        => '100px',
		),
		array(
			'id'         => 'firecore_copyright_background_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Copyright Background Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change copyright background color here', 'firecore-core' ),
			'output'     => '.footer-copyright-area',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'firecore_copyright_text_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Copyright Text Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change copyright text color here', 'firecore-core' ),
			'output'     => '.footer-copyright-area .copyright-text',
			'output_mode' => 'color',
		),
		array(
			'id'         => 'firecore_newsletter_background_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Newsletter Background Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change newsletter background color here', 'firecore-core' ),
			'output'     => '.footer-widget .newsletter-from .email input[type="email"]',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'firecore_footer_social_background_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Background Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change footer social background color here', 'firecore-core' ),
			'output'     => '.footer-widget .social-list li a',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'firecore_footer_social_background_hover_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Background Hover Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change footer social background hover color here', 'firecore-core' ),
			'output'     => '.footer-widget .social-list li a:hover',
			'output_mode' => 'background',
		),
		array(
			'id'         => 'firecore_footer_social_text_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Text Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change footer social text color here', 'firecore-core' ),
			'output'     => '.footer-widget .social-list li a',
			'output_mode' => 'color',
		),
		array(
			'id'         => 'firecore_footer_social_text_hover_color',
			'type'       => 'color',
			'title'      => esc_html__( 'Footer Social Text Hover Color', 'firecore-core' ),
			'subtitle'   => esc_html__( 'Change footer social text hover color here', 'firecore-core' ),
			'output'     => '.footer-widget .social-list li a:hover',
			'output_mode' => 'color',
		),
	),
	) );
/*
* ============================
* ====  End Footer Styles ====
* ============================
*/
