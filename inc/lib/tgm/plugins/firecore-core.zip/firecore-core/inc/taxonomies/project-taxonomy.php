<?php
/**
 * Project Taxonomy
 */
function myplugin_project_taxonomy() {
	$labels = array(
		'name'              => _x( 'Project Categories', 'taxonomy general name', 'firecore-core' ),
		'singular_name'     => _x( 'Project Category', 'taxonomy singular name', 'firecore-core' ),
		'menu_name'         => __( 'Project Categories', 'firecore-core' ),
		'search_items'      => __( 'Search Categories', 'firecore-core' ),
		'all_items'         => __( 'All Categories', 'firecore-core' ),
		'parent_item'       => __( 'Parent Category', 'firecore-core' ),
		'parent_item_colon' => __( 'Parent Category:', 'firecore-core' ),
		'edit_item'         => __( 'Edit Category', 'firecore-core' ),
		'update_item'       => __( 'Update Category', 'firecore-core' ),
		'add_new_item'      => __( 'Add New Category', 'firecore-core' ),
		'new_item_name'     => __( 'New Category Name', 'firecore-core' ),
	);
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'show_in_rest'      => true,
		'rewrite'            => ['slug' => 'firecore-project-texonomy'],
	);
	register_taxonomy( 'webex_projects_cats', array('webex_projects'), $args );
}
add_action('init', 'myplugin_project_taxonomy');