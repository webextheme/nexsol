<?php
/**
 * Create Project Post Type
 */

class Project {

	private $type = 'webex_projects';
	private $slug;
	private $cats_slug;
	private $name;
	private $singular_name;
	private $plural_name;

	public function __construct() {
		$options = get_option( 'firecore_Theme_Option' );
		$this->name          = ! empty( $options['project_label'] ) ? str_replace( ' ', '', $options['project_label'] ) : 'Projects';
		$this->slug          = ! empty( $options['project_slug'] ) ? strtolower( str_replace( ' ', '', $options['project_slug'] ) ) : 'projects-item';
		$this->cats_slug     = ! empty( $options['project_cats_slug'] ) ? strtolower( str_replace( ' ', '', $options['project_cats_slug'] ) ) : 'projects-category';

		add_action( 'init', [$this, 'set_labels_and_register'] );
	}

	/**
	 * Set labels and register everything on init
	 */
	public function set_labels_and_register() {
		// These functions must run at or after init to avoid the warning
		$this->singular_name = esc_html__( 'Item', 'firecore-core' );
		$this->plural_name   = esc_html__( 'Items', 'firecore-core' );
		$this->name          = esc_html__( $this->name, 'firecore-core' );

		$this->register_post_type();
		$this->register_taxonomy_cat();
	}

	public function register_post_type() {
		$labels = [
			'name'                  => $this->name,
			'singular_name'         => $this->singular_name,
			'add_new'               => sprintf( esc_html__( 'Add New %s', 'firecore-core' ), $this->singular_name ),
			'add_new_item'          => sprintf( esc_html__( 'Add New %s', 'firecore-core' ), $this->singular_name ),
			'edit_item'             => sprintf( esc_html__( 'Edit %s', 'firecore-core' ), $this->singular_name ),
			'new_item'              => sprintf( esc_html__( 'New %s', 'firecore-core' ), $this->singular_name ),
			'all_items'             => sprintf( esc_html__( 'All %s', 'firecore-core' ), $this->plural_name ),
			'view_item'             => sprintf( esc_html__( 'View %s', 'firecore-core' ), $this->name ),
			'search_items'          => sprintf( esc_html__( 'Search %s', 'firecore-core' ), $this->name ),
			'not_found'             => sprintf( esc_html__( 'No %s found', 'firecore-core' ), strtolower( $this->name ) ),
			'not_found_in_trash'    => sprintf( esc_html__( 'No %s found in Trash', 'firecore-core' ), strtolower( $this->name ) ),
			'menu_name'             => $this->name,
			'featured_image'        => sprintf( esc_html__( '%s Image ', 'firecore-core' ), $this->singular_name ),
			'set_featured_image'    => sprintf( esc_html__( 'Set %s Image', 'firecore-core' ), $this->singular_name ),
			'remove_featured_image' => esc_html__( 'Remove ', 'firecore-core' ) . $this->singular_name . esc_html__( ' Image', 'firecore-core' ),
			'use_featured_image'    => sprintf( esc_html__( 'Use as %s Image', 'firecore-core' ), $this->singular_name ),
		];

		$args = [
			'labels'        => $labels,
			'public'        => true,
			'show_ui'       => true,
			'show_in_menu'  => true,
			'query_var'     => true,
			'rewrite'       => ['slug' => $this->slug],
			'has_archive'   => true,
			'menu_position' => 33,
			'menu_icon'     => defined( 'FIRECORE_THEME_URI' ) ? FIRECORE_ADDON_ASSETS . '/images/cpt-icon.png' : '',
			'supports'      => ['title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'],
		];

		register_post_type( $this->type, $args );
	}

	public function register_taxonomy_cat() {
		$category = 'cats';

		$labels = [
			'name'              => sprintf( esc_html__( '%s Categories', 'firecore-core' ), $this->name ),
			'menu_name'         => sprintf( esc_html__( '%s Categories', 'firecore-core' ), $this->name ),
			'singular_name'     => sprintf( esc_html__( '%s Category', 'firecore-core' ), $this->name ),
			'search_items'      => sprintf( esc_html__( 'Search %s Categories', 'firecore-core' ), $this->name ),
			'all_items'         => sprintf( esc_html__( 'All %s Categories', 'firecore-core' ), $this->name ),
			'parent_item'       => sprintf( esc_html__( 'Parent %s Category', 'firecore-core' ), $this->name ),
			'parent_item_colon' => sprintf( esc_html__( 'Parent %s Category:', 'firecore-core' ), $this->name ),
			'new_item_name'     => sprintf( esc_html__( 'New %s Category Name', 'firecore-core' ), $this->name ),
			'add_new_item'      => sprintf( esc_html__( 'Add New %s Category', 'firecore-core' ), $this->name ),
			'edit_item'         => sprintf( esc_html__( 'Edit %s Category', 'firecore-core' ), $this->name ),
			'update_item'       => sprintf( esc_html__( 'Update %s Category', 'firecore-core' ), $this->name ),
		];

		$args = [
			'labels'            => $labels,
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => $this->cats_slug],
			'show_in_nav_menus' => false,
		];

		register_taxonomy( $this->type . '_' . $category, [$this->type], $args );
	}
}

new Project();
