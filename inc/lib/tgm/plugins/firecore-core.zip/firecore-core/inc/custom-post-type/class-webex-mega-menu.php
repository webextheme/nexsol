<?php
/**
 * Firecore Mega Menu – FINAL WUKO STYLE SYSTEM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Firecore_Mega_Menu {

  public function __construct() {

    /* Register Mega Menu Template Post Type */
    add_action( 'init', array( $this, 'register_cpt' ) );

    /* Add Fields */
    add_action( 'wp_nav_menu_item_custom_fields', array( $this, 'add_menu_item_fields' ), 10, 4 );

    /* Save Fields */
    add_action( 'wp_update_nav_menu_item', array( $this, 'save_menu_item_fields' ), 10, 3 );

    /* Attach Custom Walker */
    add_filter( 'wp_nav_menu_args', array( $this, 'filter_nav_menu_args' ) );

    /* Elementor Support */
    add_filter( 'elementor/utils/get_public_post_types', array( $this, 'enable_elementor' ) );
    add_filter( 'elementor_pro/utils/get_public_post_types', array( $this, 'enable_elementor' ) );
    add_filter( 'elementor/editor/post_types', array( $this, 'enable_elementor' ) );
  }

  /**
   * Register CPT
   */
  public function register_cpt() {

    $labels = [
      'name'          => __('Mega Menu', 'firecore'),
      'singular_name' => __('Mega Menu', 'firecore'),
    ];

    $args = [
      'labels'          => $labels,
      'public'          => true,
      'show_in_rest'    => true,
      'menu_position'   => 32,
      'menu_icon' 			=> FIRECORE_ADDON_ASSETS .'/images/cpt-icon.png',
      'supports'        => ['title', 'editor'],
    ];

    register_post_type( 'firecore_mega_menu', $args );
  }

  /**
   * Admin Menu Item Fields
   */
  public function add_menu_item_fields( $item_id, $item ) {

    $enabled  = get_post_meta( $item_id, '_firecore_mega_enabled', true );
    $template = get_post_meta( $item_id, '_firecore_mega_template', true );

    $templates = get_posts([
      'post_type'    => 'firecore_mega_menu',
      'numberposts'  => -1,
      'post_status'  => 'publish',
    ]);
    ?>

    <p class="description description-wide">
      <label>
        <input type="checkbox"
          name="firecore_mega_enabled[<?php echo $item_id; ?>]"
          value="1" <?php checked( $enabled, '1' ); ?> />
        Enable Mega Menu
      </label>
    </p>

    <p class="description description-wide">
      <label>
        Mega Menu Template:<br>
        <select name="firecore_mega_template[<?php echo $item_id; ?>]">
          <option value="">-- None --</option>
          <?php foreach ( $templates as $t ) : ?>
            <option value="<?php echo $t->ID; ?>" <?php selected( $template, $t->ID ); ?>>
              <?php echo $t->post_title; ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
    </p>

    <?php
  }

  /**
   * Save Meta Fields
   */
  public function save_menu_item_fields( $menu_id, $item_id ) {

    $enabled  = isset($_POST['firecore_mega_enabled'][$item_id]) ? '1' : '';
    $template = isset($_POST['firecore_mega_template'][$item_id]) ? intval($_POST['firecore_mega_template'][$item_id]) : '';

    if ( $enabled )
      update_post_meta($item_id, '_firecore_mega_enabled', 1);
    else
      delete_post_meta($item_id, '_firecore_mega_enabled');

    if ( $template )
      update_post_meta($item_id, '_firecore_mega_template', $template);
    else
      delete_post_meta($item_id, '_firecore_mega_template');
  }

  /**
   * Attach Walker
   */
  public function filter_nav_menu_args( $args ) {

    if ( isset($args['theme_location']) && $args['theme_location'] === 'primary' ) {
      $args['walker'] = new Firecore_Mega_Menu_Walker();
    }

    return $args;
  }

  /**
   * Elementor support
   */
  public function enable_elementor( $post_types ) {
    $post_types['firecore_mega_menu'] = 'firecore_mega_menu';
    return $post_types;
  }
}


/***************************************************
 *  WUKO STYLE MEGA MENU WALKER
 ***************************************************/
class Firecore_Mega_Menu_Walker extends Walker_Nav_Menu {

  public function start_el( &$output, $item, $depth = 0, $args = [], $id = 0 ) {

    $enabled  = get_post_meta( $item->ID, '_firecore_mega_enabled', true );
    $template = get_post_meta( $item->ID, '_firecore_mega_template', true );

    /* Build Classes */
    $classes = empty($item->classes) ? [] : (array) $item->classes;

    if ( $enabled && $depth === 0 ) {
      $classes[] = 'firecore-mega-menu-item';
      $classes[] = 'menu-item-has-children';
    }

    $class_names = ' class="' . esc_attr( implode( ' ', $classes ) ) . '"';
    $output .= '<li' . $class_names . '>';

    /* Link */
    $output .= '<a href="' . esc_url($item->url) . '" class="firecore-menu-link">'
                . esc_html($item->title)
                . '</a>';

    /* Required empty sub-menu */
    if ( $depth === 0 ) {
      $output .= '<ul class="sub-menu"></ul>';
    }

    /* Mega Menu Content */
    if ( $enabled && $template && $depth === 0 ) {

      if ( class_exists('\Elementor\Plugin') ) {
        $content = \Elementor\Plugin::instance()->frontend
                    ->get_builder_content_for_display( $template );
      } else {
        $post = get_post( $template );
        $content = $post ? apply_filters('the_content', $post->post_content) : '';
      }

      $output .= '
        <div class="firecore-mega-menu-container">
          <div class="firecore-mega-inner">' .
            $content .
          '</div>
        </div>';
    }
  }

  public function end_el( &$output, $item, $depth = 0, $args = [] ) {
    $output .= "</li>\n";
  }
}

new Firecore_Mega_Menu();
