<?php

/**
 * Create Side Panel Post Type
 */
function webex_core_side_panel_post_type() {
	$labels = [
		'name'                  => _x('Side Panels', 'Post type general name', 'firecore-core'),
		'singular_name'         => _x('Side Panel', 'Post type singular name', 'firecore-core'),
		'add_new'               => __('Add New', 'firecore-core'),
		'all_items'             => __('All Items', 'firecore-core'),
	];

	$args = [
		'labels'             => $labels,
		'public'             => true,
		'rewrite' => array(
			'slug' => 'wbx_side_panel',
			'with_front' => true
		),
		'menu_position'      => 34,
		'menu_icon' 				 => FIRECORE_ADDON_ASSETS .'/images/cpt-icon.png',
		'supports'           => ['title', 'editor'],
	];

	register_post_type('wbx_side_panel', $args);
}

add_action('init', 'webex_core_side_panel_post_type');
